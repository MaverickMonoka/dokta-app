#!/usr/bin/env bash
# First-run setup. Idempotent — safe to run again.
set -euo pipefail

echo "→ Checking Node version"
node --version | grep -qE 'v(2[0-9]|[3-9][0-9])' || { echo "Node 20+ required"; exit 1; }

echo "→ Installing dependencies"
corepack enable && corepack prepare pnpm@9.12.0 --activate
pnpm install

if [ ! -f .env ]; then
  echo "→ Creating .env from .env.example"
  cp .env.example .env
  echo "  Fill in your Supabase and gateway keys before running the app."
fi

echo "→ Starting Postgres and Redis"
docker compose up -d postgres redis

echo "→ Waiting for Postgres"
until docker compose exec -T postgres pg_isready -U postgres -d dokta >/dev/null 2>&1; do sleep 1; done

echo "→ Applying the schema"
pnpm db:generate
pnpm db:migrate --name init

echo "→ Seeding demo data"
pnpm db:seed

echo
echo "Done. Run 'pnpm dev' and open http://localhost:3000"
