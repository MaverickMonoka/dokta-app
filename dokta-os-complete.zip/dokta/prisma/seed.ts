/**
 * Demo data for DOKTA. Realistic South African providers, medicines at roughly
 * real single-exit prices, and three patient accounts.
 *
 * Users are created in Supabase Auth first so the demo accounts can actually
 * sign in; `User.id` mirrors the Supabase UUID. Set SUPABASE_SERVICE_ROLE_KEY
 * before running, or pass --db-only to seed the tables without auth users.
 */

import { randomUUID } from 'node:crypto';
import { PrismaClient } from '@prisma/client';
import { createClient } from '@supabase/supabase-js';

const db = new PrismaClient();
const dbOnly = process.argv.includes('--db-only');
const DEMO_PASSWORD = 'DoktaDemo2026!';

const supabase =
  !dbOnly && process.env.SUPABASE_SERVICE_ROLE_KEY
    ? createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
        auth: { persistSession: false },
      })
    : null;

async function createUser(input: {
  name: string;
  email: string;
  phone: string;
  role: 'PATIENT' | 'DOCTOR' | 'PHARMACY' | 'ADMIN';
  avatarUrl?: string;
}) {
  let id = randomUUID();

  if (supabase) {
    const { data, error } = await supabase.auth.admin.createUser({
      email: input.email,
      password: DEMO_PASSWORD,
      email_confirm: true,
      user_metadata: { name: input.name, role: input.role },
    });
    if (error && !error.message.includes('already been registered')) throw error;
    if (data?.user) id = data.user.id;
  }

  return db.user.upsert({
    where: { email: input.email },
    update: { name: input.name, phone: input.phone, role: input.role },
    create: { id, ...input },
  });
}

const AVATAR = (seed: string) =>
  `https://images.unsplash.com/${seed}?auto=format&fit=facearea&facepad=2.5&w=200&h=200&q=70`;

async function main() {
  console.log('Seeding DOKTA…');

  // ── Admin ────────────────────────────────────────────────────────────────
  await createUser({
    name: 'Naledi Khoza',
    email: 'admin@dokta.africa',
    phone: '+27110000001',
    role: 'ADMIN',
  });

  // ── Doctors ──────────────────────────────────────────────────────────────
  const doctorSeed = [
    {
      name: 'Dr Thandiwe Mahlangu',
      email: 'dr.mahlangu@dokta.africa',
      phone: '+27824410021',
      speciality: 'General Practitioner',
      licenseNumber: 'MP 0654123',
      fee: 250,
      languages: ['English', 'isiZulu', 'Sepedi'],
      city: 'Polokwane',
      province: 'Limpopo',
      years: 11,
      bio: 'Family medicine, chronic disease management and womens health. Consults in three languages.',
      avatar: AVATAR('photo-1594824476967-48c8b964273f'),
      rating: 4.8,
      ratingCount: 214,
    },
    {
      name: 'Dr Sipho Ndlovu',
      email: 'dr.ndlovu@dokta.africa',
      phone: '+27837720045',
      speciality: 'Dentist',
      licenseNumber: 'DP 0219884',
      fee: 480,
      languages: ['English', 'isiZulu'],
      city: 'Johannesburg',
      province: 'Gauteng',
      years: 8,
      bio: 'General and cosmetic dentistry. Video consultations for assessments and follow-ups.',
      avatar: AVATAR('photo-1612349317150-e413f6a5b16d'),
      rating: 4.6,
      ratingCount: 97,
    },
    {
      name: 'Dr Anwar Patel',
      email: 'dr.patel@dokta.africa',
      phone: '+27713340098',
      speciality: 'Cardiologist',
      licenseNumber: 'MP 0331207',
      fee: 1450,
      languages: ['English', 'Afrikaans'],
      city: 'Pretoria',
      province: 'Gauteng',
      years: 19,
      bio: 'Interventional cardiology. Referral consultations and post-procedure follow-up.',
      avatar: AVATAR('photo-1622253692010-333f2da6031d'),
      rating: 4.9,
      ratingCount: 312,
    },
  ];

  const doctors = [];
  for (const d of doctorSeed) {
    const user = await createUser({
      name: d.name,
      email: d.email,
      phone: d.phone,
      role: 'DOCTOR',
      avatarUrl: d.avatar,
    });

    const doctor = await db.doctor.upsert({
      where: { userId: user.id },
      update: {},
      create: {
        userId: user.id,
        speciality: d.speciality,
        licenseNumber: d.licenseNumber,
        bio: d.bio,
        languages: d.languages,
        yearsExperience: d.years,
        consultFee: d.fee,
        followUpFee: Math.round(d.fee * 0.6),
        city: d.city,
        province: d.province,
        verification: 'VERIFIED',
        verifiedAt: new Date(),
        rating: d.rating,
        ratingCount: d.ratingCount,
      },
    });

    // Weekday mornings and afternoons, 15-minute slots.
    for (const weekday of [1, 2, 3, 4, 5]) {
      await db.availabilitySlot.upsert({
        where: { doctorId_weekday_startTime: { doctorId: doctor.id, weekday, startTime: '08:00' } },
        update: {},
        create: { doctorId: doctor.id, weekday, startTime: '08:00', endTime: '12:00' },
      });
      await db.availabilitySlot.upsert({
        where: { doctorId_weekday_startTime: { doctorId: doctor.id, weekday, startTime: '13:30' } },
        update: {},
        create: { doctorId: doctor.id, weekday, startTime: '13:30', endTime: '16:30' },
      });
    }

    doctors.push(doctor);
  }

  // ── Medicines ────────────────────────────────────────────────────────────
  const medicineSeed = [
    { name: 'Panado', genericName: 'Paracetamol', strength: '500mg', category: 'Analgesic', schedule: 'S0', price: 34.5, barcode: '6001106111212' },
    { name: 'Adco-Dol', genericName: 'Paracetamol/Codeine', strength: '500mg', category: 'Analgesic', schedule: 'S2', price: 58.0, barcode: '6009695420018' },
    { name: 'Amoxil', genericName: 'Amoxicillin', strength: '500mg', category: 'Antibiotic', schedule: 'S4', price: 89.9, barcode: '6001299001234' },
    { name: 'Glucophage', genericName: 'Metformin', strength: '850mg', category: 'Antidiabetic', schedule: 'S3', price: 121.4, barcode: '6001299005678' },
    { name: 'Ciplavasc', genericName: 'Amlodipine', strength: '5mg', category: 'Antihypertensive', schedule: 'S3', price: 76.2, barcode: '6009677110034' },
    { name: 'Allergex', genericName: 'Chlorphenamine', strength: '4mg', category: 'Antihistamine', schedule: 'S1', price: 41.8, barcode: '6001106220456' },
    { name: 'Venteze', genericName: 'Salbutamol', strength: '100mcg', category: 'Bronchodilator', schedule: 'S3', price: 68.5, barcode: '6009677220991' },
    { name: 'Rehidrat', genericName: 'Oral rehydration salts', strength: '4.1g', category: 'Rehydration', schedule: 'S0', price: 19.9, barcode: '6001106339012' },
  ] as const;

  const medicines = [];
  for (const m of medicineSeed) {
    medicines.push(
      await db.medicine.upsert({
        where: { barcode: m.barcode },
        update: {},
        create: {
          name: m.name,
          genericName: m.genericName,
          barcode: m.barcode,
          category: m.category,
          strength: m.strength,
          schedule: m.schedule,
          sepPrice: m.price,
          form: m.name === 'Venteze' ? 'inhaler' : 'tablet',
        },
      }),
    );
  }

  // ── Pharmacies ───────────────────────────────────────────────────────────
  const pharmacySeed = [
    {
      owner: { name: 'Lerato Sithole', email: 'lerato@kasipharm.co.za', phone: '+27735510012' },
      name: 'Kasi Care Pharmacy',
      registrationNo: 'SAPC-0114472',
      suburb: 'Jane Furse',
      city: 'Sekhukhune',
      province: 'Limpopo',
      deliveryFee: 25,
      radius: 20,
    },
    {
      owner: { name: 'Riaan van Wyk', email: 'riaan@meridianrx.co.za', phone: '+27829930077' },
      name: 'Meridian Pharmacy Menlyn',
      registrationNo: 'SAPC-0098311',
      suburb: 'Menlyn',
      city: 'Pretoria',
      province: 'Gauteng',
      deliveryFee: 45,
      radius: 12,
    },
  ];

  const pharmacies = [];
  for (const p of pharmacySeed) {
    const owner = await createUser({ ...p.owner, role: 'PHARMACY' });

    const pharmacy = await db.pharmacy.upsert({
      where: { registrationNo: p.registrationNo },
      update: {},
      create: {
        ownerId: owner.id,
        name: p.name,
        registrationNo: p.registrationNo,
        responsiblePharmacist: p.owner.name,
        phone: p.owner.phone,
        email: p.owner.email,
        suburb: p.suburb,
        city: p.city,
        province: p.province,
        deliveryFee: p.deliveryFee,
        deliveryRadiusKm: p.radius,
        verification: 'VERIFIED',
      },
    });

    const supplier = await db.supplier.create({
      data: {
        pharmacyId: pharmacy.id,
        name: 'Alpha Pharm Wholesalers',
        contactName: 'Orders desk',
        phone: '+27114550100',
        leadTimeDays: 2,
      },
    });

    for (const medicine of medicines) {
      const markup = p.city === 'Pretoria' ? 1.32 : 1.18; // township pricing runs leaner
      const item = await db.inventoryItem.upsert({
        where: { pharmacyId_medicineId: { pharmacyId: pharmacy.id, medicineId: medicine.id } },
        update: {},
        create: {
          pharmacyId: pharmacy.id,
          medicineId: medicine.id,
          costPrice: Number(medicine.sepPrice),
          sellingPrice: Math.round(Number(medicine.sepPrice) * markup * 100) / 100,
          stockOnHand: 20 + Math.floor(Math.random() * 90),
          reorderLevel: 15,
        },
      });

      await db.stockBatch.create({
        data: {
          inventoryId: item.id,
          batchNumber: `B${Math.floor(100000 + Math.random() * 899999)}`,
          quantity: item.stockOnHand,
          expiryDate: new Date(Date.now() + (90 + Math.random() * 640) * 86_400_000),
          supplierId: supplier.id,
        },
      });
    }

    pharmacies.push(pharmacy);
  }

  // ── Patients ─────────────────────────────────────────────────────────────
  const patientSeed = [
    {
      name: 'Kagiso Mokoena',
      email: 'kagiso@example.co.za',
      phone: '+27761120034',
      dob: '1992-04-17',
      gender: 'MALE',
      city: 'Sekhukhune',
      province: 'Limpopo',
      allergies: ['Penicillin'],
      history: ['Asthma, diagnosed 2015'],
      wallet: 320,
    },
    {
      name: 'Nomsa Dlamini',
      email: 'nomsa@example.co.za',
      phone: '+27823340561',
      dob: '1978-11-02',
      gender: 'FEMALE',
      city: 'Pretoria',
      province: 'Gauteng',
      allergies: [],
      history: ['Type 2 diabetes, diagnosed 2019', 'Hypertension'],
      wallet: 0,
    },
    {
      name: 'Ethan Pillay',
      email: 'ethan@example.co.za',
      phone: '+27718890223',
      dob: '2001-07-25',
      gender: 'MALE',
      city: 'Johannesburg',
      province: 'Gauteng',
      allergies: ['Sulfa drugs'],
      history: [],
      wallet: 150,
    },
  ] as const;

  const patients = [];
  for (const p of patientSeed) {
    const user = await createUser({
      name: p.name,
      email: p.email,
      phone: p.phone,
      role: 'PATIENT',
    });

    patients.push(
      await db.patient.upsert({
        where: { userId: user.id },
        update: {},
        create: {
          userId: user.id,
          dateOfBirth: new Date(p.dob),
          gender: p.gender,
          city: p.city,
          province: p.province,
          allergies: p.allergies as unknown as object,
          medicalHistory: p.history as unknown as object,
          walletBalance: p.wallet,
        },
      }),
    );
  }

  // ── A booked appointment and a live prescription, so screens are not empty ─
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  tomorrow.setHours(10, 0, 0, 0);

  const appointment = await db.appointment.create({
    data: {
      reference: 'APT-K7M2QX-0109',
      patientId: patients[0].id,
      doctorId: doctors[0].id,
      type: 'VIDEO',
      scheduledFor: tomorrow,
      status: 'CONFIRMED',
      reasonForVisit: 'Persistent cough and shortness of breath for five days',
      symptoms: ['cough', 'shortness of breath', 'fatigue'],
      fee: 250,
    },
  });

  await db.consultation.create({
    data: { appointmentId: appointment.id, chiefComplaint: 'Persistent cough' },
  });

  const validUntil = new Date();
  validUntil.setMonth(validUntil.getMonth() + 6);

  await db.prescription.create({
    data: {
      reference: 'RX-P4N8TB-0109',
      doctorId: doctors[0].id,
      patientId: patients[1].id,
      pharmacyId: pharmacies[0].id,
      status: 'SENT_TO_PHARMACY',
      repeats: 5,
      validUntil,
      items: {
        create: [
          {
            medicineId: medicines[3].id,
            medicineName: 'Glucophage',
            strength: '850mg',
            dosage: '1 tablet',
            frequency: 'Twice daily with meals',
            durationDays: 30,
            quantity: 60,
            instructions: 'Take with food to reduce stomach upset.',
          },
          {
            medicineId: medicines[4].id,
            medicineName: 'Ciplavasc',
            strength: '5mg',
            dosage: '1 tablet',
            frequency: 'Once daily in the morning',
            durationDays: 30,
            quantity: 30,
          },
        ],
      },
    },
  });

  console.log(`Seeded ${doctors.length} doctors, ${pharmacies.length} pharmacies, ${patients.length} patients, ${medicines.length} medicines.`);
  if (supabase) console.log(`Demo sign-in password: ${DEMO_PASSWORD}`);
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
