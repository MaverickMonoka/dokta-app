# DOKTA OS

The healthcare operating system for Africa. Telemedicine, prescriptions,
pharmacy management and payments in one codebase.

---

## What is in this repository

All three phases are built. The monorepo runs four web apps and three mobile
apps against one database, one design system and one domain layer.

| Area | State |
| --- | --- |
| Monorepo, Turborepo, Docker, CI | Complete |
| Prisma schema — 24 models covering every domain | Complete |
| Supabase auth, capability model, POPIA audit trail | Complete |
| Design system — tokens, Tailwind preset, component library | Complete |
| Payments — Yoco, PayFast, Ozow, SnapScan behind one interface | Complete |
| AI modules — patient triage, clinical notes, stock forecasting | Complete |
| Notifications — email, SMS, WhatsApp, push, one template set | Complete |
| Patient web — landing page, dashboard, auth callback | Complete |
| Domain layer — booking, dispensing, POS, billing, analytics | Complete |
| Doctor command centre — queue, consultation, scripts, availability, earnings | Complete |
| Pharmacy — till, script queue, dispensing, stock, expiries, reports | Complete |
| Admin — metrics, verification, payments, refunds, POPIA access log | Complete |
| Payment wiring — checkout, four webhook handlers, refunds | Complete |
| Scheduled jobs — reminders, expiry, no-show sweep | Complete |
| Expo mobile apps — patient, doctor, pharmacy | Complete |

---

## Running it

```bash
git clone <repo> dokta && cd dokta
./scripts/setup.sh
pnpm dev
```

Four web apps come up together:

| App | Port | Who signs in |
| --- | --- | --- |
| Patient web | 3000 | Patients and the public |
| Doctor command centre | 3001 | Verified doctors |
| Pharmacy | 3002 | Pharmacy owners and staff |
| Admin | 3003 | Platform administrators |

Run one on its own with `pnpm dev:doctor`, `pnpm dev:pharmacy` or `pnpm dev:admin`.
For a mobile app: `cd apps/patient-mobile && cp .env.example .env && pnpm dev`.

The setup script installs dependencies, starts Postgres and Redis in Docker,
applies the schema and loads demo data. Open http://localhost:3000.

Seeded accounts all use the password `DoktaDemo2026!`:

| Role | Email |
| --- | --- |
| Patient | `kagiso@example.co.za` |
| Doctor | `dr.mahlangu@dokta.africa` |
| Pharmacy | `lerato@kasipharm.co.za` |
| Admin | `admin@dokta.africa` |

To seed the database without creating Supabase auth users:
`pnpm db:seed -- --db-only`.

---

## Structure

```
dokta/
  apps/
    patient-web/          Next.js 14 App Router — patient marketing and dashboard
    doctor-dashboard/     Command centre, consultations, availability, earnings
    pharmacy-dashboard/   Till, scripts, dispensing, stock, expiries, reports
    admin-dashboard/      Metrics, verification, payments, access log
    patient-mobile/       Expo — appointments, prescriptions, payments
    doctor-mobile/        Expo — today's list, read-only by design
    pharmacy-mobile/      Expo — shelf-side barcode price and stock check
  packages/
    shared/               Brand tokens, roles, formatting, Zod schemas
    core/                 Domain layer: booking, dispensing, POS, billing, analytics
    database/             Prisma client and Redis read-through cache
    auth/                 Supabase SSR, session, capability guards, audit log
    ui/                   Tailwind preset and component library
    payments/             Gateway interface plus four implementations
    notifications/        Email, SMS, WhatsApp, push behind one template set
    ai/                   Patient triage, clinical notes, demand forecasting
    mobile-ui/            Native theme and primitives shared by the Expo apps
  prisma/                 schema.prisma and seed.ts
  docker/                 Multi-stage build for any app in the workspace
```

---

## Architecture notes

**Authentication.** Supabase owns the credential; this database owns the
profile. They are joined on the same UUID, so Postgres row-level security can
key off `auth.uid()` without a lookup table. The callback route creates the
profile row on first sign-in.

**Authorisation.** Nothing checks `role === 'DOCTOR'`. Roles map to capability
strings in `packages/shared/src/roles.ts`, and both the UI and the API check
capabilities. Adding a role — a nurse, a practice manager — is one entry in
that map rather than a search across the codebase.

**Payments.** Every gateway implements `PaymentGateway`. Yoco redirects,
PayFast and Ozow post signed forms, SnapScan renders a QR code — the interface
covers all three shapes through `formFields` on the checkout result. Webhook
handlers verify signatures and return `ignored` rather than `succeeded` when
they cannot, so a forged callback can never mark an order paid.

**POPIA.** Section 14 requires a record of every access to personal health
information, not only every change. `audit()` in `packages/auth` logs reads as
well as writes, including the data subject and the lawful basis. It never
throws — an audit outage must not block clinical care — but failures are logged.

**Caching.** Redis caches public data only: doctor search, pharmacy listings,
stock levels. Nothing containing patient health information is cached.

**AI boundaries.** The symptom assistant triages urgency and never names a
condition as fact. The interaction checker advises but never blocks a
prescription — a hard block would push clinicians off the platform onto paper.
Clinical notes are always drafts the doctor signs.

---

## Design system

Colours, type and spacing live in `packages/shared/src/brand.ts` and
`packages/ui/tailwind-preset.js`. Apps extend the preset rather than
redeclaring values, so a brand change is a one-file change.

- Navy `#0B2137` is the dominant surface, not an accent
- Green `#059669` is reserved for confirmed and healthy states
- Red `#DC2626` appears only for emergencies and failures
- Plus Jakarta Sans for headings, Inter for body and all figures
- All figures are tabular, so amounts line up in every table and receipt

---

## Deployment

**Vercel.** One project per app, root directory set to `apps/<name>`, build
command `pnpm turbo run build --filter=@dokta/<name>`. Set the environment
variables from `.env.example` in the project settings.

**Database.** Point `DATABASE_URL` at the Supabase pooled connection and
`DIRECT_URL` at the direct one, then run `pnpm db:deploy`.

**Webhooks.** Register these endpoints with each provider before going live:

```
/api/webhooks/yoco
/api/webhooks/payfast
/api/webhooks/ozow
/api/webhooks/snapscan
```

**Cloudflare.** Proxy the apex domain, turn on Bot Fight Mode, and rate-limit
`/api/auth/*` to 10 requests per minute per IP.


---

## How the domain layer works

Business rules live in `packages/core`, not in pages. A dashboard calls
`dispensePrescription` or `ringUpSale`; it does not write its own Prisma
queries for those. That is why the same rule holds whether a script is
dispensed from the web, an API call, or a future integration.

Rules worth knowing because they will surprise you otherwise:

- **Stock comes off first-expiry-first, not first-in-first-out.** In a pharmacy
  the batch closest to expiry is the one that must move. Expired batches are
  skipped entirely rather than dispensed.
- **A sale fails whole or succeeds whole.** Stock is deducted before the sale
  is written, so a receipt never exists for goods that were not in the shop.
- **S5 and S6 scripts are capped at 30 days with no repeats**, regardless of
  what the prescriber asks for. The regulation wins over the caller.
- **An order only moves to picking once payment settles.** Nothing leaves the
  counter on the strength of an unpaid order.
- **Webhooks that fail verification return 200 and change nothing.** Retrying a
  forged callback forever helps nobody; what matters is that it never advances
  an order. A verified webhook that we fail to *apply* returns 500, because
  that is the one case where a retry is wanted.
- **Refunds are automated for Yoco only.** PayFast, Ozow and SnapScan have no
  refund API, so the admin interface says so and asks for an EFT instead of
  failing silently.

## What each mobile app deliberately does not do

The doctor app shows the day's list and nothing else — notes written on a phone
produce worse clinical records than notes written at a desk, so consultation
writing stays on the web. The pharmacy app is a shelf-side price and stock
check; the till stays on the web dashboard where the cash drawer and slip
printer are. Both decisions are about where the work is actually done well, not
about effort saved.

## Scheduled jobs

`/api/cron/reminders` runs hourly on Vercel (`apps/patient-web/vercel.json`).
It sends 24-hour appointment reminders, expires prescriptions past their
validity date, and marks confirmed appointments as no-shows two hours after
their slot. It is protected by `CRON_SECRET`, so set that before deploying.
The reminder window is the hour *ahead* of the 24-hour mark, which means an
hourly schedule sends each reminder exactly once without a "reminded" column.

---

## Before going live

Compliance items that are code-adjacent but not code:

- SAPC licence for any pharmacy transacting on the platform
- HPCSA verification for every doctor before their profile goes public
- Section 22A record-keeping for scheduled medicines, S5 and above
- POPIA information officer registered with the Information Regulator
- Professional indemnity cover naming the platform
