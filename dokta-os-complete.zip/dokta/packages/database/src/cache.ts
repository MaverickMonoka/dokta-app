import Redis from 'ioredis';

declare global {
  // eslint-disable-next-line no-var
  var __doktaRedis: Redis | undefined;
}

export const cache =
  global.__doktaRedis ??
  new Redis(process.env.REDIS_URL ?? 'redis://localhost:6379', {
    maxRetriesPerRequest: 2,
    lazyConnect: true,
  });

if (process.env.NODE_ENV !== 'production') global.__doktaRedis = cache;

/**
 * Read-through cache. Used for doctor search results and pharmacy stock
 * lookups — never for anything containing patient health information.
 */
export async function cached<T>(
  key: string,
  ttlSeconds: number,
  produce: () => Promise<T>,
): Promise<T> {
  try {
    const hit = await cache.get(key);
    if (hit) return JSON.parse(hit) as T;
  } catch {
    // Cache is an optimisation, never a dependency — fall through to source.
  }

  const value = await produce();

  try {
    await cache.set(key, JSON.stringify(value), 'EX', ttlSeconds);
  } catch {
    /* ignore write failures */
  }

  return value;
}
