import { PrismaClient } from '@prisma/client';

declare global {
  // eslint-disable-next-line no-var
  var __doktaPrisma: PrismaClient | undefined;
}

/**
 * One client per process. Next.js hot-reloads modules in dev, which would
 * otherwise open a new pool on every save and exhaust Supabase connections.
 */
export const db =
  global.__doktaPrisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === 'development' ? ['warn', 'error'] : ['error'],
  });

if (process.env.NODE_ENV !== 'production') global.__doktaPrisma = db;

export * from '@prisma/client';
export { cache, cached } from './cache';
