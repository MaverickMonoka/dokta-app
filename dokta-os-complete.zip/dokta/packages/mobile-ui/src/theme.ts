import { colors, fonts } from '@dokta/shared';

/**
 * Native theme derived from the same tokens the web uses, so a colour change
 * on the brand lands on all three mobile apps without a second edit.
 */
export const theme = {
  color: {
    ...colors,
    surface: colors.white,
    onNavy: 'rgba(255,255,255,0.72)',
    onNavyFaint: 'rgba(255,255,255,0.45)',
  },
  space: (n: number) => n * 4,
  radius: { control: 10, card: 14, pill: 999 },
  font: {
    display: fonts.display,
    body: fonts.body,
  },
  text: {
    display: { fontSize: 28, fontWeight: '700' as const, letterSpacing: -0.6, color: colors.ink },
    title: { fontSize: 18, fontWeight: '600' as const, color: colors.ink },
    body: { fontSize: 15, color: colors.ink },
    meta: { fontSize: 13, color: colors.muted },
  },
};

export const statusTone = (status: string): { bg: string; fg: string } => {
  if (['CONFIRMED', 'COMPLETED', 'DELIVERED', 'PAID', 'SUCCEEDED', 'DISPENSED'].includes(status)) {
    return { bg: colors.greenSoft, fg: '#047857' };
  }
  if (['CANCELLED', 'FAILED', 'NO_SHOW', 'REJECTED'].includes(status)) {
    return { bg: colors.redSoft, fg: colors.red };
  }
  return { bg: '#FEF3C7', fg: colors.amber };
};
