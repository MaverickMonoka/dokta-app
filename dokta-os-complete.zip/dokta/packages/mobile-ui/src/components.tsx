import * as React from 'react';
import {
  ActivityIndicator,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
  type ViewStyle,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { theme, statusTone } from './theme';

export function Screen({
  children,
  tone = 'light',
  scroll = true,
}: {
  children: React.ReactNode;
  tone?: 'light' | 'navy';
  scroll?: boolean;
}) {
  const background = tone === 'navy' ? theme.color.navy : theme.color.background;
  const Body = scroll ? ScrollView : View;

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: background }} edges={['top']}>
      <Body
        style={{ flex: 1 }}
        contentContainerStyle={scroll ? { padding: theme.space(5), paddingBottom: theme.space(12) } : undefined}
      >
        {children}
      </Body>
    </SafeAreaView>
  );
}

export function Heading({ children, tone = 'light' }: { children: React.ReactNode; tone?: 'light' | 'navy' }) {
  return (
    <Text style={[theme.text.display, tone === 'navy' && { color: theme.color.white }]}>{children}</Text>
  );
}

export function Card({ children, style }: { children: React.ReactNode; style?: ViewStyle }) {
  return <View style={[styles.card, style]}>{children}</View>;
}

export function Button({
  label,
  onPress,
  variant = 'primary',
  loading,
  disabled,
}: {
  label: string;
  onPress: () => void;
  variant?: 'primary' | 'navy' | 'outline';
  loading?: boolean;
  disabled?: boolean;
}) {
  const background =
    variant === 'primary' ? theme.color.green : variant === 'navy' ? theme.color.navy : 'transparent';

  return (
    <Pressable
      onPress={onPress}
      disabled={disabled || loading}
      accessibilityRole="button"
      style={({ pressed }) => [
        styles.button,
        {
          backgroundColor: background,
          borderWidth: variant === 'outline' ? 1 : 0,
          borderColor: theme.color.border,
          opacity: disabled || loading ? 0.55 : pressed ? 0.85 : 1,
        },
      ]}
    >
      {loading ? (
        <ActivityIndicator color={variant === 'outline' ? theme.color.ink : theme.color.white} />
      ) : (
        <Text
          style={{
            color: variant === 'outline' ? theme.color.ink : theme.color.white,
            fontSize: 15,
            fontWeight: '600',
          }}
        >
          {label}
        </Text>
      )}
    </Pressable>
  );
}

export function Badge({ status }: { status: string }) {
  const tone = statusTone(status);
  return (
    <View style={[styles.badge, { backgroundColor: tone.bg }]}>
      <Text style={{ color: tone.fg, fontSize: 12, fontWeight: '600' }}>
        {status.toLowerCase().replace(/_/g, ' ')}
      </Text>
    </View>
  );
}

/** An empty screen states what to do next, never just that there is nothing. */
export function Empty({ title, body, action }: { title: string; body: string; action?: React.ReactNode }) {
  return (
    <View style={{ alignItems: 'center', paddingVertical: theme.space(12) }}>
      <Text style={[theme.text.title, { textAlign: 'center' }]}>{title}</Text>
      <Text style={[theme.text.meta, { textAlign: 'center', marginTop: 6, maxWidth: 280 }]}>{body}</Text>
      {action && <View style={{ marginTop: theme.space(5) }}>{action}</View>}
    </View>
  );
}

export function ErrorNote({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <View style={styles.error} accessibilityRole="alert">
      <Text style={{ color: theme.color.ink, fontSize: 14 }}>{message}</Text>
      {onRetry && (
        <Pressable onPress={onRetry} style={{ marginTop: 8 }}>
          <Text style={{ color: theme.color.red, fontWeight: '600', fontSize: 14 }}>Try again</Text>
        </Pressable>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: theme.color.white,
    borderRadius: theme.radius.card,
    borderWidth: 1,
    borderColor: theme.color.border,
    padding: theme.space(4),
  },
  button: {
    height: 48,
    borderRadius: theme.radius.control,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: theme.space(5),
  },
  badge: {
    alignSelf: 'flex-start',
    borderRadius: theme.radius.pill,
    paddingHorizontal: 10,
    paddingVertical: 4,
  },
  error: {
    backgroundColor: theme.color.redSoft,
    borderRadius: theme.radius.card,
    padding: theme.space(4),
  },
});
