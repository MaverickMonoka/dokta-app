import { createHmac, timingSafeEqual } from 'node:crypto';
import type {
  CheckoutRequest,
  CheckoutResult,
  PaymentGateway,
  RefundRequest,
  RefundResult,
  WebhookOutcome,
} from './gateway.interface';
import { GatewayError } from './gateway.interface';

const API = 'https://payments.yoco.com/api';

/** Card payments. The default for consultation fees. */
export const yoco: PaymentGateway = {
  id: 'yoco',
  label: 'Card',
  description: 'Debit or credit card, processed by Yoco',
  supportsRefunds: true,

  async createCheckout(request: CheckoutRequest): Promise<CheckoutResult> {
    const response = await fetch(`${API}/checkouts`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${process.env.YOCO_SECRET_KEY}`,
        'Content-Type': 'application/json',
        'Idempotency-Key': request.reference,
      },
      body: JSON.stringify({
        amount: request.amountCents,
        currency: request.currency,
        successUrl: request.successUrl,
        cancelUrl: request.cancelUrl,
        failureUrl: request.cancelUrl,
        metadata: { reference: request.reference, ...request.metadata },
      }),
    });

    if (!response.ok) {
      throw new GatewayError('yoco', `Checkout failed (${response.status})`, await response.text());
    }

    const data = (await response.json()) as { id: string; redirectUrl: string };
    return { gateway: 'yoco', redirectUrl: data.redirectUrl, gatewayRef: data.id };
  },

  async handleWebhook(rawBody, headers): Promise<WebhookOutcome> {
    const id = headers['webhook-id'];
    const timestamp = headers['webhook-timestamp'];
    const signature = headers['webhook-signature'];
    const secret = process.env.YOCO_WEBHOOK_SECRET;

    if (!id || !timestamp || !signature || !secret) {
      return { status: 'ignored', reason: 'Missing webhook signature headers' };
    }

    // Reject anything older than five minutes — blocks replayed captures.
    if (Math.abs(Date.now() / 1000 - Number(timestamp)) > 300) {
      return { status: 'ignored', reason: 'Webhook timestamp outside tolerance' };
    }

    const expected = createHmac('sha256', Buffer.from(secret.split('_')[1] ?? secret, 'base64'))
      .update(`${id}.${timestamp}.${rawBody}`)
      .digest('base64');
    const provided = signature.split(' ')[0]?.split(',')[1] ?? '';

    const a = Buffer.from(expected);
    const b = Buffer.from(provided);
    if (a.length !== b.length || !timingSafeEqual(a, b)) {
      return { status: 'ignored', reason: 'Signature mismatch' };
    }

    const event = JSON.parse(rawBody) as {
      type: string;
      payload: { id: string; amount: number; metadata?: { reference?: string }; status?: string };
    };
    const reference = event.payload.metadata?.reference ?? '';

    if (event.type === 'payment.succeeded') {
      return {
        status: 'succeeded',
        reference,
        gatewayRef: event.payload.id,
        amountCents: event.payload.amount,
        raw: event,
      };
    }

    if (event.type === 'payment.failed') {
      return {
        status: 'failed',
        reference,
        gatewayRef: event.payload.id,
        reason: event.payload.status ?? 'Payment declined',
        raw: event,
      };
    }

    return { status: 'ignored', reason: `Unhandled event ${event.type}` };
  },

  async refund({ gatewayRef, amountCents, reason }: RefundRequest): Promise<RefundResult> {
    const response = await fetch(`${API}/refunds`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${process.env.YOCO_SECRET_KEY}`,
        'Content-Type': 'application/json',
        'Idempotency-Key': `refund-${gatewayRef}-${amountCents}`,
      },
      body: JSON.stringify({ paymentId: gatewayRef, amount: amountCents, reason }),
    });

    if (!response.ok) {
      throw new GatewayError('yoco', `Refund failed (${response.status})`, await response.text());
    }

    const data = (await response.json()) as { id: string; status: string };
    return {
      refundRef: data.id,
      amountCents,
      status: data.status === 'succeeded' ? 'succeeded' : 'pending',
    };
  },
};
