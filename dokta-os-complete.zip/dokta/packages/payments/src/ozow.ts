import { createHash } from 'node:crypto';
import type {
  CheckoutRequest,
  CheckoutResult,
  PaymentGateway,
  WebhookOutcome,
} from './gateway.interface';
import { GatewayError } from './gateway.interface';

const API = 'https://api.ozow.com';

function hash(parts: (string | number)[], key: string): string {
  return createHash('sha512')
    .update(`${parts.join('')}${key}`.toLowerCase())
    .digest('hex');
}

/** Instant EFT straight from the patient's bank. No card needed. */
export const ozow: PaymentGateway = {
  id: 'ozow',
  label: 'Instant EFT',
  description: 'Pay directly from your bank account',
  supportsRefunds: false,

  async createCheckout(request: CheckoutRequest): Promise<CheckoutResult> {
    const siteCode = process.env.OZOW_SITE_CODE!;
    const isTest = process.env.OZOW_TEST_MODE === 'true';
    const amount = (request.amountCents / 100).toFixed(2);

    const payload = {
      SiteCode: siteCode,
      CountryCode: 'ZA',
      CurrencyCode: 'ZAR',
      Amount: amount,
      TransactionReference: request.reference,
      BankReference: request.reference.slice(0, 20),
      Customer: request.customer.name,
      CancelUrl: request.cancelUrl,
      ErrorUrl: request.cancelUrl,
      SuccessUrl: request.successUrl,
      NotifyUrl: request.webhookUrl,
      IsTest: isTest,
      HashCheck: hash(
        [
          siteCode,
          'ZA',
          'ZAR',
          amount,
          request.reference,
          request.reference.slice(0, 20),
          request.cancelUrl,
          request.cancelUrl,
          request.successUrl,
          request.webhookUrl,
          String(isTest),
        ],
        process.env.OZOW_PRIVATE_KEY!,
      ),
    };

    const response = await fetch(`${API}/PostPaymentRequest`, {
      method: 'POST',
      headers: {
        ApiKey: process.env.OZOW_API_KEY!,
        'Content-Type': 'application/json',
        Accept: 'application/json',
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      throw new GatewayError('ozow', `Checkout failed (${response.status})`, await response.text());
    }

    const data = (await response.json()) as { url: string; paymentRequestId: string };
    return { gateway: 'ozow', redirectUrl: data.url, gatewayRef: data.paymentRequestId };
  },

  async handleWebhook(rawBody): Promise<WebhookOutcome> {
    const p = Object.fromEntries(new URLSearchParams(rawBody)) as Record<string, string>;

    const expected = hash(
      [
        p.SiteCode,
        p.TransactionId,
        p.TransactionReference,
        p.Amount,
        p.Status,
        p.Optional1 ?? '',
        p.Optional2 ?? '',
        p.Optional3 ?? '',
        p.Optional4 ?? '',
        p.Optional5 ?? '',
        p.CurrencyCode,
        p.IsTest,
        p.StatusMessage ?? '',
      ],
      process.env.OZOW_PRIVATE_KEY!,
    );

    if (expected !== (p.Hash ?? '').toLowerCase()) {
      return { status: 'ignored', reason: 'Hash mismatch' };
    }

    const common = { reference: p.TransactionReference, gatewayRef: p.TransactionId, raw: p };

    if (p.Status === 'Complete') {
      return { status: 'succeeded', ...common, amountCents: Math.round(Number(p.Amount) * 100) };
    }

    return { status: 'failed', ...common, reason: p.StatusMessage || p.Status };
  },
};
