import { createHash } from 'node:crypto';
import type {
  CheckoutRequest,
  CheckoutResult,
  PaymentGateway,
  WebhookOutcome,
} from './gateway.interface';

const LIVE = 'https://www.payfast.co.za/eng/process';
const SANDBOX = 'https://sandbox.payfast.co.za/eng/process';

function signature(fields: Record<string, string>, passphrase?: string): string {
  // PayFast signs the fields in submission order, URL-encoded, uppercase escapes.
  const body = Object.entries(fields)
    .filter(([, v]) => v !== '')
    .map(([k, v]) => `${k}=${encodeURIComponent(v.trim()).replace(/%20/g, '+')}`)
    .join('&');

  const withPass = passphrase
    ? `${body}&passphrase=${encodeURIComponent(passphrase.trim()).replace(/%20/g, '+')}`
    : body;

  return createHash('md5').update(withPass).digest('hex');
}

/** EFT, card and instant EFT via PayFast. Posts a signed form rather than redirecting. */
export const payfast: PaymentGateway = {
  id: 'payfast',
  label: 'PayFast',
  description: 'Card, EFT or instant EFT',
  supportsRefunds: false,

  async createCheckout(request: CheckoutRequest): Promise<CheckoutResult> {
    const [firstName, ...rest] = request.customer.name.split(' ');

    const fields: Record<string, string> = {
      merchant_id: process.env.PAYFAST_MERCHANT_ID!,
      merchant_key: process.env.PAYFAST_MERCHANT_KEY!,
      return_url: request.successUrl,
      cancel_url: request.cancelUrl,
      notify_url: request.webhookUrl,
      name_first: firstName,
      name_last: rest.join(' ') || firstName,
      email_address: request.customer.email,
      m_payment_id: request.reference,
      amount: (request.amountCents / 100).toFixed(2),
      item_name: request.description.slice(0, 100),
    };

    fields.signature = signature(fields, process.env.PAYFAST_PASSPHRASE);

    return {
      gateway: 'payfast',
      redirectUrl: process.env.PAYFAST_SANDBOX === 'true' ? SANDBOX : LIVE,
      gatewayRef: request.reference,
      formFields: fields,
    };
  },

  async handleWebhook(rawBody): Promise<WebhookOutcome> {
    const params = Object.fromEntries(new URLSearchParams(rawBody)) as Record<string, string>;
    const { signature: provided, ...rest } = params;

    if (signature(rest, process.env.PAYFAST_PASSPHRASE) !== provided) {
      return { status: 'ignored', reason: 'Signature mismatch' };
    }

    const reference = params.m_payment_id ?? '';
    const gatewayRef = params.pf_payment_id ?? reference;

    if (params.payment_status === 'COMPLETE') {
      return {
        status: 'succeeded',
        reference,
        gatewayRef,
        amountCents: Math.round(Number(params.amount_gross ?? 0) * 100),
        raw: params,
      };
    }

    return {
      status: 'failed',
      reference,
      gatewayRef,
      reason: params.payment_status ?? 'Payment not completed',
      raw: params,
    };
  },
};
