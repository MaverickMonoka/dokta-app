import type { GatewayId, PaymentGateway } from './gateway.interface';
import { yoco } from './yoco';
import { payfast } from './payfast';
import { ozow } from './ozow';
import { snapscan } from './snapscan';

export const gateways: Record<GatewayId, PaymentGateway> = { yoco, payfast, ozow, snapscan };

export function gateway(id: GatewayId): PaymentGateway {
  const found = gateways[id];
  if (!found) throw new Error(`Unknown payment gateway: ${id}`);
  return found;
}

/** Options to show at checkout, in the order patients are most likely to pick them. */
export const checkoutOptions = [yoco, ozow, snapscan, payfast].map((g) => ({
  id: g.id,
  label: g.label,
  description: g.description,
}));

export * from './gateway.interface';
export { yoco, payfast, ozow, snapscan };
