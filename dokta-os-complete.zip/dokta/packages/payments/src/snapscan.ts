import { createHmac } from 'node:crypto';
import type {
  CheckoutRequest,
  CheckoutResult,
  PaymentGateway,
  WebhookOutcome,
} from './gateway.interface';

/**
 * QR payment. This is the one that matters at a pharmacy counter — the
 * customer scans and pays without handing over a card.
 */
export const snapscan: PaymentGateway = {
  id: 'snapscan',
  label: 'SnapScan',
  description: 'Scan the QR code with the SnapScan app',
  supportsRefunds: false,

  async createCheckout(request: CheckoutRequest): Promise<CheckoutResult> {
    const params = new URLSearchParams({
      id: process.env.SNAPSCAN_MERCHANT_ID!,
      amount: String(request.amountCents),
      strict: 'true',
      snap_code_reference: request.reference,
    });

    // SnapScan hosts the payment page; no server call is needed to open one.
    return {
      gateway: 'snapscan',
      redirectUrl: `https://pos.snapscan.io/qr/${process.env.SNAPSCAN_MERCHANT_ID}.png?${params}`,
      gatewayRef: request.reference,
    };
  },

  async handleWebhook(rawBody, headers): Promise<WebhookOutcome> {
    const provided = headers['x-snapscan-signature'] ?? headers['authorization'] ?? '';
    const expected = createHmac('sha256', process.env.SNAPSCAN_API_KEY!)
      .update(rawBody)
      .digest('hex');

    if (!provided.includes(expected)) {
      return { status: 'ignored', reason: 'Signature mismatch' };
    }

    const payload = JSON.parse(rawBody) as {
      payment: { id: string; status: string; totalAmount: number; merchantReference?: string };
    };
    const { payment } = payload;
    const reference = payment.merchantReference ?? '';

    if (payment.status === 'completed') {
      return {
        status: 'succeeded',
        reference,
        gatewayRef: String(payment.id),
        amountCents: payment.totalAmount,
        raw: payload,
      };
    }

    return {
      status: 'failed',
      reference,
      gatewayRef: String(payment.id),
      reason: payment.status,
      raw: payload,
    };
  },
};
