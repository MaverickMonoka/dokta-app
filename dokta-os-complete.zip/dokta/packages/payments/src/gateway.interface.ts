export type GatewayId = 'yoco' | 'payfast' | 'ozow' | 'snapscan';

export interface CheckoutRequest {
  /** Amount in cents. Every gateway here charges in cents. */
  amountCents: number;
  currency: 'ZAR';
  /** Our own reference — RX-…, APT-…, ORD-…. Shown on the bank statement. */
  reference: string;
  description: string;
  customer: { name: string; email: string; phone?: string };
  successUrl: string;
  cancelUrl: string;
  webhookUrl: string;
  metadata?: Record<string, string>;
}

export interface CheckoutResult {
  gateway: GatewayId;
  /** Where to send the customer to pay. */
  redirectUrl: string;
  /** The gateway's own identifier for this attempt. */
  gatewayRef: string;
  /** Present for gateways that post a form rather than redirect (PayFast, Ozow). */
  formFields?: Record<string, string>;
}

export type WebhookOutcome =
  | { status: 'succeeded'; reference: string; gatewayRef: string; amountCents: number; raw: unknown }
  | { status: 'failed'; reference: string; gatewayRef: string; reason: string; raw: unknown }
  | { status: 'ignored'; reason: string };

export interface RefundRequest {
  gatewayRef: string;
  amountCents: number;
  reason?: string;
}

export interface RefundResult {
  refundRef: string;
  amountCents: number;
  status: 'succeeded' | 'pending' | 'failed';
}

export interface PaymentGateway {
  readonly id: GatewayId;
  readonly label: string;
  /** Shown to the patient at checkout so they know what they are choosing. */
  readonly description: string;
  readonly supportsRefunds: boolean;

  createCheckout(request: CheckoutRequest): Promise<CheckoutResult>;

  /**
   * Verifies the signature and returns what happened. Implementations must
   * treat an unverifiable payload as `ignored`, never as `succeeded`.
   */
  handleWebhook(rawBody: string, headers: Record<string, string>): Promise<WebhookOutcome>;

  refund?(request: RefundRequest): Promise<RefundResult>;
}

export class GatewayError extends Error {
  constructor(
    public readonly gateway: GatewayId,
    message: string,
    public readonly cause?: unknown,
  ) {
    super(message);
    this.name = 'GatewayError';
  }
}
