import Anthropic from '@anthropic-ai/sdk';

let client: Anthropic | null = null;

export function ai(): Anthropic {
  if (!client) client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
  return client;
}

export const MODEL = process.env.AI_MODEL ?? 'claude-sonnet-4-6';

export async function complete(system: string, prompt: string, maxTokens = 1024): Promise<string> {
  const response = await ai().messages.create({
    model: MODEL,
    max_tokens: maxTokens,
    system,
    messages: [{ role: 'user', content: prompt }],
  });

  return response.content
    .filter((block): block is Anthropic.TextBlock => block.type === 'text')
    .map((block) => block.text)
    .join('\n')
    .trim();
}

/** Asks for JSON and parses it, stripping any fencing the model adds. */
export async function completeJson<T>(system: string, prompt: string, maxTokens = 1024): Promise<T> {
  const raw = await complete(
    `${system}\n\nRespond with JSON only. No preamble, no markdown fences.`,
    prompt,
    maxTokens,
  );
  return JSON.parse(raw.replace(/```json|```/g, '').trim()) as T;
}
