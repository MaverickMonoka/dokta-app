import { complete, completeJson } from './client';

/**
 * Drafts a clinical note from what the doctor dictated. The output is always
 * a draft — the doctor signs it, and the record stores who signed.
 */
export async function draftClinicalNote(input: {
  chiefComplaint: string;
  rawNotes: string;
  patientAge?: number;
  patientSex?: string;
}): Promise<{ subjective: string; objective: string; assessment: string; plan: string }> {
  return completeJson(
    `You structure a doctor's rough consultation notes into SOAP format for a South
African practice. Use only what the doctor recorded — never invent findings,
observations or vitals. If a section has nothing recorded, write "Not recorded".`,
    `Patient: ${input.patientAge ?? '?'} year old ${input.patientSex ?? 'patient'}
Chief complaint: ${input.chiefComplaint}
Doctor's notes: ${input.rawNotes}

Return: { "subjective", "objective", "assessment", "plan" }`,
  );
}

export interface InteractionWarning {
  severity: 'severe' | 'moderate' | 'minor';
  drugs: [string, string];
  effect: string;
  action: string;
}

/**
 * Advisory only. The prescription is never blocked by this check — a clinician
 * may have good reason to prescribe anyway, and a hard block would push them
 * off the platform to prescribe on paper.
 */
export async function checkInteractions(
  prescribing: string[],
  currentMeds: string[],
  allergies: string[],
): Promise<InteractionWarning[]> {
  const { warnings } = await completeJson<{ warnings: InteractionWarning[] }>(
    `You flag drug interactions and allergy conflicts for a prescribing doctor.
Report only interactions you are confident about. An empty list is a valid and
useful answer — do not pad it. Severity is one of severe, moderate, minor.`,
    `Prescribing now: ${prescribing.join(', ')}
Already taking: ${currentMeds.join(', ') || 'none recorded'}
Allergies: ${allergies.join(', ') || 'none recorded'}

Return: { "warnings": [{ "severity", "drugs", "effect", "action" }] }`,
  );
  return warnings ?? [];
}

export async function summarisePatientHistory(history: string): Promise<string> {
  return complete(
    `Summarise a patient's record for a doctor about to start a consultation.
Six lines maximum. Lead with anything that changes how they should be treated
today: allergies, chronic conditions, recent admissions, current medication.`,
    history,
    500,
  );
}
