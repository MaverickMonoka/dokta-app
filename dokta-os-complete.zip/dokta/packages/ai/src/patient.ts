import { complete, completeJson } from './client';

const TRIAGE_SYSTEM = `You are DOKTA's symptom assistant for patients in South Africa.
You do not diagnose and you never name a specific condition as fact.
Your job is to help someone decide how urgently to see a person.
Escalate to emergency for: chest pain, difficulty breathing, stroke signs (face droop,
arm weakness, slurred speech), uncontrolled bleeding, seizure, or a baby under 3 months
with fever. Write plainly, at a Grade 8 reading level. Do not use medical jargon
without explaining it.`;

export interface TriageResult {
  urgency: 'emergency' | 'same_day' | 'within_days' | 'self_care';
  summary: string;
  /** Things the person should watch for and act on. */
  redFlags: string[];
  suggestedSpeciality: string;
  questionsForTheDoctor: string[];
}

export async function triageSymptoms(input: {
  symptoms: string[];
  duration: string;
  age?: number;
  chronicConditions?: string[];
}): Promise<TriageResult> {
  return completeJson<TriageResult>(
    TRIAGE_SYSTEM,
    `Symptoms: ${input.symptoms.join(', ')}
Duration: ${input.duration}
Age: ${input.age ?? 'not given'}
Known conditions: ${input.chronicConditions?.join(', ') || 'none recorded'}

Return: { "urgency", "summary", "redFlags", "suggestedSpeciality", "questionsForTheDoctor" }`,
  );
}

export async function explainMedicine(name: string, instructions: string): Promise<string> {
  return complete(
    `Explain medication to a patient in South Africa in plain English, under 120 words.
Cover what it is for, how to take it, and the two most common side effects.
End with: "Call your doctor or pharmacist if you are unsure."`,
    `Medicine: ${name}. Doctor's instructions: ${instructions}`,
    400,
  );
}
