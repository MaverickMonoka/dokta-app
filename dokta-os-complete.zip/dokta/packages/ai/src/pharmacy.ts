import { completeJson } from './client';

export interface DemandForecast {
  medicineId: string;
  medicineName: string;
  predictedUnits30Days: number;
  recommendedOrderQty: number;
  confidence: 'high' | 'medium' | 'low';
  reasoning: string;
}

/**
 * Forecasts from the pharmacy's own sales history. Seasonal illness in South
 * Africa peaks May–August, so the model is told the current month explicitly.
 */
export async function forecastDemand(input: {
  history: { medicineId: string; name: string; unitsByMonth: number[] }[];
  month: number;
}): Promise<DemandForecast[]> {
  const { forecasts } = await completeJson<{ forecasts: DemandForecast[] }>(
    `You forecast pharmacy stock demand in South Africa. Respiratory and flu lines
peak May to August. Chronic medication is steady month to month. Base every
number on the history given — if a line has too little history, say so and set
confidence to low rather than guessing.`,
    `Current month: ${input.month}
History (units per month, oldest first):
${input.history.map((h) => `${h.medicineId} | ${h.name} | ${h.unitsByMonth.join(', ')}`).join('\n')}

Return: { "forecasts": [{ "medicineId", "medicineName", "predictedUnits30Days", "recommendedOrderQty", "confidence", "reasoning" }] }`,
    2048,
  );
  return forecasts ?? [];
}

export interface ExpiryAction {
  batchNumber: string;
  daysToExpiry: number;
  action: 'discount' | 'transfer' | 'return_to_supplier' | 'write_off' | 'sell_through';
  note: string;
}

export async function planExpiries(
  batches: { batchNumber: string; name: string; quantity: number; expiryDate: string; monthlyVelocity: number }[],
): Promise<ExpiryAction[]> {
  const { actions } = await completeJson<{ actions: ExpiryAction[] }>(
    `You advise a pharmacy on stock approaching expiry. Compare quantity against
monthly sales velocity: if it will sell through in time, say so and leave it.
Suppliers generally accept returns at 6 months to expiry, not later.`,
    `Today: ${new Date().toISOString().slice(0, 10)}
Batches:
${batches.map((b) => `${b.batchNumber} | ${b.name} | qty ${b.quantity} | expires ${b.expiryDate} | sells ${b.monthlyVelocity}/month`).join('\n')}

Return: { "actions": [{ "batchNumber", "daysToExpiry", "action", "note" }] }`,
    2048,
  );
  return actions ?? [];
}
