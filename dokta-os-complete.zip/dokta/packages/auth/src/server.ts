import { createServerClient, type CookieOptions } from '@supabase/ssr';
import { cookies } from 'next/headers';

export function supabaseServer() {
  const store = cookies();

  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        get: (name: string) => store.get(name)?.value,
        set: (name: string, value: string, options: CookieOptions) => {
          try {
            store.set({ name, value, ...options });
          } catch {
            // Server Components cannot set cookies; middleware refreshes instead.
          }
        },
        remove: (name: string, options: CookieOptions) => {
          try {
            store.set({ name, value: '', ...options });
          } catch {
            /* see above */
          }
        },
      },
    },
  );
}

/**
 * Service-role client. Bypasses RLS — only ever call this from server code
 * that has already authorised the caller.
 */
export function supabaseAdmin() {
  const { createClient } = require('@supabase/supabase-js');
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { persistSession: false, autoRefreshToken: false } },
  );
}
