import { redirect } from 'next/navigation';
import { db } from '@dokta/database';
import { can, homeRouteFor, type Role } from '@dokta/shared';
import { supabaseServer } from './server';

export interface Session {
  id: string;
  name: string;
  email: string;
  role: Role;
  avatarUrl: string | null;
}

/** Current signed-in user, or null. Safe to call on any server component. */
export async function getSession(): Promise<Session | null> {
  const supabase = supabaseServer();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return null;

  const profile = await db.user.findUnique({
    where: { id: user.id },
    select: { id: true, name: true, email: true, role: true, avatarUrl: true, isActive: true },
  });

  if (!profile || !profile.isActive) return null;

  return {
    id: profile.id,
    name: profile.name,
    email: profile.email,
    role: profile.role as Role,
    avatarUrl: profile.avatarUrl,
  };
}

/** Session or bounce to sign-in, preserving where the person was headed. */
export async function requireSession(returnTo = '/'): Promise<Session> {
  const session = await getSession();
  if (!session) redirect(`/sign-in?next=${encodeURIComponent(returnTo)}`);
  return session;
}

/** Session plus a capability check. Wrong role lands on their own home. */
export async function requireCapability(capability: string, returnTo = '/'): Promise<Session> {
  const session = await requireSession(returnTo);
  if (!can(session.role, capability)) redirect(homeRouteFor[session.role]);
  return session;
}
