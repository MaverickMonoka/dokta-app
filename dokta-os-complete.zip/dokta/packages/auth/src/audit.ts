import { headers } from 'next/headers';
import { db } from '@dokta/database';

type AuditAction = 'read' | 'create' | 'update' | 'delete' | 'export';

interface AuditInput {
  actorId?: string | null;
  action: AuditAction;
  entity: string;
  entityId?: string;
  /** The person whose health information was touched. */
  subjectId?: string;
  lawfulBasis?: string;
  metadata?: Record<string, unknown>;
}

/**
 * POPIA s14 requires a record of every access to personal health information.
 * Call this on every read of another person's records — not only on writes.
 * Failures are swallowed so an audit outage never blocks clinical care, but
 * they are surfaced to the server log for follow-up.
 */
export async function audit(input: AuditInput): Promise<void> {
  try {
    const h = headers();
    await db.auditLog.create({
      data: {
        actorId: input.actorId ?? null,
        action: input.action,
        entity: input.entity,
        entityId: input.entityId,
        subjectId: input.subjectId,
        lawfulBasis: input.lawfulBasis ?? 'consent',
        ipAddress: h.get('x-forwarded-for')?.split(',')[0]?.trim() ?? null,
        userAgent: h.get('user-agent'),
        metadata: input.metadata as never,
      },
    });
  } catch (error) {
    console.error('[audit] failed to write access log', { entity: input.entity, error });
  }
}
