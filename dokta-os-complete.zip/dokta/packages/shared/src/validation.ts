import { z } from 'zod';

export const saPhone = z
  .string()
  .regex(/^(\+27|0)[6-8][0-9]{8}$/, 'Enter a South African mobile number');

export const hpcsaNumber = z
  .string()
  .regex(/^(MP|DP|PS|OT|PT)\s?\d{5,7}$/i, 'Enter a valid HPCSA registration number');

export const signUpSchema = z.object({
  name: z.string().min(2, 'Enter your full name'),
  email: z.string().email('Enter a valid email address'),
  phone: saPhone,
  password: z.string().min(10, 'Use at least 10 characters'),
  role: z.enum(['PATIENT', 'DOCTOR', 'PHARMACY']),
});

export const bookAppointmentSchema = z.object({
  doctorId: z.string().uuid(),
  scheduledFor: z.coerce.date().min(new Date(), 'Choose a future time'),
  type: z.enum(['VIDEO', 'IN_PERSON', 'HOME_VISIT']),
  reasonForVisit: z.string().min(3, 'Tell the doctor why you are booking'),
  symptoms: z.array(z.string()).default([]),
});

export const prescriptionItemSchema = z.object({
  medicineId: z.string().uuid().optional(),
  medicineName: z.string().min(2),
  strength: z.string().optional(),
  dosage: z.string().min(1, 'Dosage is required'),
  frequency: z.string().min(1, 'Frequency is required'),
  durationDays: z.number().int().positive().optional(),
  quantity: z.number().int().positive().default(1),
  instructions: z.string().optional(),
  substitutable: z.boolean().default(true),
});

export const issuePrescriptionSchema = z.object({
  patientId: z.string().uuid(),
  consultationId: z.string().uuid().optional(),
  pharmacyId: z.string().uuid().optional(),
  repeats: z.number().int().min(0).max(5).default(0),
  validUntil: z.coerce.date(),
  notes: z.string().optional(),
  items: z.array(prescriptionItemSchema).min(1, 'Add at least one medicine'),
});

export type SignUpInput = z.infer<typeof signUpSchema>;
export type BookAppointmentInput = z.infer<typeof bookAppointmentSchema>;
export type IssuePrescriptionInput = z.infer<typeof issuePrescriptionSchema>;
