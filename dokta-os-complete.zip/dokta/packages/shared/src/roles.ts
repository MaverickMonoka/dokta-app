export type Role = 'PATIENT' | 'DOCTOR' | 'PHARMACY' | 'ADMIN';

/**
 * Capability strings are the only thing the UI and API check. Roles map to
 * capabilities here, so adding a role never means hunting for `role === 'X'`.
 */
export const capabilities: Record<Role, readonly string[]> = {
  PATIENT: [
    'profile:self',
    'doctor:search',
    'appointment:book',
    'appointment:cancel:own',
    'consultation:join',
    'document:upload:own',
    'prescription:read:own',
    'order:create',
    'payment:pay',
    'health:read:own',
  ],
  DOCTOR: [
    'profile:self',
    'availability:manage',
    'queue:read',
    'consultation:conduct',
    'consultation:note',
    'prescription:issue',
    'invoice:generate',
    'earnings:read:own',
    'patient:read:assigned',
  ],
  PHARMACY: [
    'profile:self',
    'pos:operate',
    'prescription:read:assigned',
    'prescription:dispense',
    'inventory:manage',
    'supplier:manage',
    'order:fulfil',
    'report:sales',
  ],
  ADMIN: [
    'user:manage',
    'provider:approve',
    'payment:read:all',
    'payment:refund',
    'analytics:read',
    'audit:read',
    'compliance:manage',
  ],
};

export function can(role: Role | undefined | null, capability: string): boolean {
  if (!role) return false;
  if (role === 'ADMIN') return true;
  return capabilities[role].includes(capability);
}

export const homeRouteFor: Record<Role, string> = {
  PATIENT: '/dashboard',
  DOCTOR: '/doctor',
  PHARMACY: '/pharmacy',
  ADMIN: '/admin',
};
