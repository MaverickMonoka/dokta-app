/**
 * DOKTA brand tokens. Single source of truth — Tailwind, React Native and any
 * generated PDF read from here so a colour is never redefined by hand.
 */

export const brand = {
  name: 'DOKTA',
  position: 'The Healthcare Operating System for Africa',
  domain: 'dokta.africa',
} as const;

export const colors = {
  navy: '#0B2137',
  navyRaised: '#0F2E4C',
  navySunken: '#071726',
  green: '#059669',
  greenSoft: '#D1FAE5',
  red: '#DC2626',
  redSoft: '#FEE2E2',
  amber: '#D97706',
  white: '#FFFFFF',
  background: '#F8FAFC',
  border: '#E2E8F0',
  muted: '#94A3B8',
  ink: '#0F172A',
} as const;

export const fonts = {
  display: 'Plus Jakarta Sans',
  body: 'Inter',
} as const;

/** Semantic status colours used across web, mobile and print. */
export const statusColor: Record<string, string> = {
  CONFIRMED: colors.green,
  IN_PROGRESS: colors.green,
  COMPLETED: colors.green,
  DELIVERED: colors.green,
  PAID: colors.green,
  SUCCEEDED: colors.green,
  REQUESTED: colors.amber,
  PENDING: colors.amber,
  AWAITING_PAYMENT: colors.amber,
  PICKING: colors.amber,
  CANCELLED: colors.red,
  FAILED: colors.red,
  NO_SHOW: colors.red,
  REJECTED: colors.red,
};
