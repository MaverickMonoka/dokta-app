const zar = new Intl.NumberFormat('en-ZA', {
  style: 'currency',
  currency: 'ZAR',
  minimumFractionDigits: 2,
});

export function money(amount: number | string): string {
  return zar.format(Number(amount));
}

/** Rands to cents — every gateway in this platform charges in cents. */
export function toCents(amount: number | string): number {
  return Math.round(Number(amount) * 100);
}

export function fromCents(cents: number): number {
  return cents / 100;
}

export const VAT_RATE = 0.15;

export function withVat(exclusive: number) {
  const vat = Math.round(exclusive * VAT_RATE * 100) / 100;
  return { exclusive, vat, inclusive: Math.round((exclusive + vat) * 100) / 100 };
}

export function shortDate(date: Date | string): string {
  return new Intl.DateTimeFormat('en-ZA', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  }).format(new Date(date));
}

export function time(date: Date | string): string {
  return new Intl.DateTimeFormat('en-ZA', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).format(new Date(date));
}

/** Normalises 073…, 073 123 4567 and +27 73… to E.164 for SMS and WhatsApp. */
export function toE164(phone: string): string {
  const digits = phone.replace(/\D/g, '');
  if (digits.startsWith('27')) return `+${digits}`;
  if (digits.startsWith('0')) return `+27${digits.slice(1)}`;
  return `+${digits}`;
}

const PREFIX: Record<string, string> = {
  appointment: 'APT',
  prescription: 'RX',
  order: 'ORD',
  payment: 'PAY',
  sale: 'POS',
};

/** Human-readable reference, e.g. RX-8K4M2P-2609 — safe to read over a phone. */
export function reference(kind: keyof typeof PREFIX, at = new Date()): string {
  const alphabet = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789'; // no I/L/O/0/1
  let body = '';
  for (let i = 0; i < 6; i += 1) {
    body += alphabet[Math.floor(Math.random() * alphabet.length)];
  }
  const stamp = `${String(at.getDate()).padStart(2, '0')}${String(at.getMonth() + 1).padStart(2, '0')}`;
  return `${PREFIX[kind]}-${body}-${stamp}`;
}
