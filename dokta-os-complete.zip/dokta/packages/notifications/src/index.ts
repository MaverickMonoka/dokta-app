import { db } from '@dokta/database';
import { templates, type TemplateName } from './templates';
import { sendEmail } from './channels/email';
import { sendSms } from './channels/sms';
import { sendWhatsApp } from './channels/whatsapp';
import { sendPush } from './channels/push';

export type Channel = 'EMAIL' | 'SMS' | 'WHATSAPP' | 'PUSH' | 'IN_APP';

/**
 * Sends one event across the channels asked for and records every attempt.
 * Channels are independent: an SMS failure must not stop the push notification,
 * because a patient missing a "medication ready" message is the real cost.
 */
export async function notify<T extends TemplateName>(options: {
  userId: string;
  template: T;
  data: Parameters<(typeof templates)[T]>[0];
  channels?: Channel[];
}): Promise<void> {
  const { userId, template, channels = ['PUSH', 'IN_APP'] } = options;

  const user = await db.user.findUnique({
    where: { id: userId },
    select: { email: true, phone: true, devices: { select: { pushToken: true } } },
  });
  if (!user) return;

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const message = (templates[template] as any)(options.data);

  await Promise.allSettled(
    channels.map(async (channel) => {
      const record = await db.notification.create({
        data: {
          userId,
          channel,
          template,
          title: message.title,
          body: message.body,
          data: options.data as never,
        },
      });

      try {
        if (channel === 'EMAIL' && user.email) await sendEmail(user.email, message);
        if (channel === 'SMS' && user.phone) await sendSms(user.phone, message);
        if (channel === 'WHATSAPP' && user.phone) await sendWhatsApp(user.phone, message);
        if (channel === 'PUSH') await sendPush(user.devices.map((d) => d.pushToken), message);

        await db.notification.update({
          where: { id: record.id },
          data: { status: 'SENT', sentAt: new Date() },
        });
      } catch (error) {
        await db.notification.update({ where: { id: record.id }, data: { status: 'FAILED' } });
        console.error(`[notify] ${channel} failed for ${template}`, error);
      }
    }),
  );
}

export { templates, type TemplateName } from './templates';
export { sendEmail, sendSms, sendWhatsApp, sendPush };
