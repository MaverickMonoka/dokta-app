import { toE164 } from '@dokta/shared';
import type { RenderedMessage } from '../templates';

/** SMS is the fallback that always lands — many patients have no data. */
export async function sendSms(to: string, message: RenderedMessage): Promise<string> {
  const response = await fetch('https://platform.clickatell.com/messages', {
    method: 'POST',
    headers: {
      Authorization: process.env.CLICKATELL_API_KEY!,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      messages: [{ channel: 'sms', to: toE164(to), content: `${message.title}: ${message.body}` }],
    }),
  });

  if (!response.ok) throw new Error(`SMS failed (${response.status})`);
  const data = (await response.json()) as { messages: { apiMessageId: string }[] };
  return data.messages[0]?.apiMessageId ?? '';
}
