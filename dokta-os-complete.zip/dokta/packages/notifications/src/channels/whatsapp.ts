import { toE164 } from '@dokta/shared';
import type { RenderedMessage } from '../templates';

/**
 * WhatsApp only allows free-form text within 24 hours of the patient's last
 * message. Outside that window Meta requires a pre-approved template, so the
 * template name must be registered in Business Manager before it will send.
 */
export async function sendWhatsApp(
  to: string,
  message: RenderedMessage,
  approvedTemplate?: { name: string; params: string[] },
): Promise<string> {
  const body = approvedTemplate
    ? {
        messaging_product: 'whatsapp',
        to: toE164(to),
        type: 'template',
        template: {
          name: approvedTemplate.name,
          language: { code: 'en' },
          components: [
            {
              type: 'body',
              parameters: approvedTemplate.params.map((text) => ({ type: 'text', text })),
            },
          ],
        },
      }
    : {
        messaging_product: 'whatsapp',
        to: toE164(to),
        type: 'text',
        text: { body: `*${message.title}*\n\n${message.body}` },
      };

  const response = await fetch(
    `https://graph.facebook.com/v20.0/${process.env.WHATSAPP_PHONE_ID}/messages`,
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${process.env.WHATSAPP_TOKEN}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    },
  );

  if (!response.ok) throw new Error(`WhatsApp failed (${response.status})`);
  const data = (await response.json()) as { messages: { id: string }[] };
  return data.messages[0]?.id ?? '';
}
