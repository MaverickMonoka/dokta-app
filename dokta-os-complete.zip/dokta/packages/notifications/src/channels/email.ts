import type { RenderedMessage } from '../templates';

export async function sendEmail(to: string, message: RenderedMessage): Promise<string> {
  const response = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${process.env.RESEND_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      from: `DOKTA <${process.env.NOTIFY_FROM_EMAIL ?? 'no-reply@dokta.africa'}>`,
      to,
      subject: message.title,
      text: message.body,
    }),
  });

  if (!response.ok) throw new Error(`Email failed (${response.status})`);
  const data = (await response.json()) as { id: string };
  return data.id;
}
