import type { RenderedMessage } from '../templates';

export async function sendPush(
  tokens: string[],
  message: RenderedMessage,
  data?: Record<string, string>,
): Promise<void> {
  if (tokens.length === 0) return;

  const response = await fetch('https://exp.host/--/api/v2/push/send', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${process.env.EXPO_ACCESS_TOKEN}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(
      tokens.map((to) => ({ to, title: message.title, body: message.body, data, sound: 'default' })),
    ),
  });

  if (!response.ok) throw new Error(`Push failed (${response.status})`);
}
