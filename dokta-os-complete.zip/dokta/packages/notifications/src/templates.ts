import { shortDate, time } from '@dokta/shared';

export interface RenderedMessage {
  title: string;
  body: string;
}

/**
 * Every message the platform sends lives here. One template renders across
 * email, SMS, WhatsApp and push, so a patient never gets two different
 * wordings for the same event.
 */
export const templates = {
  appointment_confirmed: (v: { doctorName: string; when: Date; reference: string }): RenderedMessage => ({
    title: 'Appointment confirmed',
    body: `Your appointment with ${v.doctorName} is confirmed for ${shortDate(v.when)} at ${time(v.when)}. Reference ${v.reference}.`,
  }),

  appointment_reminder: (v: { doctorName: string; when: Date }): RenderedMessage => ({
    title: 'Appointment tomorrow',
    body: `Your appointment with ${v.doctorName} is tomorrow at ${time(v.when)}. Open DOKTA a few minutes early to test your camera.`,
  }),

  appointment_cancelled: (v: { doctorName: string; when: Date; reason?: string }): RenderedMessage => ({
    title: 'Appointment cancelled',
    body: `Your appointment with ${v.doctorName} on ${shortDate(v.when)} has been cancelled.${v.reason ? ` Reason: ${v.reason}.` : ''} Any payment is refunded within 5 working days.`,
  }),

  prescription_issued: (v: { doctorName: string; reference: string }): RenderedMessage => ({
    title: 'Prescription ready',
    body: `${v.doctorName} has issued your prescription ${v.reference}. Send it to a pharmacy in the DOKTA app to have it dispensed.`,
  }),

  prescription_ready: (v: { pharmacyName: string; reference: string }): RenderedMessage => ({
    title: 'Medication ready for collection',
    body: `Your medication is ready for collection at ${v.pharmacyName}. Bring reference ${v.reference} and your ID.`,
  }),

  order_out_for_delivery: (v: { pharmacyName: string; reference: string }): RenderedMessage => ({
    title: 'Medication on the way',
    body: `Your order ${v.reference} from ${v.pharmacyName} is out for delivery. The driver will call you on arrival.`,
  }),

  payment_received: (v: { amount: string; reference: string }): RenderedMessage => ({
    title: 'Payment received',
    body: `We received ${v.amount} for ${v.reference}. Your receipt is in the app under Payments.`,
  }),

  payment_failed: (v: { amount: string; reference: string }): RenderedMessage => ({
    title: 'Payment did not go through',
    body: `Your payment of ${v.amount} for ${v.reference} was declined by the bank. Open DOKTA to try another payment method.`,
  }),

  stock_low: (v: { medicineName: string; onHand: number }): RenderedMessage => ({
    title: 'Stock running low',
    body: `${v.medicineName} is down to ${v.onHand} units. Place a supplier order to avoid running out.`,
  }),

  provider_verified: (v: { name: string }): RenderedMessage => ({
    title: 'Verification approved',
    body: `${v.name}, your DOKTA profile is verified. Patients can now find and book you.`,
  }),
} as const;

export type TemplateName = keyof typeof templates;
