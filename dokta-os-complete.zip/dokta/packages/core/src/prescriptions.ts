import { db } from '@dokta/database';
import { reference } from '@dokta/shared';
import { notify } from '@dokta/notifications';
import { conflict, forbidden, notFound } from './errors';

export interface PrescriptionLine {
  medicineId?: string;
  medicineName: string;
  strength?: string;
  dosage: string;
  frequency: string;
  durationDays?: number;
  quantity: number;
  instructions?: string;
  substitutable?: boolean;
}

/**
 * Issues a script. Validity follows South African practice: six months for a
 * repeatable script, thirty days for S5 and S6 which cannot be repeated at all.
 */
export async function issuePrescription(input: {
  doctorId: string;
  patientId: string;
  consultationId?: string;
  pharmacyId?: string;
  repeats?: number;
  notes?: string;
  items: PrescriptionLine[];
  /**
   * Caller's preferred expiry. Ignored for S5/S6, which are capped at 30 days
   * by regulation regardless of what the prescriber asks for.
   */
  validUntil?: Date;
}) {
  if (input.items.length === 0) throw conflict('Add at least one medicine');

  const medicineIds = input.items.map((i) => i.medicineId).filter(Boolean) as string[];
  const medicines = medicineIds.length
    ? await db.medicine.findMany({
        where: { id: { in: medicineIds } },
        select: { id: true, schedule: true },
      })
    : [];

  const restricted = medicines.some((m) => m.schedule === 'S5' || m.schedule === 'S6');
  const repeats = restricted ? 0 : Math.min(input.repeats ?? 0, 5);

  const capped = new Date();
  capped.setMonth(capped.getMonth() + 1);

  const requested = input.validUntil ?? (() => {
    const d = new Date();
    d.setMonth(d.getMonth() + 6);
    return d;
  })();

  const validUntil = restricted ? capped : requested;

  const prescription = await db.prescription.create({
    data: {
      reference: reference('prescription'),
      doctorId: input.doctorId,
      patientId: input.patientId,
      consultationId: input.consultationId,
      pharmacyId: input.pharmacyId,
      status: input.pharmacyId ? 'SENT_TO_PHARMACY' : 'ISSUED',
      repeats,
      validUntil,
      notes: input.notes,
      items: {
        create: input.items.map((item) => ({
          medicineId: item.medicineId,
          medicineName: item.medicineName,
          strength: item.strength,
          dosage: item.dosage,
          frequency: item.frequency,
          durationDays: item.durationDays,
          quantity: item.quantity,
          instructions: item.instructions,
          substitutable: item.substitutable ?? true,
        })),
      },
    },
    include: {
      items: true,
      patient: { select: { userId: true } },
      doctor: { select: { user: { select: { name: true } } } },
    },
  });

  await notify({
    userId: prescription.patient.userId,
    template: 'prescription_issued',
    data: { doctorName: prescription.doctor.user.name, reference: prescription.reference },
    channels: ['PUSH', 'IN_APP', 'SMS'],
  });

  return prescription;
}

export async function sendToPharmacy(prescriptionId: string, pharmacyId: string, patientUserId: string) {
  const prescription = await db.prescription.findUnique({
    where: { id: prescriptionId },
    include: { patient: { select: { userId: true } } },
  });
  if (!prescription) throw notFound('Prescription');
  if (prescription.patient.userId !== patientUserId) throw forbidden('This is not your prescription');
  if (prescription.validUntil < new Date()) throw conflict('This prescription has expired');

  return db.prescription.update({
    where: { id: prescriptionId },
    data: { pharmacyId, status: 'SENT_TO_PHARMACY' },
  });
}

/** The pharmacy's work queue: scripts waiting on them, oldest first. */
export async function pharmacyQueue(pharmacyId: string) {
  return db.prescription.findMany({
    where: { pharmacyId, status: { in: ['SENT_TO_PHARMACY', 'APPROVED'] } },
    orderBy: { createdAt: 'asc' },
    include: {
      items: true,
      doctor: { select: { speciality: true, user: { select: { name: true } } } },
      patient: {
        select: { id: true, allergies: true, user: { select: { name: true, phone: true } } },
      },
    },
  });
}

/** Kept for callers written against the earlier name. */
export type PrescriptionItemInput = PrescriptionLine;
