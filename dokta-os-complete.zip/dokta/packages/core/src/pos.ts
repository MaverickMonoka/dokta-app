import { db } from '@dokta/database';
import { VAT_RATE, reference } from '@dokta/shared';
import { conflict } from './errors';
import { deductStock, warnIfLow } from './inventory';

export interface CartLine {
  inventoryId: string;
  medicineId: string;
  description: string;
  quantity: number;
  unitPrice: number;
}

export interface Totals {
  subtotal: number;
  discount: number;
  vat: number;
  total: number;
}

/**
 * VAT-inclusive pricing, which is how medicine is priced on the shelf in South
 * Africa. The VAT figure is backed out of the total for the receipt rather
 * than added on top, so what the customer is charged matches the shelf label.
 */
export function totalCart(lines: CartLine[], discount = 0): Totals {
  const gross = lines.reduce((sum, l) => sum + l.unitPrice * l.quantity, 0);
  const total = Math.max(0, round(gross - discount));
  const vat = round(total - total / (1 + VAT_RATE));

  return { subtotal: round(gross), discount: round(discount), vat, total };
}

const round = (n: number) => Math.round(n * 100) / 100;

export async function ringUpSale(input: {
  pharmacyId: string;
  cashierId: string;
  lines: CartLine[];
  discount?: number;
  gateway: 'YOCO' | 'SNAPSCAN' | 'CASH' | 'PAYFAST' | 'OZOW';
  tendered?: number;
}) {
  if (input.lines.length === 0) throw conflict('The cart is empty');

  const totals = totalCart(input.lines, input.discount ?? 0);

  if (input.gateway === 'CASH') {
    if (input.tendered == null) throw conflict('Enter the amount tendered');
    if (input.tendered < totals.total) throw conflict('Amount tendered is less than the total');
  }

  // Stock comes off before the sale is written: if a line cannot be filled the
  // whole sale fails rather than leaving a receipt for goods not in the shop.
  for (const line of input.lines) {
    await deductStock(line.inventoryId, line.quantity);
  }

  const sale = await db.sale.create({
    data: {
      reference: reference('sale'),
      pharmacyId: input.pharmacyId,
      cashierId: input.cashierId,
      lines: input.lines as never,
      subtotal: totals.subtotal,
      discount: totals.discount,
      vat: totals.vat,
      total: totals.total,
      gateway: input.gateway,
      tendered: input.tendered,
      change: input.tendered != null ? round(input.tendered - totals.total) : null,
    },
  });

  await Promise.all(input.lines.map((l) => warnIfLow(input.pharmacyId, l.inventoryId)));

  return { sale, totals };
}

/** Reverses a sale and returns the stock. Used for a mis-scan at the counter. */
export async function voidSale(saleId: string, pharmacyId: string) {
  const sale = await db.sale.findFirst({ where: { id: saleId, pharmacyId } });
  if (!sale) throw conflict('Sale not found for this pharmacy');
  if (sale.voidedAt) throw conflict('This sale was already voided');

  const lines = sale.lines as unknown as CartLine[];

  await db.$transaction(async (tx) => {
    for (const line of lines) {
      await tx.inventoryItem.update({
        where: { id: line.inventoryId },
        data: { stockOnHand: { increment: line.quantity } },
      });
    }
    await tx.sale.update({ where: { id: saleId }, data: { voidedAt: new Date() } });
  });
}

export async function todaysTakings(pharmacyId: string) {
  const start = new Date();
  start.setHours(0, 0, 0, 0);

  const [counter, online] = await Promise.all([
    db.sale.aggregate({
      where: { pharmacyId, createdAt: { gte: start }, voidedAt: null },
      _sum: { total: true },
      _count: true,
    }),
    db.order.aggregate({
      where: { pharmacyId, placedAt: { gte: start }, status: { notIn: ['CANCELLED', 'CART'] } },
      _sum: { total: true },
      _count: true,
    }),
  ]);

  return {
    counterTotal: Number(counter._sum.total ?? 0),
    counterCount: counter._count,
    onlineTotal: Number(online._sum.total ?? 0),
    onlineCount: online._count,
    total: Number(counter._sum.total ?? 0) + Number(online._sum.total ?? 0),
  };
}
