import { db } from '@dokta/database';
import { reference } from '@dokta/shared';
import { notify } from '@dokta/notifications';
import { conflict, notFound } from './errors';
import { deductStock, warnIfLow } from './inventory';
import { totalCart, type CartLine } from './pos';

/**
 * Turns an approved prescription into a priced order and takes the stock off
 * the shelf. This is the point where a script becomes something to be paid for.
 */
export async function dispensePrescription(input: {
  prescriptionId: string;
  pharmacyId: string;
  fulfilment: 'COLLECTION' | 'DELIVERY';
  deliveryAddress?: string;
  /** Pharmacist substitutions, keyed by prescription item id. */
  substitutions?: Record<string, string>;
}) {
  const prescription = await db.prescription.findUnique({
    where: { id: input.prescriptionId },
    include: { items: true, patient: { select: { id: true, userId: true } } },
  });
  if (!prescription) throw notFound('Prescription');
  if (prescription.pharmacyId !== input.pharmacyId) throw conflict('This script was sent elsewhere');
  if (prescription.validUntil < new Date()) throw conflict('This prescription has expired');
  if (prescription.status === 'DISPENSED' || prescription.status === 'COLLECTED') {
    if (prescription.repeatsUsed >= prescription.repeats) {
      throw conflict('No repeats left on this prescription');
    }
  }

  const pharmacy = await db.pharmacy.findUniqueOrThrow({
    where: { id: input.pharmacyId },
    select: { name: true, deliveryFee: true, offersDelivery: true },
  });
  if (input.fulfilment === 'DELIVERY' && !pharmacy.offersDelivery) {
    throw conflict('This pharmacy does not deliver');
  }

  const lines: CartLine[] = [];

  for (const item of prescription.items) {
    const medicineId = input.substitutions?.[item.id] ?? item.medicineId;
    if (!medicineId) throw conflict(`${item.medicineName} is not linked to a product. Pick a substitute.`);

    if (input.substitutions?.[item.id] && !item.substitutable) {
      throw conflict(`${item.medicineName} was marked no-substitution by the doctor`);
    }

    const inventory = await db.inventoryItem.findUnique({
      where: { pharmacyId_medicineId: { pharmacyId: input.pharmacyId, medicineId } },
      include: { medicine: { select: { name: true, strength: true } } },
    });
    if (!inventory) throw conflict(`${item.medicineName} is not stocked here`);

    lines.push({
      inventoryId: inventory.id,
      medicineId,
      description: `${inventory.medicine.name} ${inventory.medicine.strength ?? ''}`.trim(),
      quantity: item.quantity,
      unitPrice: Number(inventory.sellingPrice),
    });
  }

  for (const line of lines) await deductStock(line.inventoryId, line.quantity);

  const deliveryFee = input.fulfilment === 'DELIVERY' ? Number(pharmacy.deliveryFee) : 0;
  const totals = totalCart(lines);

  const order = await db.order.create({
    data: {
      reference: reference('order'),
      patientId: prescription.patient.id,
      pharmacyId: input.pharmacyId,
      prescriptionId: prescription.id,
      status: 'AWAITING_PAYMENT',
      fulfilment: input.fulfilment,
      deliveryAddress: input.deliveryAddress,
      deliveryFee,
      subtotal: totals.subtotal,
      vat: totals.vat,
      total: totals.total + deliveryFee,
      placedAt: new Date(),
      items: {
        create: lines.map((l) => ({
          medicineId: l.medicineId,
          description: l.description,
          quantity: l.quantity,
          unitPrice: l.unitPrice,
          lineTotal: Math.round(l.unitPrice * l.quantity * 100) / 100,
        })),
      },
    },
  });

  await db.prescription.update({
    where: { id: prescription.id },
    data: {
      status: 'DISPENSED',
      dispensedAt: new Date(),
      repeatsUsed: { increment: prescription.status === 'DISPENSED' ? 1 : 0 },
    },
  });

  await Promise.all(lines.map((l) => warnIfLow(input.pharmacyId, l.inventoryId)));

  await notify({
    userId: prescription.patient.userId,
    template: 'prescription_ready',
    data: { pharmacyName: pharmacy.name, reference: order.reference },
    channels: ['PUSH', 'IN_APP', 'SMS', 'WHATSAPP'],
  });

  return order;
}

export async function advanceOrder(orderId: string, status: 'PICKING' | 'READY_FOR_COLLECTION' | 'OUT_FOR_DELIVERY' | 'DELIVERED') {
  const order = await db.order.update({
    where: { id: orderId },
    data: { status, deliveredAt: status === 'DELIVERED' ? new Date() : undefined },
    include: {
      pharmacy: { select: { name: true } },
      patient: { select: { userId: true } },
    },
  });

  if (status === 'OUT_FOR_DELIVERY') {
    await notify({
      userId: order.patient.userId,
      template: 'order_out_for_delivery',
      data: { pharmacyName: order.pharmacy.name, reference: order.reference },
      channels: ['PUSH', 'IN_APP', 'SMS'],
    });
  }

  return order;
}
