import { db } from '@dokta/database';
import { reference } from '@dokta/shared';
import { notify } from '@dokta/notifications';
import { conflict, forbidden, notFound } from './errors';

/**
 * Free slots for a doctor on a given day. Derived from the weekly availability
 * pattern minus anything already booked, so a doctor changing their hours does
 * not need existing bookings rewritten.
 */
export async function availableSlots(doctorId: string, day: Date): Promise<Date[]> {
  const doctor = await db.doctor.findUnique({
    where: { id: doctorId },
    select: { verification: true, availability: { where: { isActive: true } } },
  });
  if (!doctor) throw notFound('Doctor');
  if (doctor.verification !== 'VERIFIED') return [];

  const windows = doctor.availability.filter((a) => a.weekday === day.getDay());
  if (windows.length === 0) return [];

  const dayStart = new Date(day);
  dayStart.setHours(0, 0, 0, 0);
  const dayEnd = new Date(dayStart);
  dayEnd.setDate(dayEnd.getDate() + 1);

  const booked = await db.appointment.findMany({
    where: {
      doctorId,
      scheduledFor: { gte: dayStart, lt: dayEnd },
      status: { notIn: ['CANCELLED', 'NO_SHOW'] },
    },
    select: { scheduledFor: true },
  });
  const taken = new Set(booked.map((b) => b.scheduledFor.getTime()));

  const slots: Date[] = [];
  const now = Date.now();

  for (const window of windows) {
    const [sh, sm] = window.startTime.split(':').map(Number);
    const [eh, em] = window.endTime.split(':').map(Number);

    const cursor = new Date(dayStart);
    cursor.setHours(sh, sm, 0, 0);
    const end = new Date(dayStart);
    end.setHours(eh, em, 0, 0);

    while (cursor < end) {
      // Never offer a slot in the past or inside the next 15 minutes.
      if (cursor.getTime() > now + 15 * 60_000 && !taken.has(cursor.getTime())) {
        slots.push(new Date(cursor));
      }
      cursor.setMinutes(cursor.getMinutes() + window.slotMins);
    }
  }

  return slots.sort((a, b) => a.getTime() - b.getTime());
}

export async function bookAppointment(input: {
  patientId: string;
  doctorId: string;
  scheduledFor: Date;
  type: 'VIDEO' | 'IN_PERSON' | 'HOME_VISIT';
  reasonForVisit: string;
  symptoms?: string[];
}) {
  const doctor = await db.doctor.findUnique({
    where: { id: input.doctorId },
    select: { consultFee: true, verification: true, user: { select: { name: true } } },
  });
  if (!doctor) throw notFound('Doctor');
  if (doctor.verification !== 'VERIFIED') throw forbidden('This doctor is not accepting bookings');

  // The unique guard is the real defence against two patients taking one slot;
  // this check exists to give the second one a sensible message.
  const clash = await db.appointment.findFirst({
    where: {
      doctorId: input.doctorId,
      scheduledFor: input.scheduledFor,
      status: { notIn: ['CANCELLED', 'NO_SHOW'] },
    },
    select: { id: true },
  });
  if (clash) throw conflict('That time has just been taken. Choose another slot.');

  const appointment = await db.appointment.create({
    data: {
      reference: reference('appointment'),
      patientId: input.patientId,
      doctorId: input.doctorId,
      type: input.type,
      scheduledFor: input.scheduledFor,
      reasonForVisit: input.reasonForVisit,
      symptoms: input.symptoms ?? [],
      status: 'REQUESTED',
      fee: doctor.consultFee,
    },
    include: { patient: { select: { userId: true } } },
  });

  await notify({
    userId: appointment.patient.userId,
    template: 'appointment_confirmed',
    data: {
      doctorName: doctor.user.name,
      when: appointment.scheduledFor,
      reference: appointment.reference,
    },
    channels: ['PUSH', 'IN_APP', 'SMS'],
  });

  return appointment;
}

export async function cancelAppointment(id: string, actorUserId: string, reason?: string) {
  const appointment = await db.appointment.findUnique({
    where: { id },
    include: {
      patient: { select: { userId: true } },
      doctor: { select: { userId: true, user: { select: { name: true } } } },
    },
  });
  if (!appointment) throw notFound('Appointment');

  const allowed = [appointment.patient.userId, appointment.doctor.userId];
  if (!allowed.includes(actorUserId)) throw forbidden('You cannot cancel this appointment');
  if (appointment.status === 'COMPLETED') throw conflict('Completed appointments cannot be cancelled');

  const updated = await db.appointment.update({
    where: { id },
    data: { status: 'CANCELLED', cancelledBy: actorUserId, cancelReason: reason },
  });

  await notify({
    userId: appointment.patient.userId,
    template: 'appointment_cancelled',
    data: { doctorName: appointment.doctor.user.name, when: appointment.scheduledFor, reason },
    channels: ['PUSH', 'IN_APP', 'SMS'],
  });

  return updated;
}

/** Today's list for a doctor, in the order they will see them. */
export async function doctorQueue(doctorId: string) {
  const start = new Date();
  start.setHours(0, 0, 0, 0);
  const end = new Date(start);
  end.setDate(end.getDate() + 1);

  return db.appointment.findMany({
    where: {
      doctorId,
      scheduledFor: { gte: start, lt: end },
      status: { in: ['CONFIRMED', 'IN_PROGRESS', 'REQUESTED'] },
    },
    orderBy: { scheduledFor: 'asc' },
    include: {
      consultation: { select: { id: true, startedAt: true, endedAt: true } },
      patient: {
        select: {
          id: true,
          dateOfBirth: true,
          gender: true,
          allergies: true,
          user: { select: { name: true, avatarUrl: true } },
        },
      },
    },
  });
}
