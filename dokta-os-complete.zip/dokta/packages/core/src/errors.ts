/**
 * Domain failures the interface is expected to show a person. Anything else
 * is a bug and should surface as a 500 rather than be dressed up as advice.
 */
export class DomainError extends Error {
  constructor(
    message: string,
    public readonly code: string,
    public readonly status = 400,
  ) {
    super(message);
    this.name = 'DomainError';
  }
}

export const notFound = (what: string) => new DomainError(`${what} not found`, 'not_found', 404);
export const forbidden = (why: string) => new DomainError(why, 'forbidden', 403);
export const conflict = (why: string) => new DomainError(why, 'conflict', 409);
