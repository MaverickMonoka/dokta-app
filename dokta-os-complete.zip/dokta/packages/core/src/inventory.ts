import { db } from '@dokta/database';
import { notify } from '@dokta/notifications';
import { conflict, notFound } from './errors';

/** Barcode lookup for the POS. Returns the pharmacy's own price and stock. */
export async function scanBarcode(pharmacyId: string, barcode: string) {
  const medicine = await db.medicine.findUnique({
    where: { barcode },
    select: { id: true, name: true, strength: true, schedule: true, form: true },
  });
  if (!medicine) throw notFound('That barcode');

  const item = await db.inventoryItem.findUnique({
    where: { pharmacyId_medicineId: { pharmacyId, medicineId: medicine.id } },
    select: { id: true, sellingPrice: true, stockOnHand: true, isActive: true },
  });
  if (!item || !item.isActive) throw notFound('That product in your inventory');

  return {
    inventoryId: item.id,
    medicineId: medicine.id,
    name: medicine.name,
    strength: medicine.strength,
    schedule: medicine.schedule,
    unitPrice: Number(item.sellingPrice),
    stockOnHand: item.stockOnHand,
    /** S2 and above cannot be sold without a pharmacist present. */
    requiresPharmacist: medicine.schedule !== 'S0' && medicine.schedule !== 'S1',
  };
}

/**
 * Removes stock first-expiry-first. FEFO rather than FIFO, because in a
 * pharmacy the batch closest to expiry is the one that must move.
 */
export async function deductStock(inventoryId: string, quantity: number) {
  return db.$transaction(async (tx) => {
    const item = await tx.inventoryItem.findUnique({
      where: { id: inventoryId },
      include: { batches: { orderBy: { expiryDate: 'asc' } }, medicine: { select: { name: true } } },
    });
    if (!item) throw notFound('Inventory item');
    if (item.stockOnHand < quantity) {
      throw conflict(`Only ${item.stockOnHand} units of ${item.medicine.name} on hand`);
    }

    let remaining = quantity;
    const used: { batchNumber: string; quantity: number }[] = [];

    for (const batch of item.batches) {
      if (remaining === 0) break;
      if (batch.expiryDate < new Date()) continue; // never dispense expired stock

      const take = Math.min(batch.quantity, remaining);
      remaining -= take;
      used.push({ batchNumber: batch.batchNumber, quantity: take });

      if (take === batch.quantity) {
        await tx.stockBatch.delete({ where: { id: batch.id } });
      } else {
        await tx.stockBatch.update({
          where: { id: batch.id },
          data: { quantity: batch.quantity - take },
        });
      }
    }

    if (remaining > 0) throw conflict('Not enough unexpired stock to fill this line');

    const updated = await tx.inventoryItem.update({
      where: { id: inventoryId },
      data: { stockOnHand: { decrement: quantity } },
    });

    return { batchesUsed: used, stockOnHand: updated.stockOnHand, reorderLevel: updated.reorderLevel };
  });
}

export async function receiveStock(input: {
  inventoryId: string;
  batchNumber: string;
  quantity: number;
  expiryDate: Date;
  supplierId?: string;
}) {
  if (input.expiryDate < new Date()) throw conflict('That batch has already expired');

  return db.$transaction(async (tx) => {
    await tx.stockBatch.create({
      data: {
        inventoryId: input.inventoryId,
        batchNumber: input.batchNumber,
        quantity: input.quantity,
        expiryDate: input.expiryDate,
        supplierId: input.supplierId,
      },
    });

    return tx.inventoryItem.update({
      where: { id: input.inventoryId },
      data: { stockOnHand: { increment: input.quantity } },
    });
  });
}

export async function lowStock(pharmacyId: string) {
  const items = await db.inventoryItem.findMany({
    where: { pharmacyId, isActive: true },
    include: { medicine: { select: { name: true, strength: true } } },
    orderBy: { stockOnHand: 'asc' },
  });

  return items.filter((item) => item.stockOnHand <= item.reorderLevel);
}

/** Batches expiring inside the window, soonest first. Default 90 days. */
export async function expiringBatches(pharmacyId: string, days = 90) {
  const cutoff = new Date(Date.now() + days * 86_400_000);

  return db.stockBatch.findMany({
    where: { expiryDate: { lte: cutoff }, inventory: { pharmacyId } },
    orderBy: { expiryDate: 'asc' },
    include: {
      inventory: {
        select: {
          id: true,
          sellingPrice: true,
          medicine: { select: { name: true, strength: true } },
        },
      },
      supplier: { select: { name: true } },
    },
  });
}

/** Warns the pharmacy owner once a line drops to its reorder level. */
export async function warnIfLow(pharmacyId: string, inventoryId: string) {
  const item = await db.inventoryItem.findUnique({
    where: { id: inventoryId },
    include: {
      medicine: { select: { name: true } },
      pharmacy: { select: { ownerId: true } },
    },
  });
  if (!item || item.stockOnHand > item.reorderLevel) return;

  await notify({
    userId: item.pharmacy.ownerId,
    template: 'stock_low',
    data: { medicineName: item.medicine.name, onHand: item.stockOnHand },
    channels: ['IN_APP', 'PUSH'],
  });
}
