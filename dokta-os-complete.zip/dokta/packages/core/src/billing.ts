import { db } from '@dokta/database';
import { gateway, type GatewayId } from '@dokta/payments';
import { money, reference, toCents } from '@dokta/shared';
import { notify } from '@dokta/notifications';
import { conflict, notFound } from './errors';

/**
 * Opens a payment for an appointment or an order. Wallet credit is applied
 * first, and a wallet that covers the whole amount skips the gateway entirely.
 */
export async function startCheckout(input: {
  userId: string;
  gatewayId: GatewayId;
  appointmentId?: string;
  orderId?: string;
  appUrl: string;
}) {
  const user = await db.user.findUnique({
    where: { id: input.userId },
    select: { name: true, email: true, phone: true, patient: { select: { id: true, walletBalance: true } } },
  });
  if (!user) throw notFound('User');

  let amount = 0;
  let description = '';

  if (input.appointmentId) {
    const appointment = await db.appointment.findUnique({
      where: { id: input.appointmentId },
      include: { doctor: { select: { user: { select: { name: true } } } }, payment: true },
    });
    if (!appointment) throw notFound('Appointment');
    if (appointment.payment?.status === 'SUCCEEDED') throw conflict('This appointment is already paid');
    amount = Number(appointment.fee);
    description = `Consultation with ${appointment.doctor.user.name}`;
  } else if (input.orderId) {
    const order = await db.order.findUnique({
      where: { id: input.orderId },
      include: { pharmacy: { select: { name: true } }, payment: true },
    });
    if (!order) throw notFound('Order');
    if (order.payment?.status === 'SUCCEEDED') throw conflict('This order is already paid');
    amount = Number(order.total);
    description = `Medicine from ${order.pharmacy.name}`;
  } else {
    throw conflict('Nothing to pay for');
  }

  const wallet = Number(user.patient?.walletBalance ?? 0);
  const fromWallet = Math.min(wallet, amount);
  const due = Math.round((amount - fromWallet) * 100) / 100;

  const payment = await db.payment.create({
    data: {
      reference: reference('payment'),
      userId: input.userId,
      appointmentId: input.appointmentId,
      orderId: input.orderId,
      amount,
      gateway: due === 0 ? 'CASH' : (input.gatewayId.toUpperCase() as never),
      status: 'PENDING',
    },
  });

  // Wallet covers it: settle immediately, no redirect.
  if (due === 0 && user.patient) {
    await db.patient.update({
      where: { id: user.patient.id },
      data: { walletBalance: { decrement: fromWallet } },
    });
    await settlePayment(payment.reference, payment.reference, toCents(amount));
    return { settled: true as const, paymentId: payment.id };
  }

  const checkout = await gateway(input.gatewayId).createCheckout({
    amountCents: toCents(due),
    currency: 'ZAR',
    reference: payment.reference,
    description,
    customer: { name: user.name, email: user.email, phone: user.phone ?? undefined },
    successUrl: `${input.appUrl}/payments/${payment.id}?state=done`,
    cancelUrl: `${input.appUrl}/payments/${payment.id}?state=cancelled`,
    webhookUrl: `${input.appUrl}/api/webhooks/${input.gatewayId}`,
  });

  await db.payment.update({
    where: { id: payment.id },
    data: { status: 'PROCESSING', gatewayRef: checkout.gatewayRef },
  });

  if (fromWallet > 0 && user.patient) {
    await db.patient.update({
      where: { id: user.patient.id },
      data: { walletBalance: { decrement: fromWallet } },
    });
  }

  return { settled: false as const, paymentId: payment.id, checkout };
}

/**
 * Marks a payment successful and moves whatever it paid for forward. Written
 * to be safe to call twice — gateways retry webhooks, and a double-confirm
 * must not double-advance an order.
 */
export async function settlePayment(paymentReference: string, gatewayRef: string, amountCents: number) {
  const payment = await db.payment.findUnique({
    where: { reference: paymentReference },
    include: { order: { select: { id: true } }, appointment: { select: { id: true } } },
  });
  if (!payment) throw notFound('Payment');
  if (payment.status === 'SUCCEEDED') return payment;

  const expected = toCents(Number(payment.amount));
  if (amountCents > 0 && Math.abs(amountCents - expected) > 1 && payment.gateway !== 'CASH') {
    // Underpayment or tampering — record it and leave the order unpaid.
    await db.payment.update({
      where: { id: payment.id },
      data: { status: 'FAILED', failureReason: `Amount mismatch: expected ${expected}, received ${amountCents}` },
    });
    throw conflict('Payment amount did not match the invoice');
  }

  const updated = await db.payment.update({
    where: { id: payment.id },
    data: { status: 'SUCCEEDED', gatewayRef, paidAt: new Date() },
  });

  if (payment.order) {
    await db.order.update({ where: { id: payment.order.id }, data: { status: 'PICKING' } });
  }
  if (payment.appointment) {
    await db.appointment.update({
      where: { id: payment.appointment.id },
      data: { status: 'CONFIRMED', paymentStatus: 'SUCCEEDED' },
    });
  }

  await notify({
    userId: payment.userId,
    template: 'payment_received',
    data: { amount: money(Number(payment.amount)), reference: payment.reference },
    channels: ['IN_APP', 'PUSH'],
  });

  return updated;
}

export async function failPayment(paymentReference: string, gatewayRef: string, why: string) {
  const payment = await db.payment.findUnique({ where: { reference: paymentReference } });
  if (!payment || payment.status === 'SUCCEEDED') return;

  await db.payment.update({
    where: { id: payment.id },
    data: { status: 'FAILED', gatewayRef, failureReason: why },
  });

  await notify({
    userId: payment.userId,
    template: 'payment_failed',
    data: { amount: money(Number(payment.amount)), reference: payment.reference },
    channels: ['IN_APP', 'PUSH', 'SMS'],
  });
}

export async function refundPayment(paymentId: string, amount: number, reason?: string) {
  const payment = await db.payment.findUnique({ where: { id: paymentId } });
  if (!payment) throw notFound('Payment');
  if (payment.status !== 'SUCCEEDED') throw conflict('Only settled payments can be refunded');

  const remaining = Number(payment.amount) - Number(payment.refundedAmount);
  if (amount > remaining) throw conflict(`Only ${money(remaining)} is left to refund`);

  const id = payment.gateway.toLowerCase() as GatewayId;
  const provider = gateway(id);
  if (!provider.refund) {
    throw conflict(`${provider.label} cannot refund automatically. Refund by EFT and record it here.`);
  }

  await provider.refund({
    gatewayRef: payment.gatewayRef!,
    amountCents: toCents(amount),
    reason,
  });

  const refunded = Number(payment.refundedAmount) + amount;

  return db.payment.update({
    where: { id: paymentId },
    data: {
      refundedAmount: refunded,
      status: refunded >= Number(payment.amount) ? 'REFUNDED' : 'PARTIALLY_REFUNDED',
    },
  });
}
