import { db } from '@dokta/database';

export interface PlatformMetrics {
  users: number;
  patients: number;
  activeDoctors: number;
  pendingProviders: number;
  appointments30d: number;
  consultationRevenue30d: number;
  pharmacyRevenue30d: number;
  platformRevenue30d: number;
}

const daysAgo = (n: number) => new Date(Date.now() - n * 86_400_000);

export async function platformMetrics(): Promise<PlatformMetrics> {
  const since = daysAgo(30);

  const [users, patients, activeDoctors, pendingDoctors, pendingPharmacies, appointments, consultRevenue, pharmacyRevenue, counterRevenue] =
    await Promise.all([
      db.user.count(),
      db.user.count({ where: { role: 'PATIENT' } }),
      db.doctor.count({ where: { verification: 'VERIFIED' } }),
      db.doctor.count({ where: { verification: { in: ['PENDING', 'UNDER_REVIEW'] } } }),
      db.pharmacy.count({ where: { verification: { in: ['PENDING', 'UNDER_REVIEW'] } } }),
      db.appointment.count({ where: { createdAt: { gte: since } } }),
      db.payment.aggregate({
        where: { status: 'SUCCEEDED', paidAt: { gte: since }, appointmentId: { not: null } },
        _sum: { amount: true },
      }),
      db.payment.aggregate({
        where: { status: 'SUCCEEDED', paidAt: { gte: since }, orderId: { not: null } },
        _sum: { amount: true },
      }),
      db.sale.aggregate({ where: { createdAt: { gte: since }, voidedAt: null }, _sum: { total: true } }),
    ]);

  const consult = Number(consultRevenue._sum.amount ?? 0);
  const pharmacy = Number(pharmacyRevenue._sum.amount ?? 0) + Number(counterRevenue._sum.total ?? 0);

  return {
    users,
    patients,
    activeDoctors,
    pendingProviders: pendingDoctors + pendingPharmacies,
    appointments30d: appointments,
    consultationRevenue30d: consult,
    pharmacyRevenue30d: pharmacy,
    // The platform takes 12% of consultations and 4% of medicine.
    platformRevenue30d: Math.round((consult * 0.12 + pharmacy * 0.04) * 100) / 100,
  };
}

/** Daily series for the admin charts. Gaps are filled with zero, not skipped. */
export async function dailySeries(days = 30) {
  const since = daysAgo(days);

  const [payments, signups] = await Promise.all([
    db.payment.findMany({
      where: { status: 'SUCCEEDED', paidAt: { gte: since } },
      select: { amount: true, paidAt: true },
    }),
    db.user.findMany({ where: { createdAt: { gte: since } }, select: { createdAt: true } }),
  ]);

  const labels: string[] = [];
  const revenue: number[] = [];
  const users: number[] = [];

  for (let i = days - 1; i >= 0; i -= 1) {
    const day = new Date(Date.now() - i * 86_400_000);
    const key = day.toISOString().slice(0, 10);
    labels.push(key);
    revenue.push(
      Math.round(
        payments
          .filter((p) => p.paidAt?.toISOString().slice(0, 10) === key)
          .reduce((s, p) => s + Number(p.amount), 0) * 100,
      ) / 100,
    );
    users.push(signups.filter((u) => u.createdAt.toISOString().slice(0, 10) === key).length);
  }

  return { labels, revenue, users };
}

export async function topMedicines(limit = 8) {
  const grouped = await db.orderItem.groupBy({
    by: ['description'],
    _sum: { quantity: true },
    orderBy: { _sum: { quantity: 'desc' } },
    take: limit,
  });

  return grouped.map((g) => ({ name: g.description, units: g._sum.quantity ?? 0 }));
}

export async function pharmacyPerformance() {
  const pharmacies = await db.pharmacy.findMany({
    where: { verification: 'VERIFIED' },
    select: {
      id: true,
      name: true,
      city: true,
      _count: { select: { orders: true } },
      sales: { where: { voidedAt: null }, select: { total: true } },
    },
  });

  return pharmacies
    .map((p) => ({
      id: p.id,
      name: p.name,
      city: p.city,
      orders: p._count.orders,
      counterTotal: p.sales.reduce((s, sale) => s + Number(sale.total), 0),
    }))
    .sort((a, b) => b.counterTotal - a.counterTotal);
}

export interface DoctorEarnings {
  gross30d: number;
  net30d: number;
  allTime: number;
  consultationsCompleted: number;
  /** What the next Tuesday payout will move, i.e. settled but not yet paid out. */
  pendingPayout: number;
}

/** The platform keeps 12% of each consultation fee. */
export const PLATFORM_CONSULT_FEE = 0.12;

export async function doctorEarnings(doctorId: string): Promise<DoctorEarnings> {
  const since = daysAgo(30);
  const where = { status: 'SUCCEEDED' as const, appointment: { doctorId } };

  const [last30, allTime, completed, pending] = await Promise.all([
    db.payment.aggregate({ where: { ...where, paidAt: { gte: since } }, _sum: { amount: true } }),
    db.payment.aggregate({ where, _sum: { amount: true } }),
    db.appointment.count({ where: { doctorId, status: 'COMPLETED' } }),
    db.payment.aggregate({
      where: { ...where, paidAt: { gte: lastPayoutRun() } },
      _sum: { amount: true },
    }),
  ]);

  const gross30d = Number(last30._sum.amount ?? 0);
  const net = (gross: number) => Math.round(gross * (1 - PLATFORM_CONSULT_FEE) * 100) / 100;

  return {
    gross30d,
    net30d: net(gross30d),
    allTime: net(Number(allTime._sum.amount ?? 0)),
    consultationsCompleted: completed,
    pendingPayout: net(Number(pending._sum.amount ?? 0)),
  };
}

/** Payouts run every Tuesday, covering everything settled since the last one. */
function lastPayoutRun(): Date {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  const daysSinceTuesday = (d.getDay() - 2 + 7) % 7;
  d.setDate(d.getDate() - daysSinceTuesday);
  return d;
}
