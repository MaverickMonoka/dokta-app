'use server';

import { revalidatePath } from 'next/cache';
import { requireCapability } from '@dokta/auth';
import { db } from '@dokta/database';

async function currentDoctorId() {
  const session = await requireCapability('availability:manage', '/availability');
  const doctor = await db.doctor.findUnique({ where: { userId: session.id }, select: { id: true } });
  if (!doctor) throw new Error('No doctor profile for this account');
  return doctor.id;
}

export async function addWindow(input: {
  weekday: number;
  startTime: string;
  endTime: string;
  slotMins: number;
}) {
  const doctorId = await currentDoctorId();

  if (input.endTime <= input.startTime) {
    return { ok: false as const, error: 'The end time must be after the start time.' };
  }

  const existing = await db.availabilitySlot.findMany({
    where: { doctorId, weekday: input.weekday, isActive: true },
    select: { startTime: true, endTime: true },
  });

  const overlaps = existing.some((w) => input.startTime < w.endTime && input.endTime > w.startTime);
  if (overlaps) {
    return { ok: false as const, error: 'That overlaps consulting hours you already have on this day.' };
  }

  await db.availabilitySlot.create({
    data: {
      doctorId,
      weekday: input.weekday,
      startTime: input.startTime,
      endTime: input.endTime,
      slotMins: input.slotMins,
    },
  });

  revalidatePath('/availability');
  return { ok: true as const };
}

/**
 * Closing a window never deletes it while bookings exist inside it — the
 * appointments stay valid and the doctor is told what is still on the books.
 */
export async function closeWindow(id: string) {
  const doctorId = await currentDoctorId();

  const window = await db.availabilitySlot.findFirst({
    where: { id, doctorId },
    select: { weekday: true, startTime: true, endTime: true },
  });
  if (!window) return { ok: false as const, error: 'Those hours were not found.' };

  const upcoming = await db.appointment.count({
    where: {
      doctorId,
      scheduledFor: { gte: new Date() },
      status: { in: ['REQUESTED', 'CONFIRMED'] },
    },
  });

  await db.availabilitySlot.delete({ where: { id } });
  revalidatePath('/availability');

  return {
    ok: true as const,
    notice:
      upcoming > 0
        ? `Hours removed. ${upcoming} appointment${upcoming === 1 ? '' : 's'} already booked will still go ahead.`
        : undefined,
  };
}
