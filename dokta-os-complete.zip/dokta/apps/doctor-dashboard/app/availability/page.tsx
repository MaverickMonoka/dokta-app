import { requireCapability } from '@dokta/auth';
import { db } from '@dokta/database';
import { PageHeader } from '@dokta/ui';
import { AvailabilityEditor } from '@/components/availability-editor';

export const metadata = { title: 'Availability' };
export const dynamic = 'force-dynamic';

export default async function AvailabilityPage() {
  const session = await requireCapability('availability:manage', '/availability');

  const doctor = await db.doctor.findUniqueOrThrow({
    where: { userId: session.id },
    select: {
      id: true,
      consultFee: true,
      availability: { where: { isActive: true }, orderBy: [{ weekday: 'asc' }, { startTime: 'asc' }] },
    },
  });

  return (
    <>
      <PageHeader
        title="Consulting hours"
        description="Patients can book any open slot inside these hours. Slots are offered up to 15 minutes before they start."
      />
      <div className="p-5 lg:p-8">
        <AvailabilityEditor
          windows={doctor.availability.map((w) => ({
            id: w.id,
            weekday: w.weekday,
            startTime: w.startTime,
            endTime: w.endTime,
            slotMins: w.slotMins,
          }))}
        />
      </div>
    </>
  );
}
