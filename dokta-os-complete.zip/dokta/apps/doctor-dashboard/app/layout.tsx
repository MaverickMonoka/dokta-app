import type { Metadata, Viewport } from 'next';
import { Inter, Plus_Jakarta_Sans } from 'next/font/google';
import { headers } from 'next/headers';
import { CalendarDays, LayoutDashboard, Clock, Wallet, Users } from 'lucide-react';
import { requireCapability } from '@dokta/auth';
import { db } from '@dokta/database';
import { AppShell } from '@dokta/ui';
import './globals.css';

const body = Inter({ subsets: ['latin'], variable: '--font-body', display: 'swap' });
const display = Plus_Jakarta_Sans({
  subsets: ['latin'],
  weight: ['600', '700'],
  variable: '--font-display',
  display: 'swap',
});

export const metadata: Metadata = { title: { default: 'Command centre', template: '%s · DOKTA' } };
export const viewport: Viewport = { themeColor: '#0B2137', width: 'device-width', initialScale: 1 };

export default async function DoctorLayout({ children }: { children: React.ReactNode }) {
  const session = await requireCapability('queue:read', '/');

  const doctor = await db.doctor.findUnique({
    where: { userId: session.id },
    select: { id: true, speciality: true },
  });

  const start = new Date();
  start.setHours(0, 0, 0, 0);
  const end = new Date(start);
  end.setDate(end.getDate() + 1);

  const waiting = doctor
    ? await db.appointment.count({
        where: {
          doctorId: doctor.id,
          scheduledFor: { gte: start, lt: end },
          status: { in: ['CONFIRMED', 'IN_PROGRESS'] },
        },
      })
    : 0;

  const path = headers().get('x-invoke-path') ?? headers().get('x-pathname') ?? '/';

  return (
    <html lang="en-ZA" className={`${body.variable} ${display.variable}`}>
      <body>
        <AppShell
          product="Command centre"
          currentPath={path}
          user={{ name: session.name, subtitle: doctor?.speciality }}
          nav={[
            { href: '/', label: 'Today', icon: LayoutDashboard },
            { href: '/queue', label: 'Patient queue', icon: Users, badge: waiting },
            { href: '/availability', label: 'Availability', icon: CalendarDays },
            { href: '/history', label: 'Past consultations', icon: Clock },
            { href: '/earnings', label: 'Earnings', icon: Wallet },
          ]}
        >
          {children}
        </AppShell>
      </body>
    </html>
  );
}
