import { notFound } from 'next/navigation';
import { requireCapability, audit } from '@dokta/auth';
import { db } from '@dokta/database';
import { money, shortDate, time } from '@dokta/shared';
import { Badge, PageHeader } from '@dokta/ui';
import { ConsultationWorkspace } from '@/components/consultation-workspace';

export const dynamic = 'force-dynamic';

export default async function ConsultationPage({ params }: { params: { id: string } }) {
  const session = await requireCapability('consultation:conduct', `/consultations/${params.id}`);

  const doctor = await db.doctor.findUnique({
    where: { userId: session.id },
    select: { id: true },
  });
  if (!doctor) notFound();

  const appointment = await db.appointment.findFirst({
    // Scoped to this doctor: a doctor may only open their own consultations.
    where: { id: params.id, doctorId: doctor.id },
    select: {
      id: true,
      reference: true,
      scheduledFor: true,
      status: true,
      type: true,
      fee: true,
      reasonForVisit: true,
      symptoms: true,
      consultation: {
        select: {
          id: true,
          notes: true,
          diagnosis: true,
          icd10Codes: true,
          chiefComplaint: true,
          followUpDate: true,
        },
      },
      patient: {
        select: {
          id: true,
          dateOfBirth: true,
          gender: true,
          bloodType: true,
          allergies: true,
          medicalHistory: true,
          chronicMeds: true,
          medicalAidName: true,
          user: { select: { name: true, phone: true } },
        },
      },
    },
  });

  if (!appointment) notFound();

  // Opening a consultation is an access to health information under POPIA s14.
  await audit({
    actorId: session.id,
    action: 'read',
    entity: 'Consultation',
    entityId: appointment.consultation?.id,
    subjectId: appointment.patient.id,
    lawfulBasis: 'provision_of_healthcare',
  });

  const [pastConsultations, activeScripts, pharmacies] = await Promise.all([
    db.consultation.findMany({
      where: {
        appointment: { patientId: appointment.patient.id, status: 'COMPLETED' },
        NOT: { appointmentId: appointment.id },
      },
      orderBy: { createdAt: 'desc' },
      take: 5,
      select: {
        id: true,
        diagnosis: true,
        createdAt: true,
        appointment: { select: { doctor: { select: { user: { select: { name: true } } } } } },
      },
    }),
    db.prescription.findMany({
      where: {
        patientId: appointment.patient.id,
        status: { notIn: ['CANCELLED', 'EXPIRED'] },
        validUntil: { gte: new Date() },
      },
      select: { items: { select: { medicineName: true, strength: true } } },
    }),
    db.pharmacy.findMany({
      where: { verification: 'VERIFIED' },
      orderBy: { name: 'asc' },
      select: { id: true, name: true, suburb: true, city: true },
    }),
  ]);

  const currentMeds = activeScripts.flatMap((rx) =>
    rx.items.map((i) => `${i.medicineName}${i.strength ? ` ${i.strength}` : ''}`),
  );

  return (
    <>
      <PageHeader
        title={appointment.patient.user.name}
        description={`${appointment.reference} · ${shortDate(appointment.scheduledFor)} at ${time(appointment.scheduledFor)} · ${money(Number(appointment.fee))}`}
        actions={<Badge status={appointment.status} />}
      />

      <ConsultationWorkspace
        appointmentId={appointment.id}
        consultationId={appointment.consultation!.id}
        patient={{
          id: appointment.patient.id,
          name: appointment.patient.user.name,
          phone: appointment.patient.user.phone,
          age: appointment.patient.dateOfBirth
            ? Math.floor((Date.now() - appointment.patient.dateOfBirth.getTime()) / 31_557_600_000)
            : null,
          gender: appointment.patient.gender,
          bloodType: appointment.patient.bloodType,
          allergies: (appointment.patient.allergies as string[]) ?? [],
          history: (appointment.patient.medicalHistory as string[]) ?? [],
          medicalAid: appointment.patient.medicalAidName,
          currentMeds,
        }}
        reasonForVisit={appointment.reasonForVisit}
        symptoms={appointment.symptoms}
        existing={{
          notes: appointment.consultation?.notes ?? '',
          diagnosis: appointment.consultation?.diagnosis ?? '',
        }}
        pastConsultations={pastConsultations.map((c) => ({
          id: c.id,
          date: shortDate(c.createdAt),
          diagnosis: c.diagnosis ?? 'No diagnosis recorded',
          doctor: c.appointment.doctor.user.name,
        }))}
        pharmacies={pharmacies.map((p) => ({
          value: p.id,
          label: `${p.name} — ${p.suburb ?? p.city ?? ''}`,
        }))}
        isVideo={appointment.type === 'VIDEO'}
      />
    </>
  );
}
