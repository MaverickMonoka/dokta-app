'use server';

import { revalidatePath } from 'next/cache';
import { requireCapability, audit } from '@dokta/auth';
import { db } from '@dokta/database';
import { issuePrescription, DomainError, type PrescriptionLine } from '@dokta/core';
import { checkInteractions, draftClinicalNote, type InteractionWarning } from '@dokta/ai';

async function currentDoctor(capability: string) {
  const session = await requireCapability(capability, '/');
  const doctor = await db.doctor.findUnique({
    where: { userId: session.id },
    select: { id: true },
  });
  if (!doctor) throw new Error('No doctor profile for this account');
  return { session, doctorId: doctor.id };
}

export async function saveConsultation(input: {
  consultationId: string;
  appointmentId: string;
  notes: string;
  diagnosis: string;
  icd10Codes: string[];
  followUpDate?: string;
}) {
  const { session, doctorId } = await currentDoctor('consultation:note');

  const owns = await db.consultation.findFirst({
    where: { id: input.consultationId, appointment: { doctorId } },
    select: { appointment: { select: { patientId: true } } },
  });
  if (!owns) return { ok: false as const, error: 'That consultation is not yours to edit.' };

  await db.consultation.update({
    where: { id: input.consultationId },
    data: {
      notes: input.notes,
      diagnosis: input.diagnosis || null,
      icd10Codes: input.icd10Codes,
      followUpDate: input.followUpDate ? new Date(input.followUpDate) : null,
    },
  });

  await audit({
    actorId: session.id,
    action: 'update',
    entity: 'Consultation',
    entityId: input.consultationId,
    subjectId: owns.appointment.patientId,
    lawfulBasis: 'provision_of_healthcare',
  });

  revalidatePath(`/consultations/${input.appointmentId}`);
  return { ok: true as const };
}

export async function completeConsultation(appointmentId: string) {
  const { doctorId } = await currentDoctor('consultation:conduct');

  const consultation = await db.consultation.findFirst({
    where: { appointmentId, appointment: { doctorId } },
    select: { id: true, diagnosis: true },
  });

  if (!consultation) return { ok: false as const, error: 'Consultation not found.' };
  if (!consultation.diagnosis) {
    return {
      ok: false as const,
      error: 'Record a diagnosis before closing the consultation.',
    };
  }

  await db.$transaction([
    db.consultation.update({ where: { id: consultation.id }, data: { endedAt: new Date() } }),
    db.appointment.update({ where: { id: appointmentId }, data: { status: 'COMPLETED' } }),
  ]);

  revalidatePath('/');
  return { ok: true as const };
}

export async function issueScript(input: {
  appointmentId: string;
  consultationId: string;
  patientId: string;
  pharmacyId?: string;
  repeats: number;
  validMonths: number;
  notes?: string;
  items: PrescriptionLine[];
}) {
  const { session, doctorId } = await currentDoctor('prescription:issue');

  const validUntil = new Date();
  validUntil.setMonth(validUntil.getMonth() + input.validMonths);

  try {
    const prescription = await issuePrescription({
      doctorId,
      patientId: input.patientId,
      consultationId: input.consultationId,
      pharmacyId: input.pharmacyId || undefined,
      repeats: input.repeats,
      validUntil,
      notes: input.notes,
      items: input.items,
    });

    await audit({
      actorId: session.id,
      action: 'create',
      entity: 'Prescription',
      entityId: prescription.id,
      subjectId: input.patientId,
      lawfulBasis: 'provision_of_healthcare',
      metadata: { itemCount: input.items.length, repeats: input.repeats },
    });

    revalidatePath(`/consultations/${input.appointmentId}`);
    return { ok: true as const, reference: prescription.reference };
  } catch (error) {
    if (error instanceof DomainError) return { ok: false as const, error: error.message };
    throw error;
  }
}

/**
 * Advisory check run when the doctor adds a medicine. Never blocks the script —
 * a clinician may prescribe against a warning with good reason, and a hard
 * block would push them off the platform onto paper.
 */
export async function screenInteractions(input: {
  prescribing: string[];
  currentMeds: string[];
  allergies: string[];
}): Promise<{ ok: true; warnings: InteractionWarning[] } | { ok: false; error: string }> {
  await currentDoctor('prescription:issue');

  try {
    const warnings = await checkInteractions(input.prescribing, input.currentMeds, input.allergies);
    return { ok: true, warnings };
  } catch {
    return { ok: false, error: 'The interaction check is unavailable. Review the medicines yourself.' };
  }
}

export async function draftNote(input: {
  chiefComplaint: string;
  rawNotes: string;
  patientAge?: number;
  patientSex?: string;
}) {
  await currentDoctor('consultation:note');

  try {
    const soap = await draftClinicalNote(input);
    return {
      ok: true as const,
      // Returned as one editable block — the doctor signs what they read.
      text: `Subjective: ${soap.subjective}\n\nObjective: ${soap.objective}\n\nAssessment: ${soap.assessment}\n\nPlan: ${soap.plan}`,
    };
  } catch {
    return { ok: false as const, error: 'Could not draft the note. Your typed notes are unchanged.' };
  }
}
