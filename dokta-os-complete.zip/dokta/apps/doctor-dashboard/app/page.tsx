import Link from 'next/link';
import { AlertTriangle, FileWarning, Stethoscope } from 'lucide-react';
import { requireCapability } from '@dokta/auth';
import { db } from '@dokta/database';
import { doctorQueue } from '@dokta/core';
import { money, time } from '@dokta/shared';
import { Badge, Card, CardBody, CardHeader, CardTitle, EmptyState, PageHeader, Stat, buttonVariants } from '@dokta/ui';

export const dynamic = 'force-dynamic';

export default async function CommandCentre() {
  const session = await requireCapability('queue:read', '/');
  const doctor = await db.doctor.findUnique({
    where: { userId: session.id },
    select: { id: true, verification: true, consultFee: true },
  });

  if (!doctor) {
    return (
      <EmptyState
        icon={Stethoscope}
        title="Your doctor profile is not set up"
        body="Add your HPCSA number and speciality before patients can find you."
        action={{ label: 'Set up profile', href: '/profile' }}
      />
    );
  }

  if (doctor.verification !== 'VERIFIED') {
    return (
      <>
        <PageHeader title="Verification in progress" />
        <div className="p-5 lg:p-8">
          <Card className="max-w-prose">
            <CardBody className="pt-5">
              <div className="flex gap-3">
                <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-warn" aria-hidden />
                <div>
                  <p className="text-sm text-ink">
                    We are confirming your HPCSA registration. This usually takes one working day.
                    You will get an email as soon as your profile is live, and patients can book
                    from that moment.
                  </p>
                  <p className="mt-3 text-sm text-muted">
                    Set your consulting hours now so your calendar is ready.
                  </p>
                  <Link href="/availability" className={buttonVariants({ size: 'sm', className: 'mt-4' })}>
                    Set consulting hours
                  </Link>
                </div>
              </div>
            </CardBody>
          </Card>
        </div>
      </>
    );
  }

  const monthStart = new Date();
  monthStart.setDate(1);
  monthStart.setHours(0, 0, 0, 0);

  const [queue, earnings, unsignedNotes, scriptRequests] = await Promise.all([
    doctorQueue(doctor.id),
    db.payment.aggregate({
      where: {
        status: 'SUCCEEDED',
        paidAt: { gte: monthStart },
        appointment: { doctorId: doctor.id },
      },
      _sum: { amount: true },
      _count: true,
    }),
    db.consultation.count({
      where: { appointment: { doctorId: doctor.id }, endedAt: { not: null }, diagnosis: null },
    }),
    db.prescription.count({ where: { doctorId: doctor.id, status: 'ISSUED' } }),
  ]);

  const gross = Number(earnings._sum.amount ?? 0);

  return (
    <>
      <PageHeader
        title="Today"
        description={new Intl.DateTimeFormat('en-ZA', { dateStyle: 'full' }).format(new Date())}
        actions={
          queue[0] ? (
            <Link href={`/consultations/${queue[0].id}`} className={buttonVariants()}>
              Start next consultation
            </Link>
          ) : null
        }
      />

      <div className="space-y-5 p-5 lg:p-8">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Stat label="Patients today" value={queue.length} />
          <Stat
            label="Earned this month"
            value={money(gross * 0.88)}
            hint={`${earnings._count} paid · after 12% platform fee`}
          />
          <Stat label="Notes to sign" value={unsignedNotes} hint={unsignedNotes ? 'Sign to release to the patient' : 'All signed'} />
          <Stat label="Script requests" value={scriptRequests} />
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Your list</CardTitle>
            {unsignedNotes > 0 && (
              <span className="flex items-center gap-1.5 text-meta text-warn">
                <FileWarning className="h-3.5 w-3.5" aria-hidden />
                {unsignedNotes} unsigned
              </span>
            )}
          </CardHeader>
          <CardBody className="px-0 pb-0">
            {queue.length === 0 ? (
              <EmptyState
                icon={Stethoscope}
                title="No patients booked today"
                body="Open a few more consulting hours and patients will be able to book them."
                action={{ label: 'Adjust availability', href: '/availability' }}
              />
            ) : (
              <ul className="divide-y divide-hairline border-t border-hairline">
                {queue.map((appointment) => {
                  const allergies = (appointment.patient.allergies as string[]) ?? [];
                  return (
                    <li key={appointment.id}>
                      <Link
                        href={`/consultations/${appointment.id}`}
                        className="flex items-center gap-4 px-5 py-3.5 hover:bg-canvas"
                      >
                        <span className="money w-14 shrink-0 text-sm font-semibold text-ink">
                          {time(appointment.scheduledFor)}
                        </span>
                        <span className="min-w-0 flex-1">
                          <span className="block truncate text-sm font-medium text-ink">
                            {appointment.patient.user.name}
                          </span>
                          <span className="block truncate text-meta text-muted">
                            {appointment.reasonForVisit ?? 'No reason given'}
                          </span>
                        </span>
                        {allergies.length > 0 && (
                          <Badge tone="alert" className="shrink-0">
                            Allergy: {allergies[0]}
                          </Badge>
                        )}
                        <Badge status={appointment.status} className="shrink-0" />
                      </Link>
                    </li>
                  );
                })}
              </ul>
            )}
          </CardBody>
        </Card>
      </div>
    </>
  );
}
