import Link from 'next/link';
import { ClipboardList } from 'lucide-react';
import { requireCapability } from '@dokta/auth';
import { db } from '@dokta/database';
import { shortDate, time } from '@dokta/shared';
import { Badge, DataTable, EmptyState, PageHeader, buttonVariants } from '@dokta/ui';

export const metadata = { title: "Today's patients" };
export const dynamic = 'force-dynamic';

export default async function QueuePage() {
  const session = await requireCapability('queue:read', '/queue');
  const doctor = await db.doctor.findUniqueOrThrow({
    where: { userId: session.id },
    select: { id: true },
  });

  const from = new Date();
  from.setHours(0, 0, 0, 0);
  const to = new Date(from);
  to.setDate(to.getDate() + 7);

  const appointments = await db.appointment.findMany({
    where: { doctorId: doctor.id, scheduledFor: { gte: from, lt: to } },
    orderBy: { scheduledFor: 'asc' },
    select: {
      id: true,
      reference: true,
      scheduledFor: true,
      status: true,
      type: true,
      reasonForVisit: true,
      patient: { select: { user: { select: { name: true } } } },
    },
  });

  return (
    <>
      <PageHeader title="Patient queue" description="Everything booked over the next seven days." />

      <div className="p-5 lg:p-8">
        <DataTable
          rows={appointments}
          rowKey={(a) => a.id}
          empty={
            <EmptyState
              icon={ClipboardList}
              title="Nothing booked this week"
              body="Open more slots on your calendar and patients will be able to book you."
              action={{ label: 'Manage availability', href: '/availability' }}
            />
          }
          columns={[
            {
              key: 'when',
              header: 'When',
              width: '170px',
              render: (a) => (
                <span className="money">
                  {shortDate(a.scheduledFor)} · {time(a.scheduledFor)}
                </span>
              ),
            },
            {
              key: 'patient',
              header: 'Patient',
              render: (a) => <span className="font-medium">{a.patient.user.name}</span>,
            },
            {
              key: 'reason',
              header: 'Reason',
              render: (a) => (
                <span className="line-clamp-1 text-muted">{a.reasonForVisit ?? '—'}</span>
              ),
            },
            { key: 'type', header: 'Type', render: (a) => a.type.replace(/_/g, ' ').toLowerCase() },
            { key: 'status', header: 'Status', render: (a) => <Badge status={a.status} /> },
            {
              key: 'open',
              header: '',
              width: '110px',
              render: (a) => (
                <Link
                  href={`/consultations/${a.id}`}
                  className={buttonVariants({ variant: 'outline', size: 'sm' })}
                >
                  Open
                </Link>
              ),
            },
          ]}
        />
      </div>
    </>
  );
}
