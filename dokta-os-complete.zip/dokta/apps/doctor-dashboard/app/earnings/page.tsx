import { requireCapability } from '@dokta/auth';
import { db } from '@dokta/database';
import { doctorEarnings } from '@dokta/core';
import { money, shortDate } from '@dokta/shared';
import { Badge, DataTable, EmptyState, PageHeader, Stat } from '@dokta/ui';
import { Wallet } from 'lucide-react';

export const metadata = { title: 'Earnings' };
export const dynamic = 'force-dynamic';

export default async function EarningsPage() {
  const session = await requireCapability('earnings:read:own', '/earnings');
  const doctor = await db.doctor.findUniqueOrThrow({
    where: { userId: session.id },
    select: { id: true },
  });

  const [earnings, payments] = await Promise.all([
    doctorEarnings(doctor.id),
    db.payment.findMany({
      where: { appointment: { doctorId: doctor.id } },
      orderBy: { createdAt: 'desc' },
      take: 25,
      select: {
        id: true,
        reference: true,
        amount: true,
        status: true,
        gateway: true,
        paidAt: true,
        createdAt: true,
        appointment: { select: { patient: { select: { user: { select: { name: true } } } } } },
      },
    }),
  ]);

  return (
    <>
      <PageHeader
        title="Earnings"
        description="DOKTA takes 12% of each consultation fee. Payouts run every Tuesday for the preceding week."
      />

      <div className="p-5 lg:p-8">
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <Stat label="Gross, last 30 days" value={money(earnings.gross30d)} />
          <Stat label="Net, last 30 days" value={money(earnings.net30d)} hint="After the platform fee" />
          <Stat label="All time" value={money(earnings.allTime)} />
          <Stat label="Consultations completed" value={earnings.consultationsCompleted} />
        </div>

        <h2 className="mb-3 mt-8 font-display text-title text-ink">Recent payments</h2>

        <DataTable
          rows={payments}
          rowKey={(p) => p.id}
          empty={
            <EmptyState
              icon={Wallet}
              title="No payments yet"
              body="Payments appear here once a patient pays for a consultation with you."
            />
          }
          columns={[
            { key: 'ref', header: 'Reference', render: (p) => <span className="money">{p.reference}</span> },
            {
              key: 'patient',
              header: 'Patient',
              render: (p) => p.appointment?.patient.user.name ?? '—',
            },
            {
              key: 'date',
              header: 'Date',
              render: (p) => shortDate(p.paidAt ?? p.createdAt),
            },
            { key: 'gateway', header: 'Method', render: (p) => p.gateway.toLowerCase() },
            { key: 'status', header: 'Status', render: (p) => <Badge status={p.status} /> },
            {
              key: 'amount',
              header: 'Amount',
              numeric: true,
              render: (p) => money(Number(p.amount)),
            },
          ]}
        />
      </div>
    </>
  );
}
