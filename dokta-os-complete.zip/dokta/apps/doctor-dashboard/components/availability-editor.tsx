'use client';

import * as React from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { Button, Card, CardBody, CardHeader, CardTitle, ErrorState, SelectField, Field } from '@dokta/ui';
import { addWindow, closeWindow } from '@/app/availability/actions';

const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

interface Window {
  id: string;
  weekday: number;
  startTime: string;
  endTime: string;
  slotMins: number;
}

function slotsIn(window: Window): number {
  const [sh, sm] = window.startTime.split(':').map(Number);
  const [eh, em] = window.endTime.split(':').map(Number);
  return Math.max(0, Math.floor((eh * 60 + em - (sh * 60 + sm)) / window.slotMins));
}

export function AvailabilityEditor({ windows }: { windows: Window[] }) {
  const [weekday, setWeekday] = React.useState('1');
  const [startTime, setStartTime] = React.useState('08:00');
  const [endTime, setEndTime] = React.useState('12:00');
  const [slotMins, setSlotMins] = React.useState('15');
  const [message, setMessage] = React.useState<{ tone: 'error' | 'notice'; text: string } | null>(null);
  const [pending, startTransition] = React.useTransition();

  const byDay = DAYS.map((_, day) => windows.filter((w) => w.weekday === day));
  const weeklySlots = windows.reduce((sum, w) => sum + slotsIn(w), 0);

  function submit() {
    setMessage(null);
    startTransition(async () => {
      const result = await addWindow({
        weekday: Number(weekday),
        startTime,
        endTime,
        slotMins: Number(slotMins),
      });
      if (!result.ok) setMessage({ tone: 'error', text: result.error });
    });
  }

  function remove(id: string) {
    setMessage(null);
    startTransition(async () => {
      const result = await closeWindow(id);
      if (!result.ok) setMessage({ tone: 'error', text: result.error });
      else if (result.notice) setMessage({ tone: 'notice', text: result.notice });
    });
  }

  return (
    <div className="grid gap-5 lg:grid-cols-[1fr_320px]">
      <Card>
        <CardHeader>
          <CardTitle>Your week</CardTitle>
          <span className="text-meta text-muted">{weeklySlots} bookable slots</span>
        </CardHeader>
        <CardBody className="px-0 pb-0">
          <ul className="divide-y divide-hairline border-t border-hairline">
            {DAYS.map((day, index) => (
              <li key={day} className="flex items-start gap-4 px-5 py-3.5">
                <span className="w-24 shrink-0 pt-1 text-sm font-medium text-ink">{day}</span>
                <div className="flex flex-1 flex-wrap gap-2">
                  {byDay[index].length === 0 ? (
                    <span className="pt-1 text-sm text-muted">Not consulting</span>
                  ) : (
                    byDay[index].map((w) => (
                      <span
                        key={w.id}
                        className="flex items-center gap-2 rounded-pill bg-navy-50 py-1 pl-3 pr-1.5 text-sm text-navy"
                      >
                        <span className="money">
                          {w.startTime}–{w.endTime}
                        </span>
                        <span className="text-meta text-muted">{slotsIn(w)} slots</span>
                        <button
                          type="button"
                          onClick={() => remove(w.id)}
                          disabled={pending}
                          aria-label={`Remove ${day} ${w.startTime} to ${w.endTime}`}
                          className="rounded-full p-1 text-muted hover:bg-white hover:text-alert"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </span>
                    ))
                  )}
                </div>
              </li>
            ))}
          </ul>
        </CardBody>
      </Card>

      <div className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle>Add hours</CardTitle>
          </CardHeader>
          <CardBody className="space-y-3">
            <SelectField
              label="Day"
              value={weekday}
              onChange={(e) => setWeekday(e.target.value)}
              options={DAYS.map((d, i) => ({ value: String(i), label: d }))}
            />
            <div className="grid grid-cols-2 gap-3">
              <Field
                label="From"
                type="time"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
              />
              <Field
                label="To"
                type="time"
                value={endTime}
                onChange={(e) => setEndTime(e.target.value)}
              />
            </div>
            <SelectField
              label="Appointment length"
              value={slotMins}
              onChange={(e) => setSlotMins(e.target.value)}
              options={[
                { value: '10', label: '10 minutes' },
                { value: '15', label: '15 minutes' },
                { value: '20', label: '20 minutes' },
                { value: '30', label: '30 minutes' },
                { value: '45', label: '45 minutes' },
              ]}
            />
            <Button full loading={pending} onClick={submit}>
              <Plus className="h-4 w-4" aria-hidden />
              Add these hours
            </Button>
          </CardBody>
        </Card>

        {message?.tone === 'error' && <ErrorState title="Could not save" body={message.text} />}
        {message?.tone === 'notice' && (
          <p role="status" className="rounded-card border border-hairline bg-white p-4 text-sm text-ink">
            {message.text}
          </p>
        )}
      </div>
    </div>
  );
}
