'use client';

import * as React from 'react';
import { AlertTriangle, Check, Plus, Sparkles, Trash2, Video } from 'lucide-react';
import {
  Badge,
  Button,
  Card,
  CardBody,
  CardHeader,
  CardTitle,
  ErrorState,
  Field,
  SelectField,
  Sheet,
  Tabs,
  TextArea,
} from '@dokta/ui';
import type { PrescriptionLine } from '@dokta/core';
import type { InteractionWarning } from '@dokta/ai';
import {
  completeConsultation,
  draftNote,
  issueScript,
  saveConsultation,
  screenInteractions,
} from '@/app/consultations/[id]/actions';

interface PatientContext {
  id: string;
  name: string;
  phone: string | null;
  age: number | null;
  gender: string;
  bloodType: string | null;
  allergies: string[];
  history: string[];
  medicalAid: string | null;
  currentMeds: string[];
}

const BLANK: PrescriptionLine = {
  medicineName: '',
  strength: '',
  dosage: '',
  frequency: '',
  quantity: 1,
  substitutable: true,
};

export function ConsultationWorkspace({
  appointmentId,
  consultationId,
  patient,
  reasonForVisit,
  symptoms,
  existing,
  pastConsultations,
  pharmacies,
  isVideo,
}: {
  appointmentId: string;
  consultationId: string;
  patient: PatientContext;
  reasonForVisit: string | null;
  symptoms: string[];
  existing: { notes: string; diagnosis: string };
  pastConsultations: { id: string; date: string; diagnosis: string; doctor: string }[];
  pharmacies: { value: string; label: string }[];
  isVideo: boolean;
}) {
  const [tab, setTab] = React.useState('notes');
  const [notes, setNotes] = React.useState(existing.notes);
  const [diagnosis, setDiagnosis] = React.useState(existing.diagnosis);
  const [icd10, setIcd10] = React.useState('');
  const [saving, setSaving] = React.useState(false);
  const [savedAt, setSavedAt] = React.useState<string | null>(null);
  const [drafting, setDrafting] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  const [scriptOpen, setScriptOpen] = React.useState(false);
  const [lines, setLines] = React.useState<PrescriptionLine[]>([{ ...BLANK }]);
  const [pharmacyId, setPharmacyId] = React.useState('');
  const [repeats, setRepeats] = React.useState(0);
  const [validMonths, setValidMonths] = React.useState(6);
  const [warnings, setWarnings] = React.useState<InteractionWarning[]>([]);
  const [screening, setScreening] = React.useState(false);
  const [issuing, setIssuing] = React.useState(false);
  const [issued, setIssued] = React.useState<string | null>(null);

  async function onSave() {
    setSaving(true);
    setError(null);
    const result = await saveConsultation({
      consultationId,
      appointmentId,
      notes,
      diagnosis,
      icd10Codes: icd10.split(',').map((c) => c.trim()).filter(Boolean),
    });
    setSaving(false);
    if (result.ok) setSavedAt(new Date().toLocaleTimeString('en-ZA', { hour: '2-digit', minute: '2-digit' }));
    else setError(result.error);
  }

  async function onDraft() {
    setDrafting(true);
    setError(null);
    const result = await draftNote({
      chiefComplaint: reasonForVisit ?? symptoms.join(', '),
      rawNotes: notes,
      patientAge: patient.age ?? undefined,
      patientSex: patient.gender.toLowerCase(),
    });
    setDrafting(false);
    if (result.ok) setNotes(result.text);
    else setError(result.error);
  }

  async function onComplete() {
    setSaving(true);
    setError(null);
    await saveConsultation({ consultationId, appointmentId, notes, diagnosis, icd10Codes: [] });
    const result = await completeConsultation(appointmentId);
    setSaving(false);
    if (!result.ok) setError(result.error);
  }

  async function onScreen() {
    const prescribing = lines.map((l) => l.medicineName).filter(Boolean);
    if (prescribing.length === 0) return;

    setScreening(true);
    const result = await screenInteractions({
      prescribing,
      currentMeds: patient.currentMeds,
      allergies: patient.allergies,
    });
    setScreening(false);
    if (result.ok) setWarnings(result.warnings);
  }

  async function onIssue() {
    setIssuing(true);
    setError(null);
    const result = await issueScript({
      appointmentId,
      consultationId,
      patientId: patient.id,
      pharmacyId: pharmacyId || undefined,
      repeats,
      validMonths,
      items: lines.filter((l) => l.medicineName && l.dosage && l.frequency),
    });
    setIssuing(false);

    if (result.ok) {
      setIssued(result.reference);
      setLines([{ ...BLANK }]);
      setWarnings([]);
    } else {
      setError(result.error);
    }
  }

  function updateLine(index: number, patch: Partial<PrescriptionLine>) {
    setLines((current) => current.map((l, i) => (i === index ? { ...l, ...patch } : l)));
  }

  const canIssue = lines.some((l) => l.medicineName && l.dosage && l.frequency);

  return (
    <div className="grid gap-5 p-5 lg:grid-cols-[320px_1fr] lg:p-8">
      {/* Patient context stays visible while the doctor works. */}
      <aside className="space-y-4 lg:sticky lg:top-8 lg:self-start">
        <Card>
          <CardHeader>
            <CardTitle>Patient</CardTitle>
          </CardHeader>
          <CardBody className="space-y-3 text-sm">
            <dl className="grid grid-cols-2 gap-y-2">
              <dt className="text-meta text-muted">Age</dt>
              <dd className="money text-right font-medium">{patient.age ?? 'Not given'}</dd>
              <dt className="text-meta text-muted">Sex</dt>
              <dd className="text-right font-medium capitalize">{patient.gender.toLowerCase()}</dd>
              <dt className="text-meta text-muted">Blood type</dt>
              <dd className="text-right font-medium">{patient.bloodType ?? 'Unknown'}</dd>
              <dt className="text-meta text-muted">Medical aid</dt>
              <dd className="text-right font-medium">{patient.medicalAid ?? 'Private'}</dd>
            </dl>

            {patient.allergies.length > 0 && (
              <div className="rounded-control bg-alert-soft p-3">
                <p className="flex items-center gap-1.5 text-meta font-semibold text-alert">
                  <AlertTriangle className="h-3.5 w-3.5" aria-hidden />
                  Allergies
                </p>
                <p className="mt-1 text-sm text-ink">{patient.allergies.join(', ')}</p>
              </div>
            )}

            {patient.history.length > 0 && (
              <div>
                <p className="text-meta text-muted">History</p>
                <ul className="mt-1 space-y-0.5">
                  {patient.history.map((item) => (
                    <li key={item} className="text-sm">
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {patient.currentMeds.length > 0 && (
              <div>
                <p className="text-meta text-muted">Currently taking</p>
                <ul className="mt-1 space-y-0.5">
                  {patient.currentMeds.map((med) => (
                    <li key={med} className="text-sm">
                      {med}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </CardBody>
        </Card>

        {isVideo && (
          <Button variant="navy" full>
            <Video className="h-4 w-4" aria-hidden />
            Join video room
          </Button>
        )}
      </aside>

      <div className="min-w-0 space-y-5">
        <Card>
          <CardHeader>
            <CardTitle>Reason for visit</CardTitle>
          </CardHeader>
          <CardBody>
            <p className="text-sm text-ink">{reasonForVisit ?? 'Not recorded'}</p>
            {symptoms.length > 0 && (
              <div className="mt-3 flex flex-wrap gap-1.5">
                {symptoms.map((symptom) => (
                  <Badge key={symptom}>{symptom}</Badge>
                ))}
              </div>
            )}
          </CardBody>
        </Card>

        {error && <ErrorState body={error} />}

        <Card>
          <CardBody className="px-0 pb-0 pt-0">
            <Tabs
              className="px-5"
              active={tab}
              onChange={setTab}
              tabs={[
                { id: 'notes', label: 'Notes and diagnosis' },
                { id: 'history', label: 'Past consultations', count: pastConsultations.length },
              ]}
            />

            {tab === 'notes' ? (
              <div className="space-y-4 p-5">
                <TextArea
                  label="Consultation notes"
                  rows={9}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="What the patient reported, what you observed, and what you advised."
                />

                <div className="flex flex-wrap items-center gap-2">
                  <Button variant="outline" size="sm" loading={drafting} onClick={onDraft}>
                    <Sparkles className="h-4 w-4" aria-hidden />
                    Structure into SOAP
                  </Button>
                  <p className="text-meta text-muted">
                    Rewrites what you typed. It adds nothing you did not record.
                  </p>
                </div>

                <div className="grid gap-4 sm:grid-cols-2">
                  <Field
                    label="Diagnosis"
                    value={diagnosis}
                    onChange={(e) => setDiagnosis(e.target.value)}
                    placeholder="Acute bronchitis"
                  />
                  <Field
                    label="ICD-10 codes"
                    value={icd10}
                    onChange={(e) => setIcd10(e.target.value)}
                    hint="Separate multiple codes with commas"
                    placeholder="J20.9"
                  />
                </div>

                <div className="flex flex-wrap items-center gap-3 border-t border-hairline pt-4">
                  <Button variant="outline" loading={saving} onClick={onSave}>
                    Save notes
                  </Button>
                  <Button onClick={() => setScriptOpen(true)}>
                    <Plus className="h-4 w-4" aria-hidden />
                    Write a prescription
                  </Button>
                  <Button variant="navy" loading={saving} onClick={onComplete}>
                    <Check className="h-4 w-4" aria-hidden />
                    Close consultation
                  </Button>
                  {savedAt && <span className="text-meta text-care">Saved at {savedAt}</span>}
                </div>
              </div>
            ) : (
              <div className="p-5">
                {pastConsultations.length === 0 ? (
                  <p className="text-sm text-muted">
                    This is the first consultation recorded for this patient on DOKTA.
                  </p>
                ) : (
                  <ul className="divide-y divide-hairline">
                    {pastConsultations.map((consultation) => (
                      <li key={consultation.id} className="py-3 first:pt-0 last:pb-0">
                        <p className="text-sm font-medium text-ink">{consultation.diagnosis}</p>
                        <p className="text-meta text-muted">
                          {consultation.date} · {consultation.doctor}
                        </p>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            )}
          </CardBody>
        </Card>
      </div>

      <Sheet
        open={scriptOpen}
        onClose={() => setScriptOpen(false)}
        title="Write a prescription"
        description={`For ${patient.name}`}
        width="lg"
        footer={
          <div className="flex items-center justify-between gap-3">
            <Button variant="ghost" onClick={() => setScriptOpen(false)}>
              Close
            </Button>
            <div className="flex gap-2">
              <Button variant="outline" loading={screening} onClick={onScreen} disabled={!canIssue}>
                Check interactions
              </Button>
              <Button loading={issuing} onClick={onIssue} disabled={!canIssue}>
                Issue prescription
              </Button>
            </div>
          </div>
        }
      >
        {issued && (
          <div className="mb-5 rounded-control bg-care-soft p-4">
            <p className="text-sm font-semibold text-care-dark">Prescription {issued} issued</p>
            <p className="mt-0.5 text-meta text-ink/70">
              The patient has been notified{pharmacyId ? ' and the pharmacy can now dispense it' : ''}.
            </p>
          </div>
        )}

        {warnings.length > 0 && (
          <div className="mb-5 space-y-2">
            {warnings.map((warning, i) => (
              <div
                key={i}
                className={`rounded-control p-3 ${warning.severity === 'severe' ? 'bg-alert-soft' : 'bg-warn-soft'}`}
              >
                <p className="flex items-center gap-1.5 text-meta font-semibold">
                  <AlertTriangle
                    className={`h-3.5 w-3.5 ${warning.severity === 'severe' ? 'text-alert' : 'text-warn'}`}
                    aria-hidden
                  />
                  {warning.drugs.join(' with ')} — {warning.severity}
                </p>
                <p className="mt-1 text-sm text-ink">{warning.effect}</p>
                <p className="mt-1 text-meta text-ink/70">{warning.action}</p>
              </div>
            ))}
            <p className="text-meta text-muted">
              These are advisory. You can still issue the prescription.
            </p>
          </div>
        )}

        <div className="space-y-5">
          {lines.map((line, index) => (
            <div key={index} className="rounded-card border border-hairline p-4">
              <div className="mb-3 flex items-center justify-between">
                <p className="text-meta font-medium text-muted">Medicine {index + 1}</p>
                {lines.length > 1 && (
                  <button
                    type="button"
                    onClick={() => setLines((c) => c.filter((_, i) => i !== index))}
                    className="text-muted hover:text-alert"
                    aria-label={`Remove medicine ${index + 1}`}
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                )}
              </div>

              <div className="grid gap-3 sm:grid-cols-2">
                <Field
                  label="Medicine"
                  value={line.medicineName}
                  onChange={(e) => updateLine(index, { medicineName: e.target.value })}
                  placeholder="Amoxil"
                />
                <Field
                  label="Strength"
                  value={line.strength ?? ''}
                  onChange={(e) => updateLine(index, { strength: e.target.value })}
                  placeholder="500mg"
                />
                <Field
                  label="Dosage"
                  value={line.dosage}
                  onChange={(e) => updateLine(index, { dosage: e.target.value })}
                  placeholder="1 capsule"
                />
                <Field
                  label="Frequency"
                  value={line.frequency}
                  onChange={(e) => updateLine(index, { frequency: e.target.value })}
                  placeholder="Three times daily"
                />
                <Field
                  label="Days"
                  type="number"
                  min={1}
                  value={line.durationDays ?? ''}
                  onChange={(e) => updateLine(index, { durationDays: Number(e.target.value) })}
                />
                <Field
                  label="Quantity to dispense"
                  type="number"
                  min={1}
                  value={line.quantity}
                  onChange={(e) => updateLine(index, { quantity: Number(e.target.value) })}
                />
              </div>

              <div className="mt-3">
                <Field
                  label="Instructions for the patient"
                  value={line.instructions ?? ''}
                  onChange={(e) => updateLine(index, { instructions: e.target.value })}
                  placeholder="Take with food. Finish the full course."
                />
              </div>

              <label className="mt-3 flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={line.substitutable ?? true}
                  onChange={(e) => updateLine(index, { substitutable: e.target.checked })}
                  className="h-4 w-4 rounded border-hairline text-care"
                />
                The pharmacy may substitute a generic
              </label>
            </div>
          ))}

          <Button variant="outline" size="sm" onClick={() => setLines((c) => [...c, { ...BLANK }])}>
            <Plus className="h-4 w-4" aria-hidden />
            Add another medicine
          </Button>

          <div className="grid gap-3 border-t border-hairline pt-5 sm:grid-cols-3">
            <SelectField
              label="Send to pharmacy"
              value={pharmacyId}
              onChange={(e) => setPharmacyId(e.target.value)}
              options={[{ value: '', label: 'Let the patient choose' }, ...pharmacies]}
            />
            <SelectField
              label="Repeats"
              value={String(repeats)}
              onChange={(e) => setRepeats(Number(e.target.value))}
              options={[0, 1, 2, 3, 4, 5].map((n) => ({
                value: String(n),
                label: n === 0 ? 'None' : `${n}`,
              }))}
            />
            <SelectField
              label="Valid for"
              value={String(validMonths)}
              onChange={(e) => setValidMonths(Number(e.target.value))}
              options={[1, 3, 6, 12].map((n) => ({
                value: String(n),
                label: `${n} month${n > 1 ? 's' : ''}`,
              }))}
            />
          </div>
        </div>
      </Sheet>
    </div>
  );
}
