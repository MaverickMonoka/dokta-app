import * as React from 'react';
import { Text, View } from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { Redirect } from 'expo-router';
import { api, ApiError, Button, Card, ErrorNote, Screen, theme } from '@dokta/mobile-ui';
import { money } from '@dokta/shared';
import { useSession } from '@/lib/session';

interface Product {
  name: string;
  strength: string | null;
  unitPrice: number;
  stockOnHand: number;
  requiresPharmacist: boolean;
  schedule: string;
}

/**
 * Shelf-side stock check. The counter till stays on the web dashboard where the
 * cash drawer and slip printer are; this is for checking price and stock while
 * standing at the shelf, which is where the question actually gets asked.
 */
export default function Scanner() {
  const { session, loading, signOut } = useSession();
  const [permission, requestPermission] = useCameraPermissions();
  const [product, setProduct] = React.useState<Product | null>(null);
  const [error, setError] = React.useState<string | null>(null);
  const [busy, setBusy] = React.useState(false);
  const lastScan = React.useRef<string>('');

  async function onScanned({ data }: { data: string }) {
    if (busy || data === lastScan.current) return;
    lastScan.current = data;
    setBusy(true);
    setError(null);

    try {
      setProduct(await api<Product>(`/api/pharmacy/lookup?barcode=${encodeURIComponent(data)}`));
    } catch (e) {
      if (e instanceof ApiError && e.status === 401) return signOut();
      setProduct(null);
      setError(e instanceof Error ? e.message : 'Could not look that up.');
    } finally {
      setBusy(false);
      // Allow a re-scan of the same item after a moment.
      setTimeout(() => (lastScan.current = ''), 2500);
    }
  }

  if (loading) return null;
  if (!session) return <Redirect href="/sign-in" />;

  if (!permission?.granted) {
    return (
      <Screen>
        <Text style={theme.text.title}>Camera access needed</Text>
        <Text style={[theme.text.meta, { marginTop: 6, marginBottom: theme.space(5) }]}>
          The scanner uses the camera to read barcodes on the shelf. Nothing is recorded or stored.
        </Text>
        <Button label="Allow camera" onPress={requestPermission} />
      </Screen>
    );
  }

  return (
    <View style={{ flex: 1 }}>
      <CameraView
        style={{ flex: 1 }}
        barcodeScannerSettings={{ barcodeTypes: ['ean13', 'ean8', 'code128', 'upc_a'] }}
        onBarcodeScanned={onScanned}
      />

      <View style={{ padding: theme.space(5), gap: theme.space(3) }}>
        {error && <ErrorNote message={error} />}

        {product ? (
          <Card>
            <Text style={{ fontSize: 17, fontWeight: '700' }}>{product.name}</Text>
            <Text style={theme.text.meta}>{product.strength ?? '—'}</Text>

            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                marginTop: theme.space(4),
              }}
            >
              <View>
                <Text style={theme.text.meta}>Price</Text>
                <Text style={{ fontSize: 20, fontWeight: '700' }}>{money(product.unitPrice)}</Text>
              </View>
              <View>
                <Text style={theme.text.meta}>On hand</Text>
                <Text
                  style={{
                    fontSize: 20,
                    fontWeight: '700',
                    color: product.stockOnHand === 0 ? theme.color.red : theme.color.ink,
                  }}
                >
                  {product.stockOnHand}
                </Text>
              </View>
              <View>
                <Text style={theme.text.meta}>Schedule</Text>
                <Text style={{ fontSize: 20, fontWeight: '700' }}>{product.schedule}</Text>
              </View>
            </View>

            {product.requiresPharmacist && (
              <Text style={{ color: theme.color.amber, fontSize: 13, marginTop: theme.space(3) }}>
                Scheduled medicine. A pharmacist must authorise this sale.
              </Text>
            )}
          </Card>
        ) : (
          <Text style={[theme.text.meta, { textAlign: 'center' }]}>
            Point the camera at a barcode to see price and stock.
          </Text>
        )}
      </View>
    </View>
  );
}
