import { NextResponse, type NextRequest } from 'next/server';
import { gateway, type GatewayId } from '@dokta/payments';
import { failPayment, settlePayment } from '@dokta/core';

const SUPPORTED: GatewayId[] = ['yoco', 'payfast', 'ozow', 'snapscan'];

/**
 * One endpoint per gateway, all handled here. The body is read raw because
 * every signature scheme hashes the exact bytes that were sent — parsing first
 * would change the whitespace and break verification.
 *
 * A 200 is returned even for payloads we ignore: gateways retry non-2xx
 * responses, and retrying a forged callback forever helps nobody. What matters
 * is that `ignored` never advances an order.
 */
export async function POST(request: NextRequest, { params }: { params: { gateway: string } }) {
  const id = params.gateway as GatewayId;
  if (!SUPPORTED.includes(id)) {
    return NextResponse.json({ error: 'Unknown gateway' }, { status: 404 });
  }

  const rawBody = await request.text();
  const headers = Object.fromEntries(
    Array.from(request.headers.entries()).map(([k, v]) => [k.toLowerCase(), v]),
  );

  let outcome;
  try {
    outcome = await gateway(id).handleWebhook(rawBody, headers);
  } catch (error) {
    console.error(`[webhook:${id}] verification threw`, error);
    return NextResponse.json({ received: true, handled: false }, { status: 200 });
  }

  if (outcome.status === 'ignored') {
    console.warn(`[webhook:${id}] ignored`, outcome.reason);
    return NextResponse.json({ received: true, handled: false }, { status: 200 });
  }

  try {
    if (outcome.status === 'succeeded') {
      await settlePayment(outcome.reference, outcome.gatewayRef, outcome.amountCents);
    } else {
      await failPayment(outcome.reference, outcome.gatewayRef, outcome.reason);
    }
  } catch (error) {
    // Signature was valid but we could not apply it. Return 500 so the gateway
    // retries — this is the one case where a retry is what we want.
    console.error(`[webhook:${id}] could not apply outcome`, error);
    return NextResponse.json({ received: true, handled: false }, { status: 500 });
  }

  return NextResponse.json({ received: true, handled: true });
}
