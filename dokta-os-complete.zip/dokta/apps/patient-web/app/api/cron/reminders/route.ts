import { NextResponse, type NextRequest } from 'next/server';
import { db } from '@dokta/database';
import { notify } from '@dokta/notifications';

export const dynamic = 'force-dynamic';
export const maxDuration = 60;

/**
 * Runs hourly. Reminds patients about appointments starting in roughly 24
 * hours, and expires prescriptions past their validity date.
 *
 * The window is the hour ahead of the 24-hour mark, so an hourly schedule
 * sends each reminder exactly once without needing a "reminded" column.
 */
export async function GET(request: NextRequest) {
  if (request.headers.get('authorization') !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: 'Unauthorised' }, { status: 401 });
  }

  const from = new Date(Date.now() + 24 * 3_600_000);
  const to = new Date(from.getTime() + 3_600_000);

  const upcoming = await db.appointment.findMany({
    where: { status: 'CONFIRMED', scheduledFor: { gte: from, lt: to } },
    select: {
      id: true,
      scheduledFor: true,
      patient: { select: { userId: true } },
      doctor: { select: { user: { select: { name: true } } } },
    },
  });

  const results = await Promise.allSettled(
    upcoming.map((appointment) =>
      notify({
        userId: appointment.patient.userId,
        template: 'appointment_reminder',
        data: {
          doctorName: appointment.doctor.user.name,
          when: appointment.scheduledFor,
        },
        channels: ['PUSH', 'SMS', 'IN_APP'],
      }),
    ),
  );

  const expired = await db.prescription.updateMany({
    where: { validUntil: { lt: new Date() }, status: { notIn: ['EXPIRED', 'CANCELLED', 'COLLECTED'] } },
    data: { status: 'EXPIRED' },
  });

  // No-shows: confirmed appointments whose slot passed two hours ago.
  const noShows = await db.appointment.updateMany({
    where: { status: 'CONFIRMED', scheduledFor: { lt: new Date(Date.now() - 2 * 3_600_000) } },
    data: { status: 'NO_SHOW' },
  });

  return NextResponse.json({
    remindersSent: results.filter((r) => r.status === 'fulfilled').length,
    remindersFailed: results.filter((r) => r.status === 'rejected').length,
    prescriptionsExpired: expired.count,
    markedNoShow: noShows.count,
  });
}
