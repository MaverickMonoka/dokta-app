import { NextResponse, type NextRequest } from 'next/server';
import { db } from '@dokta/database';
import { doctorQueue } from '@dokta/core';
import { audit } from '@dokta/auth';
import { can } from '@dokta/shared';
import { bearerSession } from '@/lib/bearer-session';

export async function GET(request: NextRequest) {
  const session = await bearerSession(request);
  if (!session || !can(session.role as never, 'queue:read')) {
    return NextResponse.json({ error: 'Not permitted' }, { status: 403 });
  }

  const doctor = await db.doctor.findUnique({ where: { userId: session.id }, select: { id: true } });
  if (!doctor) return NextResponse.json({ queue: [] });

  const queue = await doctorQueue(doctor.id);

  await audit({
    actorId: session.id,
    action: 'read',
    entity: 'Appointment',
    lawfulBasis: 'provision_of_healthcare',
    metadata: { count: queue.length, surface: 'mobile' },
  });

  return NextResponse.json({
    queue: queue.map((a) => ({
      id: a.id,
      scheduledFor: a.scheduledFor.toISOString(),
      status: a.status,
      type: a.type,
      patientName: a.patient.user.name,
      reasonForVisit: a.reasonForVisit,
      allergies: (a.patient.allergies as string[]) ?? [],
    })),
  });
}
