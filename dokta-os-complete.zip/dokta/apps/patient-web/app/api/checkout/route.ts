import { NextResponse, type NextRequest } from 'next/server';
import { z } from 'zod';
import { getSession } from '@dokta/auth';
import { DomainError, startCheckout } from '@dokta/core';

const schema = z
  .object({
    gateway: z.enum(['yoco', 'payfast', 'ozow', 'snapscan']),
    appointmentId: z.string().uuid().optional(),
    orderId: z.string().uuid().optional(),
  })
  .refine((v) => Boolean(v.appointmentId) !== Boolean(v.orderId), {
    message: 'Pay for exactly one of an appointment or an order',
  });

export async function POST(request: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: 'Sign in to pay' }, { status: 401 });

  const parsed = schema.safeParse(await request.json());
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0].message }, { status: 400 });
  }

  try {
    const result = await startCheckout({
      userId: session.id,
      gatewayId: parsed.data.gateway,
      appointmentId: parsed.data.appointmentId,
      orderId: parsed.data.orderId,
      appUrl: process.env.APP_URL ?? request.nextUrl.origin,
    });

    return NextResponse.json(result);
  } catch (error) {
    if (error instanceof DomainError) {
      return NextResponse.json({ error: error.message }, { status: error.status });
    }
    console.error('[checkout] failed', error);
    return NextResponse.json({ error: 'Could not open a payment. Try again.' }, { status: 500 });
  }
}
