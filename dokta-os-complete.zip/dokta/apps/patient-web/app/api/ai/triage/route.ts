import { NextResponse, type NextRequest } from 'next/server';
import { z } from 'zod';
import { getSession } from '@dokta/auth';
import { db } from '@dokta/database';
import { triageSymptoms } from '@dokta/ai';

const schema = z.object({
  symptoms: z.array(z.string().min(1)).min(1, 'Describe at least one symptom'),
  duration: z.string().min(1),
});

/**
 * Symptom triage. Returns urgency and what to watch for — never a diagnosis.
 * Emergency answers are returned with the emergency number attached so the
 * interface does not have to know when to show it.
 */
export async function POST(request: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: 'Sign in first' }, { status: 401 });

  const parsed = schema.safeParse(await request.json());
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0].message }, { status: 400 });
  }

  const patient = await db.patient.findUnique({
    where: { userId: session.id },
    select: { dateOfBirth: true, medicalHistory: true },
  });

  const age = patient?.dateOfBirth
    ? Math.floor((Date.now() - patient.dateOfBirth.getTime()) / 31_557_600_000)
    : undefined;

  try {
    const result = await triageSymptoms({
      symptoms: parsed.data.symptoms,
      duration: parsed.data.duration,
      age,
      chronicConditions: (patient?.medicalHistory as string[]) ?? [],
    });

    return NextResponse.json({
      ...result,
      emergencyNumber: result.urgency === 'emergency' ? '10177' : null,
      disclaimer:
        'This is guidance on how soon to see someone, not a diagnosis. A doctor decides what is wrong.',
    });
  } catch (error) {
    console.error('[triage] failed', error);
    return NextResponse.json(
      { error: 'The symptom assistant is unavailable. Book a consultation to speak to a doctor.' },
      { status: 503 },
    );
  }
}
