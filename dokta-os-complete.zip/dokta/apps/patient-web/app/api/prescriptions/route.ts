import { NextResponse, type NextRequest } from 'next/server';
import { db } from '@dokta/database';
import { audit } from '@dokta/auth';
import { bearerSession } from '@/lib/bearer-session';

export async function GET(request: NextRequest) {
  const session = await bearerSession(request);
  if (!session) return NextResponse.json({ error: 'Sign in first' }, { status: 401 });

  const patient = await db.patient.findUnique({ where: { userId: session.id }, select: { id: true } });
  if (!patient) return NextResponse.json({ prescriptions: [] });

  const prescriptions = await db.prescription.findMany({
    where: { patientId: patient.id },
    orderBy: { createdAt: 'desc' },
    take: 20,
    select: {
      id: true,
      reference: true,
      status: true,
      validUntil: true,
      repeats: true,
      repeatsUsed: true,
      items: { select: { medicineName: true, strength: true, dosage: true, frequency: true } },
      doctor: { select: { user: { select: { name: true } } } },
      pharmacy: { select: { name: true } },
    },
  });

  await audit({
    actorId: session.id,
    action: 'read',
    entity: 'Prescription',
    subjectId: patient.id,
    lawfulBasis: 'data_subject_access',
  });

  return NextResponse.json({
    prescriptions: prescriptions.map((rx) => ({
      id: rx.id,
      reference: rx.reference,
      status: rx.status,
      validUntil: rx.validUntil.toISOString(),
      repeatsLeft: rx.repeats - rx.repeatsUsed,
      doctorName: rx.doctor.user.name,
      pharmacyName: rx.pharmacy?.name ?? null,
      items: rx.items.map((i) => ({
        name: `${i.medicineName}${i.strength ? ` ${i.strength}` : ''}`,
        dosage: i.dosage,
        frequency: i.frequency,
      })),
    })),
  });
}
