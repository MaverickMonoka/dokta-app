import { NextResponse, type NextRequest } from 'next/server';
import { db } from '@dokta/database';
import { DomainError, bookAppointment } from '@dokta/core';
import { bookAppointmentSchema } from '@dokta/shared';
import { bearerSession } from '@/lib/bearer-session';

/** Upcoming and recent appointments for the signed-in patient. */
export async function GET(request: NextRequest) {
  const session = await bearerSession(request);
  if (!session) return NextResponse.json({ error: 'Sign in first' }, { status: 401 });

  const patient = await db.patient.findUnique({ where: { userId: session.id }, select: { id: true } });
  if (!patient) return NextResponse.json({ appointments: [] });

  const appointments = await db.appointment.findMany({
    where: { patientId: patient.id },
    orderBy: { scheduledFor: 'desc' },
    take: 20,
    select: {
      id: true,
      reference: true,
      scheduledFor: true,
      type: true,
      status: true,
      paymentStatus: true,
      fee: true,
      doctor: { select: { speciality: true, user: { select: { name: true, avatarUrl: true } } } },
    },
  });

  return NextResponse.json({
    appointments: appointments.map((a) => ({
      id: a.id,
      reference: a.reference,
      scheduledFor: a.scheduledFor.toISOString(),
      type: a.type,
      status: a.status,
      paid: a.paymentStatus === 'SUCCEEDED',
      fee: Number(a.fee),
      doctorName: a.doctor.user.name,
      doctorAvatar: a.doctor.user.avatarUrl,
      speciality: a.doctor.speciality,
    })),
  });
}

export async function POST(request: NextRequest) {
  const session = await bearerSession(request);
  if (!session) return NextResponse.json({ error: 'Sign in first' }, { status: 401 });

  const parsed = bookAppointmentSchema.safeParse(await request.json());
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0].message }, { status: 400 });
  }

  const patient = await db.patient.findUnique({ where: { userId: session.id }, select: { id: true } });
  if (!patient) {
    return NextResponse.json({ error: 'Complete your profile before booking' }, { status: 400 });
  }

  try {
    const appointment = await bookAppointment({ patientId: patient.id, ...parsed.data });
    return NextResponse.json(
      { id: appointment.id, reference: appointment.reference, fee: Number(appointment.fee) },
      { status: 201 },
    );
  } catch (error) {
    if (error instanceof DomainError) {
      return NextResponse.json({ error: error.message }, { status: error.status });
    }
    throw error;
  }
}
