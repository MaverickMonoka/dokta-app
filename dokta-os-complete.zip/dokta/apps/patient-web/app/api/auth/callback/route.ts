import { NextResponse, type NextRequest } from 'next/server';
import { supabaseServer } from '@dokta/auth';
import { db } from '@dokta/database';
import { homeRouteFor, type Role } from '@dokta/shared';

/**
 * Exchanges the Supabase auth code for a session, then makes sure a matching
 * row exists in our own `users` table. Supabase owns the credential; we own
 * the profile, and the two are joined by the same UUID.
 */
export async function GET(request: NextRequest) {
  const { searchParams, origin } = request.nextUrl;
  const code = searchParams.get('code');
  const next = searchParams.get('next');

  if (!code) {
    return NextResponse.redirect(`${origin}/sign-in?error=missing_code`);
  }

  const supabase = supabaseServer();
  const { data, error } = await supabase.auth.exchangeCodeForSession(code);

  if (error || !data.user) {
    return NextResponse.redirect(`${origin}/sign-in?error=exchange_failed`);
  }

  const { user } = data;
  const role = ((user.user_metadata?.role as Role) ?? 'PATIENT') as Role;

  const profile = await db.user.upsert({
    where: { id: user.id },
    update: { lastSeenAt: new Date() },
    create: {
      id: user.id,
      email: user.email!,
      name: (user.user_metadata?.name as string) ?? user.email!.split('@')[0],
      phone: (user.user_metadata?.phone as string) ?? null,
      role,
      lastSeenAt: new Date(),
    },
  });

  // A patient profile is created on first sign-in so booking never blocks on it.
  if (profile.role === 'PATIENT') {
    await db.patient.upsert({ where: { userId: profile.id }, update: {}, create: { userId: profile.id } });
  }

  return NextResponse.redirect(`${origin}${next ?? homeRouteFor[profile.role as Role]}`);
}
