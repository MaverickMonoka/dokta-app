import { NextResponse, type NextRequest } from 'next/server';
import { db } from '@dokta/database';
import { DomainError, scanBarcode } from '@dokta/core';
import { can } from '@dokta/shared';
import { bearerSession } from '@/lib/bearer-session';

export async function GET(request: NextRequest) {
  const session = await bearerSession(request);
  if (!session || !can(session.role as never, 'inventory:manage')) {
    return NextResponse.json({ error: 'Not permitted' }, { status: 403 });
  }

  const barcode = request.nextUrl.searchParams.get('barcode');
  if (!barcode) return NextResponse.json({ error: 'No barcode given' }, { status: 400 });

  const owned = await db.pharmacy.findFirst({ where: { ownerId: session.id }, select: { id: true } });
  const staff = owned
    ? null
    : await db.pharmacyStaff.findFirst({ where: { userId: session.id }, select: { pharmacyId: true } });

  const pharmacyId = owned?.id ?? staff?.pharmacyId;
  if (!pharmacyId) {
    return NextResponse.json({ error: 'This account is not linked to a pharmacy' }, { status: 400 });
  }

  try {
    const product = await scanBarcode(pharmacyId, barcode);
    return NextResponse.json(product);
  } catch (error) {
    if (error instanceof DomainError) {
      return NextResponse.json({ error: error.message }, { status: error.status });
    }
    throw error;
  }
}
