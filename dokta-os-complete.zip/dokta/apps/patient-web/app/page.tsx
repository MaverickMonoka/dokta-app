import Image from 'next/image';
import Link from 'next/link';
import { Phone, Stethoscope, Pill, ShieldCheck, Video } from 'lucide-react';
import { buttonVariants } from '@dokta/ui';
import { AvailabilityPanel } from '@/components/availability-panel';
import { SiteHeader } from '@/components/site-header';

/**
 * The hero shows the product working rather than describing it: the panel on
 * the right is the real doctor-availability list, which is the thing a person
 * actually came here for. Everything else on the page is quiet by comparison.
 */
export default function LandingPage() {
  return (
    <div className="min-h-dvh bg-navy on-navy">
      <SiteHeader />

      <main id="main">
        <section className="mx-auto grid max-w-7xl gap-10 px-5 pb-16 pt-8 lg:grid-cols-[1fr_460px] lg:items-center lg:gap-16 lg:px-8 lg:pb-24 lg:pt-14">
          <div>
            <h1 className="max-w-[13ch] font-display text-[2.75rem] font-bold leading-[1.04] tracking-tight text-white sm:text-display-1">
              See a doctor today, without leaving home
            </h1>
            <p className="mt-5 max-w-[46ch] text-lede text-white/70">
              Video consultations with registered South African doctors, a prescription
              sent straight to your pharmacy, and medicine delivered to your door.
            </p>

            <div className="mt-8 flex flex-wrap gap-3">
              <Link href="/doctors" className={buttonVariants({ size: 'lg', className: 'px-8' })}>
                Find a doctor
              </Link>
              <Link href="/pharmacies" className={buttonVariants({ variant: 'onNavy', size: 'lg' })}>
                Order medicine
              </Link>
            </div>

            <dl className="mt-12 grid max-w-lg grid-cols-3 gap-6 border-t border-white/10 pt-6">
              <div>
                <dt className="text-meta text-white/50">Consultation from</dt>
                <dd className="money mt-1 font-display text-xl font-bold text-white">R250</dd>
              </div>
              <div>
                <dt className="text-meta text-white/50">Typical wait</dt>
                <dd className="mt-1 font-display text-xl font-bold text-white">12 min</dd>
              </div>
              <div>
                <dt className="text-meta text-white/50">Delivery</dt>
                <dd className="mt-1 font-display text-xl font-bold text-white">Same day</dd>
              </div>
            </dl>
          </div>

          <AvailabilityPanel />
        </section>

        <section className="bg-canvas py-14 lg:py-20">
          <div className="mx-auto max-w-7xl px-5 lg:px-8">
            <h2 className="max-w-[20ch] font-display text-display-2 text-ink">
              Three things, and they work together
            </h2>

            <div className="mt-9 grid gap-5 md:grid-cols-3">
              <Pathway
                icon={Video}
                title="Consult by video"
                body="Pick a doctor by speciality, price and language. Join from your phone — no app download needed for the call."
                image="https://images.unsplash.com/photo-1584515933487-779824d29309?auto=format&fit=crop&w=800&q=70"
                alt="A doctor speaking with a patient during a video consultation"
                href="/doctors"
                cta="Browse doctors"
              />
              <Pathway
                icon={Stethoscope}
                title="Keep your records"
                body="Test results, past consultations and chronic medication in one place. Share them with any doctor you see, in one tap."
                image="https://images.unsplash.com/photo-1559757148-5c350d0d3c56?auto=format&fit=crop&w=800&q=70"
                alt="A clinician reviewing a patient's medical file"
                href="/sign-up"
                cta="Create your profile"
              />
              <Pathway
                icon={Pill}
                title="Get your medicine"
                body="Your prescription goes to a pharmacy near you. Collect it, or have it delivered the same day."
                image="https://images.unsplash.com/photo-1576602976047-174e57a47881?auto=format&fit=crop&w=800&q=70"
                alt="A pharmacist preparing a prescription behind the counter"
                href="/pharmacies"
                cta="Find a pharmacy"
              />
            </div>
          </div>
        </section>

        <section className="bg-alert">
          <div className="mx-auto flex max-w-7xl flex-col gap-4 px-5 py-6 sm:flex-row sm:items-center sm:justify-between lg:px-8">
            <div className="flex items-start gap-3">
              <Phone className="mt-0.5 h-5 w-5 shrink-0 text-white" aria-hidden />
              <p className="max-w-prose text-sm text-white">
                DOKTA is not for emergencies. For chest pain, difficulty breathing, stroke
                signs or severe bleeding, call 10177 or go to your nearest hospital.
              </p>
            </div>
            <a
              href="tel:10177"
              className="shrink-0 rounded-control bg-white px-5 py-2.5 text-sm font-semibold text-alert"
            >
              Call 10177
            </a>
          </div>
        </section>
      </main>

      <footer className="border-t border-white/10 py-10">
        <div className="mx-auto flex max-w-7xl flex-col gap-6 px-5 sm:flex-row sm:items-center sm:justify-between lg:px-8">
          <div className="flex items-center gap-2.5 text-white/60">
            <ShieldCheck className="h-4 w-4" aria-hidden />
            <p className="text-meta">
              POPIA compliant. Your health records are encrypted and never sold.
            </p>
          </div>
          <nav className="flex flex-wrap gap-x-6 gap-y-2 text-meta text-white/60">
            <Link href="/legal/privacy" className="hover:text-white">
              Privacy
            </Link>
            <Link href="/legal/terms" className="hover:text-white">
              Terms
            </Link>
            <Link href="/for-doctors" className="hover:text-white">
              For doctors
            </Link>
            <Link href="/for-pharmacies" className="hover:text-white">
              For pharmacies
            </Link>
          </nav>
        </div>
      </footer>
    </div>
  );
}

function Pathway({
  icon: Icon,
  title,
  body,
  image,
  alt,
  href,
  cta,
}: {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  body: string;
  image: string;
  alt: string;
  href: string;
  cta: string;
}) {
  return (
    <article className="overflow-hidden rounded-card border border-hairline bg-white">
      <div className="relative h-44">
        <Image src={image} alt={alt} fill sizes="(max-width: 768px) 100vw, 33vw" className="object-cover" />
      </div>
      <div className="p-5">
        <div className="flex items-center gap-2.5">
          <Icon className="h-4 w-4 text-care" />
          <h3 className="font-display text-title text-ink">{title}</h3>
        </div>
        <p className="mt-2 text-sm leading-relaxed text-ink/70">{body}</p>
        <Link
          href={href}
          className="mt-4 inline-block text-sm font-semibold text-care hover:text-care-dark"
        >
          {cta}
        </Link>
      </div>
    </article>
  );
}
