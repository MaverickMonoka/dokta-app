import Link from 'next/link';
import { CalendarClock, FileText, Pill, Wallet, Package, Video } from 'lucide-react';
import { requireCapability, audit } from '@dokta/auth';
import { db } from '@dokta/database';
import { money, shortDate, time } from '@dokta/shared';
import { Badge, Card, CardBody, CardHeader, CardTitle, EmptyState, buttonVariants } from '@dokta/ui';

export const metadata = { title: 'Your health' };
export const dynamic = 'force-dynamic';

export default async function PatientDashboard() {
  const session = await requireCapability('health:read:own', '/dashboard');

  const patient = await db.patient.findUnique({
    where: { userId: session.id },
    select: { id: true, walletBalance: true },
  });

  if (!patient) {
    return (
      <main className="mx-auto max-w-3xl px-5 py-16">
        <EmptyState
          icon={FileText}
          title="Finish setting up your profile"
          body="We need your date of birth and contact details before you can book a consultation."
          action={{ label: 'Complete profile', href: '/profile' }}
        />
      </main>
    );
  }

  await audit({
    actorId: session.id,
    action: 'read',
    entity: 'Patient',
    entityId: patient.id,
    subjectId: patient.id,
    lawfulBasis: 'data_subject_access',
  });

  const [nextAppointment, prescriptions, orders, documentCount] = await Promise.all([
    db.appointment.findFirst({
      where: {
        patientId: patient.id,
        status: { in: ['CONFIRMED', 'IN_PROGRESS'] },
        scheduledFor: { gte: new Date() },
      },
      orderBy: { scheduledFor: 'asc' },
      select: {
        id: true,
        scheduledFor: true,
        type: true,
        status: true,
        reference: true,
        doctor: { select: { speciality: true, user: { select: { name: true } } } },
      },
    }),
    db.prescription.findMany({
      where: { patientId: patient.id, status: { notIn: ['COLLECTED', 'CANCELLED', 'EXPIRED'] } },
      orderBy: { createdAt: 'desc' },
      take: 3,
      select: {
        id: true,
        reference: true,
        status: true,
        validUntil: true,
        items: { select: { medicineName: true, strength: true } },
      },
    }),
    db.order.findMany({
      where: { patientId: patient.id, status: { notIn: ['DELIVERED', 'CANCELLED', 'CART'] } },
      orderBy: { createdAt: 'desc' },
      take: 3,
      select: {
        id: true,
        reference: true,
        status: true,
        total: true,
        pharmacy: { select: { name: true } },
      },
    }),
    db.medicalDocument.count({ where: { patientId: patient.id } }),
  ]);

  return (
    <main className="mx-auto max-w-7xl px-5 py-8 lg:px-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <h1 className="font-display text-display-2 text-ink">
          {session.name.split(' ')[0]}&rsquo;s health
        </h1>
        <Link href="/doctors" className={buttonVariants()}>
          Book a consultation
        </Link>
      </div>

      <div className="mt-7 grid gap-5 lg:grid-cols-3">
        {/* Next appointment leads: it is the only thing here that is time-critical. */}
        <Card tone="navy" className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-white/70">Next appointment</CardTitle>
            {nextAppointment && <Badge tone="onNavy">{nextAppointment.reference}</Badge>}
          </CardHeader>
          <CardBody>
            {nextAppointment ? (
              <>
                <p className="font-display text-[1.75rem] font-bold leading-tight text-white">
                  {nextAppointment.doctor.user.name}
                </p>
                <p className="mt-1 text-sm text-white/60">{nextAppointment.doctor.speciality}</p>
                <p className="mt-4 flex items-center gap-2 text-sm text-white">
                  <CalendarClock className="h-4 w-4 text-care" aria-hidden />
                  {shortDate(nextAppointment.scheduledFor)} at {time(nextAppointment.scheduledFor)}
                </p>
                {nextAppointment.type === 'VIDEO' && (
                  <Link
                    href={`/consultations/${nextAppointment.id}`}
                    className={buttonVariants({ className: 'mt-5' })}
                  >
                    <Video className="h-4 w-4" aria-hidden />
                    Join consultation
                  </Link>
                )}
              </>
            ) : (
              <div className="py-2">
                <p className="text-white/70">You have no appointments booked.</p>
                <Link
                  href="/doctors"
                  className={buttonVariants({ variant: 'onNavy', className: 'mt-4' })}
                >
                  Find a doctor
                </Link>
              </div>
            )}
          </CardBody>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Health wallet</CardTitle>
            <Wallet className="h-4 w-4 text-muted" aria-hidden />
          </CardHeader>
          <CardBody>
            <p className="money font-display text-[1.75rem] font-bold leading-none text-ink">
              {money(Number(patient.walletBalance))}
            </p>
            <p className="mt-2 text-meta text-muted">
              Credit is used automatically at checkout for consultations and medicine.
            </p>
            <Link
              href="/wallet/top-up"
              className={buttonVariants({ variant: 'outline', size: 'sm', className: 'mt-4' })}
            >
              Add money
            </Link>
          </CardBody>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Prescriptions</CardTitle>
            <Pill className="h-4 w-4 text-muted" aria-hidden />
          </CardHeader>
          <CardBody>
            {prescriptions.length === 0 ? (
              <p className="py-3 text-sm text-muted">
                Nothing to fill. A doctor can issue a prescription during your consultation.
              </p>
            ) : (
              <ul className="space-y-3">
                {prescriptions.map((rx) => (
                  <li key={rx.id}>
                    <Link href={`/prescriptions/${rx.id}`} className="block">
                      <div className="flex items-start justify-between gap-3">
                        <p className="text-sm font-medium text-ink">
                          {rx.items[0]?.medicineName}
                          {rx.items.length > 1 && (
                            <span className="text-muted"> +{rx.items.length - 1} more</span>
                          )}
                        </p>
                        <Badge status={rx.status} />
                      </div>
                      <p className="mt-0.5 text-meta text-muted">
                        Valid until {shortDate(rx.validUntil)}
                      </p>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </CardBody>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Medicine orders</CardTitle>
            <Package className="h-4 w-4 text-muted" aria-hidden />
          </CardHeader>
          <CardBody>
            {orders.length === 0 ? (
              <p className="py-3 text-sm text-muted">No orders on the way.</p>
            ) : (
              <ul className="space-y-3">
                {orders.map((order) => (
                  <li key={order.id}>
                    <Link href={`/orders/${order.id}`} className="block">
                      <div className="flex items-start justify-between gap-3">
                        <p className="text-sm font-medium text-ink">{order.pharmacy.name}</p>
                        <Badge status={order.status} />
                      </div>
                      <p className="money mt-0.5 text-meta text-muted">
                        {order.reference} · {money(Number(order.total))}
                      </p>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </CardBody>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Medical records</CardTitle>
            <FileText className="h-4 w-4 text-muted" aria-hidden />
          </CardHeader>
          <CardBody>
            <p className="font-display text-[1.75rem] font-bold leading-none text-ink">
              {documentCount}
            </p>
            <p className="mt-2 text-meta text-muted">
              {documentCount === 0
                ? 'Upload test results and referral letters so any doctor you see has your history.'
                : 'Test results, letters and past consultations.'}
            </p>
            <Link
              href="/records"
              className={buttonVariants({ variant: 'outline', size: 'sm', className: 'mt-4' })}
            >
              {documentCount === 0 ? 'Upload a document' : 'Open records'}
            </Link>
          </CardBody>
        </Card>
      </div>
    </main>
  );
}
