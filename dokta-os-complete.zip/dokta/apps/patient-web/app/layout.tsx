import type { Metadata, Viewport } from 'next';
import { Inter, Plus_Jakarta_Sans } from 'next/font/google';
import './globals.css';

const body = Inter({
  subsets: ['latin'],
  variable: '--font-body',
  display: 'swap',
});

const display = Plus_Jakarta_Sans({
  subsets: ['latin'],
  weight: ['600', '700'],
  variable: '--font-display',
  display: 'swap',
});

export const metadata: Metadata = {
  title: {
    default: 'DOKTA — see a doctor, get your medicine',
    template: '%s · DOKTA',
  },
  description:
    'Book a doctor, consult by video, and have your prescription filled and delivered. Built for South Africa.',
  metadataBase: new URL(process.env.APP_URL ?? 'https://dokta.africa'),
  openGraph: {
    title: 'DOKTA',
    description: 'See a doctor and get your medicine, wherever you are.',
    locale: 'en_ZA',
    type: 'website',
  },
};

export const viewport: Viewport = {
  themeColor: '#0B2137',
  width: 'device-width',
  initialScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en-ZA" className={`${body.variable} ${display.variable}`}>
      <body>
        <a
          href="#main"
          className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:rounded-control focus:bg-white focus:px-4 focus:py-2 focus:text-navy"
        >
          Skip to content
        </a>
        {children}
      </body>
    </html>
  );
}
