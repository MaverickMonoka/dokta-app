import type { NextRequest } from 'next/server';
import { supabaseAdmin } from '@dokta/auth';
import { db } from '@dokta/database';

/**
 * Session for API callers that send a bearer token rather than a cookie —
 * the mobile apps. The token is verified against Supabase on every request;
 * we never trust a user id sent by the client.
 */
export async function bearerSession(request: NextRequest) {
  const header = request.headers.get('authorization');
  if (!header?.startsWith('Bearer ')) return null;

  const {
    data: { user },
    error,
  } = await supabaseAdmin().auth.getUser(header.slice(7));

  if (error || !user) return null;

  const profile = await db.user.findUnique({
    where: { id: user.id },
    select: { id: true, name: true, email: true, role: true, isActive: true },
  });

  if (!profile?.isActive) return null;
  return profile;
}
