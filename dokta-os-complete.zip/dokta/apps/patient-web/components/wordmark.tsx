/**
 * The wordmark is set in the display face with a cross cut from the O counter —
 * the medical mark and the letterform are the same shape, so the logo works
 * down to a 16px favicon without a separate icon file.
 */
export function Wordmark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 168 32" role="img" aria-label="DOKTA" className={className} fill="none">
      <text
        x="0"
        y="25"
        fontFamily="var(--font-display), 'Plus Jakarta Sans', sans-serif"
        fontSize="27"
        fontWeight="700"
        letterSpacing="-0.5"
        fill="currentColor"
      >
        D
      </text>
      <circle cx="36" cy="16" r="12.5" stroke="currentColor" strokeWidth="5" />
      <path d="M36 10.5v11M30.5 16h11" stroke="#059669" strokeWidth="3.4" strokeLinecap="round" />
      <text
        x="54"
        y="25"
        fontFamily="var(--font-display), 'Plus Jakarta Sans', sans-serif"
        fontSize="27"
        fontWeight="700"
        letterSpacing="-0.5"
        fill="currentColor"
      >
        KTA
      </text>
    </svg>
  );
}
