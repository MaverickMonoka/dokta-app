import Image from 'next/image';
import Link from 'next/link';
import { db } from '@dokta/database';
import { cached } from '@dokta/database';
import { money } from '@dokta/shared';

interface AvailableDoctor {
  id: string;
  name: string;
  speciality: string;
  fee: string;
  languages: string[];
  rating: number;
  avatarUrl: string | null;
}

/**
 * Verified doctors, cheapest first. Cached for a minute — this is public,
 * non-clinical data, and it is on the busiest page on the platform.
 */
async function loadAvailable(): Promise<AvailableDoctor[]> {
  return cached('landing:available-doctors', 60, async () => {
    const doctors = await db.doctor.findMany({
      where: { verification: 'VERIFIED', offersVideo: true },
      orderBy: [{ rating: 'desc' }, { consultFee: 'asc' }],
      take: 4,
      select: {
        id: true,
        speciality: true,
        consultFee: true,
        languages: true,
        rating: true,
        user: { select: { name: true, avatarUrl: true } },
      },
    });

    return doctors.map((d) => ({
      id: d.id,
      name: d.user.name,
      speciality: d.speciality,
      fee: money(Number(d.consultFee)),
      languages: d.languages,
      rating: d.rating,
      avatarUrl: d.user.avatarUrl,
    }));
  });
}

export async function AvailabilityPanel() {
  let doctors: AvailableDoctor[] = [];
  let failed = false;

  try {
    doctors = await loadAvailable();
  } catch {
    failed = true;
  }

  return (
    <aside className="rounded-card bg-white p-2 shadow-panel">
      <div className="flex items-center justify-between px-3 py-3">
        <p className="font-display text-[0.9375rem] font-semibold text-ink">Available now</p>
        <span className="flex items-center gap-2 text-meta text-care">
          <span className="h-1.5 w-1.5 rounded-full bg-care" aria-hidden />
          Online
        </span>
      </div>

      {failed ? (
        <p className="px-3 pb-4 text-sm text-muted">
          Doctor availability could not load. Reload the page, or browse the full list.
        </p>
      ) : doctors.length === 0 ? (
        <p className="px-3 pb-4 text-sm text-muted">
          No doctors are online right now. Book an appointment for later today.
        </p>
      ) : (
        <ul className="divide-y divide-hairline">
          {doctors.map((doctor) => (
            <li key={doctor.id}>
              <Link
                href={`/doctors/${doctor.id}`}
                className="flex items-center gap-3 rounded-control px-3 py-3 hover:bg-canvas"
              >
                <span className="relative h-11 w-11 shrink-0 overflow-hidden rounded-full bg-navy-100">
                  {doctor.avatarUrl && (
                    <Image src={doctor.avatarUrl} alt="" fill sizes="44px" className="object-cover" />
                  )}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-sm font-semibold text-ink">{doctor.name}</span>
                  <span className="block truncate text-meta text-muted">
                    {doctor.speciality} · {doctor.languages.slice(0, 2).join(', ')}
                  </span>
                </span>
                <span className="money shrink-0 text-sm font-semibold text-ink">{doctor.fee}</span>
              </Link>
            </li>
          ))}
        </ul>
      )}

      <Link
        href="/doctors"
        className="mt-1 block rounded-control px-3 py-3 text-center text-sm font-semibold text-care hover:bg-canvas"
      >
        See all doctors
      </Link>
    </aside>
  );
}
