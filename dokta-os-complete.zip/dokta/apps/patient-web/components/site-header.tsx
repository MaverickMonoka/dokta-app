import Link from 'next/link';
import { getSession } from '@dokta/auth';
import { buttonVariants } from '@dokta/ui';
import { homeRouteFor } from '@dokta/shared';
import { Wordmark } from './wordmark';

export async function SiteHeader() {
  const session = await getSession().catch(() => null);

  return (
    <header className="mx-auto flex max-w-7xl items-center justify-between px-5 py-5 lg:px-8">
      <Link href="/" aria-label="DOKTA home">
        <Wordmark className="h-6 w-auto text-white" />
      </Link>

      <nav className="flex items-center gap-1 sm:gap-2">
        <Link
          href="/doctors"
          className="hidden rounded-control px-3 py-2 text-sm text-white/70 hover:text-white sm:block"
        >
          Doctors
        </Link>
        <Link
          href="/pharmacies"
          className="hidden rounded-control px-3 py-2 text-sm text-white/70 hover:text-white sm:block"
        >
          Pharmacies
        </Link>

        {session ? (
          <Link href={homeRouteFor[session.role]} className={buttonVariants({ variant: 'onNavy', size: 'sm' })}>
            {session.name.split(' ')[0]}
          </Link>
        ) : (
          <>
            <Link href="/sign-in" className="rounded-control px-3 py-2 text-sm text-white/70 hover:text-white">
              Sign in
            </Link>
            <Link href="/sign-up" className={buttonVariants({ size: 'sm' })}>
              Create account
            </Link>
          </>
        )}
      </nav>
    </header>
  );
}
