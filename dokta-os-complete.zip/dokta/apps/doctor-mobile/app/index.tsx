import * as React from 'react';
import { Pressable, RefreshControl, ScrollView, Text, View } from 'react-native';
import { Redirect } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { api, ApiError, Badge, Empty, ErrorNote, theme } from '@dokta/mobile-ui';
import { time } from '@dokta/shared';
import { useSession } from '@/lib/session';

interface QueueEntry {
  id: string;
  scheduledFor: string;
  status: string;
  type: string;
  patientName: string;
  reasonForVisit: string | null;
  allergies: string[];
}

/**
 * The doctor's phone view is the list and nothing else. Writing clinical notes
 * on a phone produces worse records than writing them on a desktop, so this app
 * deliberately does not offer it — it shows who is waiting and lets them join.
 */
export default function Queue() {
  const { session, loading, signOut } = useSession();
  const [queue, setQueue] = React.useState<QueueEntry[] | null>(null);
  const [error, setError] = React.useState<string | null>(null);
  const [refreshing, setRefreshing] = React.useState(false);

  const load = React.useCallback(async () => {
    setError(null);
    try {
      setQueue((await api<{ queue: QueueEntry[] }>('/api/doctor/queue')).queue);
    } catch (e) {
      if (e instanceof ApiError && e.status === 401) return signOut();
      setError(e instanceof Error ? e.message : 'Could not load your list.');
    }
  }, [signOut]);

  React.useEffect(() => {
    if (session) load();
  }, [session, load]);

  if (loading) return null;
  if (!session) return <Redirect href="/sign-in" />;

  return (
    <SafeAreaView style={{ flex: 1 }} edges={['bottom']}>
      <ScrollView
        contentContainerStyle={{ padding: theme.space(5), gap: theme.space(3) }}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={async () => {
              setRefreshing(true);
              await load();
              setRefreshing(false);
            }}
          />
        }
      >
        {error && <ErrorNote message={error} onRetry={load} />}

        {queue?.length === 0 && !error && (
          <Empty
            title="Nobody booked today"
            body="Open more consulting hours from the web dashboard and patients can book them."
          />
        )}

        {(queue ?? []).map((entry) => (
          <Pressable
            key={entry.id}
            style={({ pressed }) => ({
              backgroundColor: theme.color.white,
              borderWidth: 1,
              borderColor: entry.allergies.length ? theme.color.red : theme.color.border,
              borderRadius: theme.radius.card,
              padding: theme.space(4),
              opacity: pressed ? 0.85 : 1,
            })}
          >
            <View style={{ flexDirection: 'row', gap: theme.space(3) }}>
              <Text style={{ fontSize: 15, fontWeight: '700', width: 52 }}>
                {time(entry.scheduledFor)}
              </Text>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 15, fontWeight: '600' }}>{entry.patientName}</Text>
                <Text style={theme.text.meta} numberOfLines={2}>
                  {entry.reasonForVisit ?? 'No reason given'}
                </Text>
              </View>
              <Badge status={entry.status} />
            </View>

            {entry.allergies.length > 0 && (
              <Text style={{ color: theme.color.red, fontSize: 13, marginTop: theme.space(2) }}>
                Allergic to {entry.allergies.join(', ')}
              </Text>
            )}
          </Pressable>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}
