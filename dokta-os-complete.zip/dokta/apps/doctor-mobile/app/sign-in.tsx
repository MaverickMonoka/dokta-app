import * as React from 'react';
import { KeyboardAvoidingView, Platform, Text, TextInput, View } from 'react-native';
import { router } from 'expo-router';
import { Button, ErrorNote, Screen, theme } from '@dokta/mobile-ui';
import { useSession } from '@/lib/session';

export default function SignIn() {
  const { signIn } = useSession();
  const [email, setEmail] = React.useState('');
  const [password, setPassword] = React.useState('');
  const [error, setError] = React.useState<string | null>(null);
  const [busy, setBusy] = React.useState(false);

  async function submit() {
    setError(null);
    setBusy(true);
    const result = await signIn(email.trim(), password);
    setBusy(false);
    if (result.error) setError(result.error);
    else router.replace('/');
  }

  return (
    <Screen>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <Text style={theme.text.display}>Welcome back</Text>
        <Text style={[theme.text.meta, { marginTop: 6, marginBottom: theme.space(6) }]}>
          Sign in to see your appointments, prescriptions and records.
        </Text>

        <View style={{ gap: theme.space(3) }}>
          <View>
            <Text style={{ fontSize: 14, fontWeight: '500', marginBottom: 6 }}>Email</Text>
            <TextInput
              value={email}
              onChangeText={setEmail}
              autoCapitalize="none"
              keyboardType="email-address"
              textContentType="emailAddress"
              style={inputStyle}
            />
          </View>

          <View>
            <Text style={{ fontSize: 14, fontWeight: '500', marginBottom: 6 }}>Password</Text>
            <TextInput
              value={password}
              onChangeText={setPassword}
              secureTextEntry
              textContentType="password"
              style={inputStyle}
            />
          </View>

          {error && <ErrorNote message={error} />}

          <Button label="Sign in" onPress={submit} loading={busy} disabled={!email || !password} />
        </View>
      </KeyboardAvoidingView>
    </Screen>
  );
}

const inputStyle = {
  height: 48,
  borderWidth: 1,
  borderColor: theme.color.border,
  borderRadius: theme.radius.control,
  paddingHorizontal: 12,
  backgroundColor: theme.color.white,
  fontSize: 15,
};
