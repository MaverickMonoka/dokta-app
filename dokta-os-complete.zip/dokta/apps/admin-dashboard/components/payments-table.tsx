'use client';

import * as React from 'react';
import { Badge, Button, DataTable, ErrorState, Field, Sheet, TextArea } from '@dokta/ui';
import { money } from '@dokta/shared';
import { issueRefund } from '@/app/payments/actions';

interface Payment {
  id: string;
  reference: string;
  payer: string;
  email: string;
  amount: number;
  refunded: number;
  gateway: string;
  status: string;
  failureReason: string | null;
  date: string;
}

/** Only Yoco supports automated refunds; the rest are refunded by EFT. */
const AUTO_REFUND = new Set(['YOCO']);

export function PaymentsTable({ payments }: { payments: Payment[] }) {
  const [open, setOpen] = React.useState<Payment | null>(null);
  const [amount, setAmount] = React.useState('');
  const [reason, setReason] = React.useState('');
  const [error, setError] = React.useState<string | null>(null);
  const [pending, startTransition] = React.useTransition();

  function refund() {
    if (!open) return;
    setError(null);
    startTransition(async () => {
      const result = await issueRefund({
        paymentId: open.id,
        amount: Number(amount),
        reason,
      });
      if (!result.ok) setError(result.error);
      else {
        setOpen(null);
        setAmount('');
        setReason('');
      }
    });
  }

  const remaining = open ? open.amount - open.refunded : 0;

  return (
    <>
      <DataTable
        rows={payments}
        rowKey={(p) => p.id}
        empty={null}
        onRowClick={(p) => {
          setOpen(p);
          setAmount(String((p.amount - p.refunded).toFixed(2)));
          setReason('');
          setError(null);
        }}
        columns={[
          { key: 'ref', header: 'Reference', render: (p) => <span className="money">{p.reference}</span> },
          {
            key: 'payer',
            header: 'Paid by',
            render: (p) => (
              <span>
                <span className="block text-ink">{p.payer}</span>
                <span className="block text-meta text-muted">{p.email}</span>
              </span>
            ),
          },
          { key: 'date', header: 'Date', render: (p) => p.date },
          { key: 'gateway', header: 'Gateway', render: (p) => p.gateway.toLowerCase() },
          { key: 'status', header: 'Status', render: (p) => <Badge status={p.status} /> },
          {
            key: 'amount',
            header: 'Amount',
            numeric: true,
            render: (p) => (
              <span>
                <span className="block">{money(p.amount)}</span>
                {p.refunded > 0 && (
                  <span className="block text-meta text-muted">−{money(p.refunded)} refunded</span>
                )}
              </span>
            ),
          },
        ]}
      />

      <Sheet
        open={Boolean(open)}
        onClose={() => setOpen(null)}
        title={open?.reference ?? ''}
        description={open ? `${open.payer} · ${open.gateway.toLowerCase()}` : undefined}
        footer={
          open?.status === 'SUCCEEDED' && remaining > 0 ? (
            <Button
              full
              variant="danger"
              loading={pending}
              disabled={!AUTO_REFUND.has(open.gateway)}
              onClick={refund}
            >
              Refund {money(Number(amount) || 0)}
            </Button>
          ) : null
        }
      >
        {open && (
          <div className="space-y-5">
            <dl className="divide-y divide-hairline rounded-card border border-hairline">
              <Row label="Amount" value={money(open.amount)} />
              <Row label="Already refunded" value={money(open.refunded)} />
              <Row label="Available to refund" value={money(remaining)} />
              <Row label="Date" value={open.date} />
            </dl>

            {open.failureReason && (
              <p className="rounded-control bg-alert-soft px-3 py-2.5 text-sm text-ink">
                {open.failureReason}
              </p>
            )}

            {open.status === 'SUCCEEDED' && remaining > 0 && (
              <>
                {!AUTO_REFUND.has(open.gateway) && (
                  <p className="rounded-control bg-warn-soft px-3 py-2.5 text-sm text-ink">
                    {open.gateway.toLowerCase()} has no refund API. Refund this by EFT and record it
                    in your accounting system — DOKTA cannot reverse it automatically.
                  </p>
                )}
                <Field
                  label="Refund amount"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  inputMode="decimal"
                  hint={`Up to ${money(remaining)}`}
                />
                <TextArea
                  label="Reason"
                  rows={3}
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  hint="Stored on the audit log against your account."
                />
              </>
            )}

            {error && <ErrorState title="Refund failed" body={error} />}
          </div>
        )}
      </Sheet>
    </>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between gap-4 px-4 py-2.5">
      <dt className="text-meta text-muted">{label}</dt>
      <dd className="money text-sm text-ink">{value}</dd>
    </div>
  );
}
