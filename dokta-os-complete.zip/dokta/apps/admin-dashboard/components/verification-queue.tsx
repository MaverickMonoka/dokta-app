'use client';

import * as React from 'react';
import { BadgeCheck, ExternalLink, X } from 'lucide-react';
import { Button, ErrorState, Sheet, TextArea } from '@dokta/ui';
import { decideProvider } from '@/app/providers/actions';

interface Application {
  kind: 'doctor' | 'pharmacy';
  id: string;
  title: string;
  subtitle: string;
  applied: string;
  registerUrl: string;
  registerLabel: string;
  facts: { label: string; value: string }[];
}

export function VerificationQueue({ applications }: { applications: Application[] }) {
  const [open, setOpen] = React.useState<Application | null>(null);
  const [reason, setReason] = React.useState('');
  const [error, setError] = React.useState<string | null>(null);
  const [pending, startTransition] = React.useTransition();

  function decide(decision: 'VERIFIED' | 'REJECTED') {
    if (!open) return;
    setError(null);
    startTransition(async () => {
      const result = await decideProvider({
        kind: open.kind,
        id: open.id,
        decision,
        reason: decision === 'REJECTED' ? reason : undefined,
      });
      if (!result.ok) setError(result.error);
      else {
        setOpen(null);
        setReason('');
      }
    });
  }

  return (
    <>
      <ul className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
        {applications.map((app) => (
          <li key={`${app.kind}-${app.id}`}>
            <button
              type="button"
              onClick={() => {
                setOpen(app);
                setReason('');
                setError(null);
              }}
              className="w-full rounded-card border border-hairline bg-white p-4 text-left transition-colors hover:border-care"
            >
              <p className="text-sm font-semibold text-ink">{app.title}</p>
              <p className="text-meta text-muted">{app.subtitle}</p>
              <p className="mt-3 text-meta text-muted">Applied {app.applied}</p>
            </button>
          </li>
        ))}
      </ul>

      <Sheet
        open={Boolean(open)}
        onClose={() => setOpen(null)}
        title={open?.title ?? ''}
        description={open ? `${open.subtitle} · applied ${open.applied}` : undefined}
        footer={
          open && (
            <div className="grid grid-cols-2 gap-2">
              <Button variant="danger" loading={pending} onClick={() => decide('REJECTED')}>
                <X className="h-4 w-4" aria-hidden />
                Reject
              </Button>
              <Button loading={pending} onClick={() => decide('VERIFIED')}>
                <BadgeCheck className="h-4 w-4" aria-hidden />
                Approve
              </Button>
            </div>
          )
        }
      >
        {open && (
          <div className="space-y-5">
            <a
              href={open.registerUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 text-sm font-medium text-care hover:text-care-dark"
            >
              Check the {open.registerLabel}
              <ExternalLink className="h-3.5 w-3.5" aria-hidden />
            </a>

            <dl className="divide-y divide-hairline rounded-card border border-hairline">
              {open.facts.map((fact) => (
                <div key={fact.label} className="flex justify-between gap-4 px-4 py-2.5">
                  <dt className="text-meta text-muted">{fact.label}</dt>
                  <dd className="money text-right text-sm text-ink">{fact.value}</dd>
                </div>
              ))}
            </dl>

            <TextArea
              label="Reason, if rejecting"
              hint="Sent to the applicant so they know what to correct."
              rows={3}
              value={reason}
              onChange={(e) => setReason(e.target.value)}
            />

            {error && <ErrorState title="Could not record the decision" body={error} />}
          </div>
        )}
      </Sheet>
    </>
  );
}
