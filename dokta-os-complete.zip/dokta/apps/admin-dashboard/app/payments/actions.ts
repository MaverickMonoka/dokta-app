'use server';

import { revalidatePath } from 'next/cache';
import { requireCapability, audit } from '@dokta/auth';
import { DomainError, refundPayment } from '@dokta/core';

export async function issueRefund(input: { paymentId: string; amount: number; reason: string }) {
  const session = await requireCapability('payment:refund', '/payments');

  if (!input.reason.trim()) {
    return { ok: false as const, error: 'Record why this is being refunded.' };
  }
  if (input.amount <= 0) {
    return { ok: false as const, error: 'Enter an amount greater than zero.' };
  }

  try {
    const payment = await refundPayment(input.paymentId, input.amount, input.reason);

    await audit({
      actorId: session.id,
      action: 'update',
      entity: 'Payment',
      entityId: input.paymentId,
      lawfulBasis: 'contract',
      metadata: { refunded: input.amount, reason: input.reason },
    });

    revalidatePath('/payments');
    return { ok: true as const, status: payment.status };
  } catch (error) {
    if (error instanceof DomainError) return { ok: false as const, error: error.message };
    throw error;
  }
}
