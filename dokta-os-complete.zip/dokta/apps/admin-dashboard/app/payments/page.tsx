import { CreditCard } from 'lucide-react';
import { requireCapability } from '@dokta/auth';
import { db } from '@dokta/database';
import { money, shortDate } from '@dokta/shared';
import { EmptyState, PageHeader, Stat } from '@dokta/ui';
import { PaymentsTable } from '@/components/payments-table';

export const metadata = { title: 'Payments' };
export const dynamic = 'force-dynamic';

export default async function PaymentsPage() {
  await requireCapability('payment:read:all', '/payments');

  const since = new Date(Date.now() - 30 * 86_400_000);

  const [payments, settled, failed, refunded] = await Promise.all([
    db.payment.findMany({
      orderBy: { createdAt: 'desc' },
      take: 100,
      select: {
        id: true,
        reference: true,
        amount: true,
        refundedAmount: true,
        gateway: true,
        status: true,
        failureReason: true,
        paidAt: true,
        createdAt: true,
        user: { select: { name: true, email: true } },
      },
    }),
    db.payment.aggregate({
      where: { status: 'SUCCEEDED', paidAt: { gte: since } },
      _sum: { amount: true },
      _count: true,
    }),
    db.payment.count({ where: { status: 'FAILED', createdAt: { gte: since } } }),
    db.payment.aggregate({
      where: { status: { in: ['REFUNDED', 'PARTIALLY_REFUNDED'] } },
      _sum: { refundedAmount: true },
    }),
  ]);

  const settledTotal = Number(settled._sum.amount ?? 0);
  const attempts = settled._count + failed;

  return (
    <>
      <PageHeader
        title="Payments"
        description="Last 100 attempts across every gateway. Refunds are recorded against the original payment."
      />

      <div className="space-y-5 p-5 lg:p-8">
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <Stat label="Settled, last 30 days" value={money(settledTotal)} hint={`${settled._count} payments`} />
          <Stat label="Failed attempts" value={failed} />
          <Stat
            label="Success rate"
            value={attempts ? `${Math.round((settled._count / attempts) * 100)}%` : '—'}
          />
          <Stat label="Refunded, all time" value={money(Number(refunded._sum.refundedAmount ?? 0))} />
        </div>

        {payments.length === 0 ? (
          <EmptyState icon={CreditCard} title="No payments yet" body="Payment attempts appear here as soon as patients start transacting." />
        ) : (
          <PaymentsTable
            payments={payments.map((p) => ({
              id: p.id,
              reference: p.reference,
              payer: p.user.name,
              email: p.user.email,
              amount: Number(p.amount),
              refunded: Number(p.refundedAmount),
              gateway: p.gateway,
              status: p.status,
              failureReason: p.failureReason,
              date: shortDate(p.paidAt ?? p.createdAt),
            }))}
          />
        )}
      </div>
    </>
  );
}
