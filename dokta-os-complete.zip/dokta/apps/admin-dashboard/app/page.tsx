import { dailySeries, platformMetrics, pharmacyPerformance, topMedicines } from '@dokta/core';
import { requireCapability } from '@dokta/auth';
import { money } from '@dokta/shared';
import { BarList, Card, CardBody, CardHeader, CardTitle, LineChart, PageHeader, Stat } from '@dokta/ui';

export const dynamic = 'force-dynamic';

export default async function AdminOverview() {
  await requireCapability('analytics:read', '/');

  const [metrics, series, medicines, pharmacies] = await Promise.all([
    platformMetrics(),
    dailySeries(30),
    topMedicines(8),
    pharmacyPerformance(),
  ]);

  return (
    <>
      <PageHeader
        title="Platform overview"
        description="Last 30 days. Revenue is what the platform keeps: 12% of consultations and 4% of medicine."
      />

      <div className="space-y-5 p-5 lg:p-8">
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <Stat label="Registered users" value={metrics.users.toLocaleString('en-ZA')} hint={`${metrics.patients.toLocaleString('en-ZA')} patients`} />
          <Stat label="Verified doctors" value={metrics.activeDoctors} hint={metrics.pendingProviders ? `${metrics.pendingProviders} awaiting verification` : 'None waiting'} />
          <Stat label="Appointments" value={metrics.appointments30d} />
          <Stat label="Platform revenue" value={money(metrics.platformRevenue30d)} />
        </div>

        <div className="grid gap-5 lg:grid-cols-3">
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Money through the platform, daily</CardTitle>
              <span className="money text-meta text-muted">
                {money(metrics.consultationRevenue30d + metrics.pharmacyRevenue30d)} in 30 days
              </span>
            </CardHeader>
            <CardBody>
              <LineChart values={series.revenue} labels={series.labels} format={money} />
            </CardBody>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>New accounts, daily</CardTitle>
            </CardHeader>
            <CardBody>
              <LineChart values={series.users} labels={series.labels} color="#0F2E4C" />
            </CardBody>
          </Card>
        </div>

        <div className="grid gap-5 lg:grid-cols-3">
          <Card>
            <CardHeader>
              <CardTitle>Where the money comes from</CardTitle>
            </CardHeader>
            <CardBody>
              <BarList
                items={[
                  { name: 'Consultations', value: metrics.consultationRevenue30d },
                  { name: 'Medicine', value: metrics.pharmacyRevenue30d },
                ]}
                format={money}
              />
            </CardBody>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Most dispensed medicines</CardTitle>
            </CardHeader>
            <CardBody>
              {medicines.length === 0 ? (
                <p className="text-sm text-muted">No medicine dispensed yet.</p>
              ) : (
                <BarList
                  items={medicines.map((m) => ({ name: m.name, value: m.units }))}
                  format={(n) => `${n} units`}
                />
              )}
            </CardBody>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Pharmacy performance</CardTitle>
            </CardHeader>
            <CardBody>
              {pharmacies.length === 0 ? (
                <p className="text-sm text-muted">No verified pharmacies yet.</p>
              ) : (
                <BarList
                  items={pharmacies.slice(0, 6).map((p) => ({
                    name: `${p.name}${p.city ? ` · ${p.city}` : ''}`,
                    value: p.counterTotal,
                  }))}
                  format={money}
                />
              )}
            </CardBody>
          </Card>
        </div>
      </div>
    </>
  );
}
