import type { Metadata, Viewport } from 'next';
import { Inter, Plus_Jakarta_Sans } from 'next/font/google';
import { headers } from 'next/headers';
import { BadgeCheck, CreditCard, LayoutDashboard, ScrollText, Users } from 'lucide-react';
import { requireCapability } from '@dokta/auth';
import { db } from '@dokta/database';
import { AppShell } from '@dokta/ui';
import './globals.css';

const body = Inter({ subsets: ['latin'], variable: '--font-body', display: 'swap' });
const display = Plus_Jakarta_Sans({
  subsets: ['latin'],
  weight: ['600', '700'],
  variable: '--font-display',
  display: 'swap',
});

export const metadata: Metadata = { title: { default: 'Platform', template: '%s · DOKTA admin' } };
export const viewport: Viewport = { themeColor: '#0B2137', width: 'device-width', initialScale: 1 };

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const session = await requireCapability('analytics:read', '/');

  const [pendingDoctors, pendingPharmacies] = await Promise.all([
    db.doctor.count({ where: { verification: { in: ['PENDING', 'UNDER_REVIEW'] } } }),
    db.pharmacy.count({ where: { verification: { in: ['PENDING', 'UNDER_REVIEW'] } } }),
  ]);

  const path = headers().get('x-invoke-path') ?? headers().get('x-pathname') ?? '/';

  return (
    <html lang="en-ZA" className={`${body.variable} ${display.variable}`}>
      <body>
        <AppShell
          product="Platform"
          currentPath={path}
          user={{ name: session.name, subtitle: 'Administrator' }}
          nav={[
            { href: '/', label: 'Overview', icon: LayoutDashboard },
            { href: '/providers', label: 'Verification', icon: BadgeCheck, badge: pendingDoctors + pendingPharmacies },
            { href: '/users', label: 'People', icon: Users },
            { href: '/payments', label: 'Payments', icon: CreditCard },
            { href: '/audit', label: 'Access log', icon: ScrollText },
          ]}
        >
          {children}
        </AppShell>
      </body>
    </html>
  );
}
