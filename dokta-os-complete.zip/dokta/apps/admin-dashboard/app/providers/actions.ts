'use server';

import { revalidatePath } from 'next/cache';
import { requireCapability, audit } from '@dokta/auth';
import { db } from '@dokta/database';
import { notify } from '@dokta/notifications';

/**
 * Verification is the gate that keeps unregistered practitioners off the
 * platform, so both outcomes are written to the audit log with the reviewer's
 * identity — this is the record a regulator would ask for.
 */
export async function decideProvider(input: {
  kind: 'doctor' | 'pharmacy';
  id: string;
  decision: 'VERIFIED' | 'REJECTED';
  reason?: string;
}) {
  const session = await requireCapability('provider:approve', '/providers');

  if (input.decision === 'REJECTED' && !input.reason?.trim()) {
    return { ok: false as const, error: 'Give a reason so the applicant knows what to fix.' };
  }

  if (input.kind === 'doctor') {
    const doctor = await db.doctor.update({
      where: { id: input.id },
      data: {
        verification: input.decision,
        verifiedAt: input.decision === 'VERIFIED' ? new Date() : null,
      },
      select: { userId: true, user: { select: { name: true } } },
    });

    if (input.decision === 'VERIFIED') {
      await notify({
        userId: doctor.userId,
        template: 'provider_verified',
        data: { name: doctor.user.name },
        channels: ['EMAIL', 'IN_APP', 'PUSH'],
      });
    }
  } else {
    const pharmacy = await db.pharmacy.update({
      where: { id: input.id },
      data: { verification: input.decision },
      select: { ownerId: true, name: true },
    });

    if (input.decision === 'VERIFIED') {
      await notify({
        userId: pharmacy.ownerId,
        template: 'provider_verified',
        data: { name: pharmacy.name },
        channels: ['EMAIL', 'IN_APP', 'PUSH'],
      });
    }
  }

  await audit({
    actorId: session.id,
    action: 'update',
    entity: input.kind === 'doctor' ? 'Doctor' : 'Pharmacy',
    entityId: input.id,
    lawfulBasis: 'legal_obligation',
    metadata: { decision: input.decision, reason: input.reason },
  });

  revalidatePath('/providers');
  return { ok: true as const };
}
