import { BadgeCheck } from 'lucide-react';
import { requireCapability } from '@dokta/auth';
import { db } from '@dokta/database';
import { money, shortDate } from '@dokta/shared';
import { EmptyState, PageHeader } from '@dokta/ui';
import { VerificationQueue } from '@/components/verification-queue';

export const metadata = { title: 'Verification' };
export const dynamic = 'force-dynamic';

export default async function ProvidersPage() {
  await requireCapability('provider:approve', '/providers');

  const [doctors, pharmacies] = await Promise.all([
    db.doctor.findMany({
      where: { verification: { in: ['PENDING', 'UNDER_REVIEW'] } },
      orderBy: { createdAt: 'asc' },
      select: {
        id: true,
        speciality: true,
        licenseNumber: true,
        licenseBody: true,
        yearsExperience: true,
        consultFee: true,
        city: true,
        province: true,
        practiceName: true,
        createdAt: true,
        user: { select: { name: true, email: true, phone: true } },
      },
    }),
    db.pharmacy.findMany({
      where: { verification: { in: ['PENDING', 'UNDER_REVIEW'] } },
      orderBy: { createdAt: 'asc' },
      select: {
        id: true,
        name: true,
        registrationNo: true,
        responsiblePharmacist: true,
        city: true,
        province: true,
        createdAt: true,
        owner: { select: { name: true, email: true, phone: true } },
      },
    }),
  ]);

  if (doctors.length === 0 && pharmacies.length === 0) {
    return (
      <>
        <PageHeader title="Verification" />
        <EmptyState
          icon={BadgeCheck}
          title="Nothing waiting"
          body="New doctor and pharmacy applications land here. Nobody appears to patients until you approve them."
        />
      </>
    );
  }

  return (
    <>
      <PageHeader
        title="Verification"
        description="Check the registration number against the HPCSA or SAPC register before approving. Approval makes the profile visible to patients immediately."
      />
      <div className="p-5 lg:p-8">
        <VerificationQueue
          applications={[
            ...doctors.map((d) => ({
              kind: 'doctor' as const,
              id: d.id,
              title: d.user.name,
              subtitle: d.speciality,
              applied: shortDate(d.createdAt),
              registerUrl: 'https://hpcsaonline.custhelp.com/app/ipractitioner',
              registerLabel: 'HPCSA register',
              facts: [
                { label: `${d.licenseBody} number`, value: d.licenseNumber },
                { label: 'Experience', value: `${d.yearsExperience} years` },
                { label: 'Consultation fee', value: money(Number(d.consultFee)) },
                { label: 'Practice', value: d.practiceName ?? '—' },
                { label: 'Location', value: [d.city, d.province].filter(Boolean).join(', ') || '—' },
                { label: 'Email', value: d.user.email },
                { label: 'Phone', value: d.user.phone ?? '—' },
              ],
            })),
            ...pharmacies.map((p) => ({
              kind: 'pharmacy' as const,
              id: p.id,
              title: p.name,
              subtitle: 'Pharmacy',
              applied: shortDate(p.createdAt),
              registerUrl: 'https://www.sapc.za.org/PharmacySearch',
              registerLabel: 'SAPC register',
              facts: [
                { label: 'SAPC number', value: p.registrationNo },
                { label: 'Responsible pharmacist', value: p.responsiblePharmacist ?? '—' },
                { label: 'Location', value: [p.city, p.province].filter(Boolean).join(', ') || '—' },
                { label: 'Owner', value: p.owner.name },
                { label: 'Email', value: p.owner.email },
                { label: 'Phone', value: p.owner.phone ?? '—' },
              ],
            })),
          ]}
        />
      </div>
    </>
  );
}
