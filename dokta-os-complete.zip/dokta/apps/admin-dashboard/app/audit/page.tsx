import { ScrollText } from 'lucide-react';
import { requireCapability } from '@dokta/auth';
import { db } from '@dokta/database';
import { Badge, DataTable, EmptyState, PageHeader, Stat } from '@dokta/ui';

export const metadata = { title: 'Access log' };
export const dynamic = 'force-dynamic';

/**
 * The POPIA record. Every read and write of personal health information is
 * here, including who did it and on what lawful basis — this is what gets
 * produced if the Information Regulator asks.
 */
export default async function AuditPage() {
  await requireCapability('audit:read', '/audit');

  const since = new Date(Date.now() - 7 * 86_400_000);

  const [entries, reads, writes] = await Promise.all([
    db.auditLog.findMany({
      orderBy: { createdAt: 'desc' },
      take: 200,
      select: {
        id: true,
        action: true,
        entity: true,
        entityId: true,
        subjectId: true,
        lawfulBasis: true,
        ipAddress: true,
        createdAt: true,
        actor: { select: { name: true, role: true } },
      },
    }),
    db.auditLog.count({ where: { action: 'read', createdAt: { gte: since } } }),
    db.auditLog.count({ where: { action: { in: ['create', 'update', 'delete'] }, createdAt: { gte: since } } }),
  ]);

  return (
    <>
      <PageHeader
        title="Access log"
        description="Every access to personal health information, kept for POPIA section 14. Entries cannot be edited or deleted from this interface."
      />

      <div className="space-y-5 p-5 lg:p-8">
        <div className="grid gap-4 sm:grid-cols-3">
          <Stat label="Records read, last 7 days" value={reads} />
          <Stat label="Records changed, last 7 days" value={writes} />
          <Stat label="Entries shown" value={entries.length} hint="Most recent 200" />
        </div>

        <DataTable
          rows={entries}
          rowKey={(e) => e.id}
          empty={
            <EmptyState
              icon={ScrollText}
              title="No access recorded yet"
              body="Entries appear as soon as anyone opens a patient record."
            />
          }
          columns={[
            {
              key: 'when',
              header: 'When',
              render: (e) => (
                <span className="money text-meta">
                  {new Intl.DateTimeFormat('en-ZA', { dateStyle: 'short', timeStyle: 'short' }).format(e.createdAt)}
                </span>
              ),
            },
            {
              key: 'actor',
              header: 'Who',
              render: (e) => (
                <span>
                  <span className="block text-ink">{e.actor?.name ?? 'System'}</span>
                  <span className="block text-meta text-muted">{e.actor?.role.toLowerCase() ?? '—'}</span>
                </span>
              ),
            },
            {
              key: 'action',
              header: 'Action',
              render: (e) => (
                <Badge tone={e.action === 'read' ? 'neutral' : e.action === 'delete' ? 'alert' : 'warn'}>
                  {e.action}
                </Badge>
              ),
            },
            { key: 'entity', header: 'Record', render: (e) => e.entity },
            {
              key: 'basis',
              header: 'Lawful basis',
              render: (e) => <span className="text-meta">{e.lawfulBasis?.replace(/_/g, ' ') ?? '—'}</span>,
            },
            { key: 'ip', header: 'From', render: (e) => <span className="money text-meta">{e.ipAddress ?? '—'}</span> },
          ]}
        />
      </div>
    </>
  );
}
