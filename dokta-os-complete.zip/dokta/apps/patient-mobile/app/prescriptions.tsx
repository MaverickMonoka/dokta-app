import * as React from 'react';
import { Text, View } from 'react-native';
import { api, Badge, Card, Empty, ErrorNote, Screen, theme } from '@dokta/mobile-ui';
import { shortDate } from '@dokta/shared';

interface Prescription {
  id: string;
  reference: string;
  status: string;
  validUntil: string;
  repeatsLeft: number;
  doctorName: string;
  pharmacyName: string | null;
  items: { name: string; dosage: string; frequency: string }[];
}

export default function Prescriptions() {
  const [prescriptions, setPrescriptions] = React.useState<Prescription[] | null>(null);
  const [error, setError] = React.useState<string | null>(null);

  const load = React.useCallback(async () => {
    setError(null);
    try {
      const data = await api<{ prescriptions: Prescription[] }>('/api/prescriptions');
      setPrescriptions(data.prescriptions);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not load your prescriptions.');
    }
  }, []);

  React.useEffect(() => {
    load();
  }, [load]);

  return (
    <Screen>
      {error && <ErrorNote message={error} onRetry={load} />}

      {prescriptions?.length === 0 && !error && (
        <Empty
          title="No prescriptions yet"
          body="A doctor can issue one during a consultation. It appears here, ready to send to a pharmacy."
        />
      )}

      <View style={{ gap: theme.space(3) }}>
        {(prescriptions ?? []).map((rx) => (
          <Card key={rx.id}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', gap: 12 }}>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 15, fontWeight: '600' }}>{rx.doctorName}</Text>
                <Text style={theme.text.meta}>{rx.reference}</Text>
              </View>
              <Badge status={rx.status} />
            </View>

            <View style={{ marginTop: theme.space(3), gap: 6 }}>
              {rx.items.map((item) => (
                <View key={item.name}>
                  <Text style={{ fontSize: 14, fontWeight: '500' }}>{item.name}</Text>
                  <Text style={theme.text.meta}>
                    {item.dosage}, {item.frequency}
                  </Text>
                </View>
              ))}
            </View>

            <Text style={[theme.text.meta, { marginTop: theme.space(3) }]}>
              Valid until {shortDate(rx.validUntil)}
              {rx.repeatsLeft > 0 ? ` · ${rx.repeatsLeft} repeats left` : ''}
              {rx.pharmacyName ? ` · at ${rx.pharmacyName}` : ''}
            </Text>
          </Card>
        ))}
      </View>
    </Screen>
  );
}
