import * as React from 'react';
import { Pressable, RefreshControl, ScrollView, Text, View } from 'react-native';
import { Redirect, router } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { api, ApiError, Badge, Button, Card, Empty, ErrorNote, theme } from '@dokta/mobile-ui';
import { money, shortDate, time } from '@dokta/shared';
import { useSession } from '@/lib/session';

interface Appointment {
  id: string;
  reference: string;
  scheduledFor: string;
  type: string;
  status: string;
  paid: boolean;
  fee: number;
  doctorName: string;
  speciality: string;
}

export default function Home() {
  const { session, loading, signOut } = useSession();
  const [appointments, setAppointments] = React.useState<Appointment[] | null>(null);
  const [error, setError] = React.useState<string | null>(null);
  const [refreshing, setRefreshing] = React.useState(false);

  const load = React.useCallback(async () => {
    setError(null);
    try {
      const data = await api<{ appointments: Appointment[] }>('/api/appointments');
      setAppointments(data.appointments);
    } catch (e) {
      if (e instanceof ApiError && e.status === 401) {
        await signOut();
        return;
      }
      setError(e instanceof Error ? e.message : 'Could not load your appointments.');
    }
  }, [signOut]);

  React.useEffect(() => {
    if (session) load();
  }, [session, load]);

  if (loading) return null;
  if (!session) return <Redirect href="/sign-in" />;

  const upcoming = (appointments ?? []).filter(
    (a) => new Date(a.scheduledFor) > new Date() && ['CONFIRMED', 'REQUESTED'].includes(a.status),
  );
  const next = upcoming[upcoming.length - 1];

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: theme.color.navy }} edges={['top']}>
      <ScrollView
        contentContainerStyle={{ paddingBottom: theme.space(12) }}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            tintColor={theme.color.white}
            onRefresh={async () => {
              setRefreshing(true);
              await load();
              setRefreshing(false);
            }}
          />
        }
      >
        <View style={{ padding: theme.space(5), paddingBottom: theme.space(7) }}>
          <Text style={{ color: theme.color.onNavyFaint, fontSize: 13 }}>DOKTA</Text>
          <Text
            style={{ color: theme.color.white, fontSize: 26, fontWeight: '700', marginTop: 4 }}
          >
            {next ? 'Your next appointment' : 'How can we help today?'}
          </Text>

          {next ? (
            <View style={{ marginTop: theme.space(4) }}>
              <Text style={{ color: theme.color.white, fontSize: 20, fontWeight: '600' }}>
                {next.doctorName}
              </Text>
              <Text style={{ color: theme.color.onNavy, marginTop: 2 }}>{next.speciality}</Text>
              <Text style={{ color: theme.color.white, marginTop: theme.space(3), fontSize: 15 }}>
                {shortDate(next.scheduledFor)} at {time(next.scheduledFor)}
              </Text>

              <View style={{ marginTop: theme.space(4), gap: theme.space(2) }}>
                {!next.paid ? (
                  <Button
                    label={`Pay ${money(next.fee)} to confirm`}
                    onPress={() => router.push(`/payments/${next.id}`)}
                  />
                ) : next.type === 'VIDEO' ? (
                  <Button label="Join consultation" onPress={() => router.push(`/consultations/${next.id}`)} />
                ) : null}
              </View>
            </View>
          ) : (
            <View style={{ marginTop: theme.space(4), gap: theme.space(2) }}>
              <Button label="Find a doctor" onPress={() => router.push('/doctors')} />
            </View>
          )}
        </View>

        <View
          style={{
            backgroundColor: theme.color.background,
            borderTopLeftRadius: 20,
            borderTopRightRadius: 20,
            padding: theme.space(5),
            minHeight: 400,
            gap: theme.space(3),
          }}
        >
          <View style={{ flexDirection: 'row', gap: theme.space(3) }}>
            <Tile label="Prescriptions" onPress={() => router.push('/prescriptions')} />
            <Tile label="Find a doctor" onPress={() => router.push('/doctors')} />
          </View>

          <Text style={[theme.text.title, { marginTop: theme.space(3) }]}>Your appointments</Text>

          {error && <ErrorNote message={error} onRetry={load} />}

          {appointments?.length === 0 && !error && (
            <Empty
              title="No appointments yet"
              body="Find a doctor by speciality, price and language, and book a time that suits you."
              action={<Button label="Find a doctor" onPress={() => router.push('/doctors')} />}
            />
          )}

          {(appointments ?? []).map((appointment) => (
            <Card key={appointment.id}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', gap: 12 }}>
                <View style={{ flex: 1 }}>
                  <Text style={{ fontSize: 15, fontWeight: '600' }}>{appointment.doctorName}</Text>
                  <Text style={theme.text.meta}>
                    {shortDate(appointment.scheduledFor)} at {time(appointment.scheduledFor)}
                  </Text>
                </View>
                <Badge status={appointment.status} />
              </View>
            </Card>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

function Tile({ label, onPress }: { label: string; onPress: () => void }) {
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      style={({ pressed }) => ({
        flex: 1,
        backgroundColor: theme.color.white,
        borderWidth: 1,
        borderColor: theme.color.border,
        borderRadius: theme.radius.card,
        padding: theme.space(4),
        opacity: pressed ? 0.8 : 1,
      })}
    >
      <Text style={{ fontSize: 15, fontWeight: '600' }}>{label}</Text>
    </Pressable>
  );
}
