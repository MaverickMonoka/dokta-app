'use client';

import * as React from 'react';
import { AlertTriangle, CheckCircle2, ClipboardList, PackageCheck } from 'lucide-react';
import { Badge, Button, EmptyState, ErrorState, SelectField, Sheet, Field } from '@dokta/ui';
import { approveScript, dispense } from '@/app/prescriptions/actions';

interface Script {
  id: string;
  reference: string;
  status: string;
  received: string;
  validUntil: string;
  repeatsLeft: number;
  notes: string | null;
  doctor: string;
  patient: { name: string; phone: string | null; allergies: string[] };
  items: {
    id: string;
    name: string;
    dosage: string;
    frequency: string;
    quantity: number;
    instructions: string | null;
    substitutable: boolean;
  }[];
}

export function ScriptQueue({ scripts, offersDelivery }: { scripts: Script[]; offersDelivery: boolean }) {
  const [open, setOpen] = React.useState<Script | null>(null);
  const [fulfilment, setFulfilment] = React.useState<'COLLECTION' | 'DELIVERY'>('COLLECTION');
  const [address, setAddress] = React.useState('');
  const [error, setError] = React.useState<string | null>(null);
  const [done, setDone] = React.useState<{ reference: string; total: number } | null>(null);
  const [pending, startTransition] = React.useTransition();

  if (scripts.length === 0) {
    return (
      <EmptyState
        icon={ClipboardList}
        title="No scripts waiting"
        body="Scripts sent to this pharmacy by a doctor appear here, oldest first."
      />
    );
  }

  function approve(id: string) {
    setError(null);
    startTransition(async () => {
      const result = await approveScript(id);
      if (!result.ok) setError(result.error);
      else setOpen(null);
    });
  }

  function fill(script: Script) {
    setError(null);
    startTransition(async () => {
      const result = await dispense({
        prescriptionId: script.id,
        fulfilment,
        deliveryAddress: fulfilment === 'DELIVERY' ? address : undefined,
      });
      if (!result.ok) setError(result.error);
      else {
        setDone({ reference: result.reference, total: result.total });
        setOpen(null);
      }
    });
  }

  return (
    <>
      {done && (
        <p role="status" className="mb-4 flex items-center gap-2 rounded-card border border-care/30 bg-care-soft p-4 text-sm text-ink">
          <CheckCircle2 className="h-4 w-4 shrink-0 text-care" aria-hidden />
          Dispensed as order {done.reference}. The patient has been sent a payment link for R
          {done.total.toFixed(2)}.
        </p>
      )}

      <ul className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
        {scripts.map((script) => (
          <li key={script.id}>
            <button
              type="button"
              onClick={() => {
                setOpen(script);
                setError(null);
              }}
              className="w-full rounded-card border border-hairline bg-white p-4 text-left transition-colors hover:border-care"
            >
              <div className="flex items-start justify-between gap-3">
                <p className="text-sm font-semibold text-ink">{script.patient.name}</p>
                <Badge status={script.status} />
              </div>
              <p className="money mt-0.5 text-meta text-muted">
                {script.reference} · received {script.received}
              </p>
              <p className="mt-2 truncate text-sm text-ink/70">
                {script.items.map((i) => i.name).join(', ')}
              </p>
              {script.patient.allergies.length > 0 && (
                <p className="mt-2 flex items-center gap-1.5 text-meta text-alert">
                  <AlertTriangle className="h-3.5 w-3.5" aria-hidden />
                  Allergic to {script.patient.allergies.join(', ')}
                </p>
              )}
            </button>
          </li>
        ))}
      </ul>

      <Sheet
        open={Boolean(open)}
        onClose={() => setOpen(null)}
        width="lg"
        title={open?.patient.name ?? ''}
        description={open ? `${open.reference} · from ${open.doctor}` : undefined}
        footer={
          open && (
            <div className="flex gap-2">
              {open.status === 'SENT_TO_PHARMACY' ? (
                <Button full loading={pending} onClick={() => approve(open.id)}>
                  <CheckCircle2 className="h-4 w-4" aria-hidden />
                  Approve as pharmacist
                </Button>
              ) : (
                <Button full loading={pending} onClick={() => fill(open)}>
                  <PackageCheck className="h-4 w-4" aria-hidden />
                  Dispense and price
                </Button>
              )}
            </div>
          )
        }
      >
        {open && (
          <div className="space-y-5">
            {open.patient.allergies.length > 0 && (
              <p className="flex items-start gap-2 rounded-control bg-alert-soft px-3 py-2.5 text-sm text-ink">
                <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-alert" aria-hidden />
                Allergic to {open.patient.allergies.join(', ')}. Check every line against this
                before you hand anything over.
              </p>
            )}

            <dl className="grid grid-cols-2 gap-3 text-sm">
              <div>
                <dt className="text-meta text-muted">Valid until</dt>
                <dd className="text-ink">{open.validUntil}</dd>
              </div>
              <div>
                <dt className="text-meta text-muted">Repeats left</dt>
                <dd className="money text-ink">{open.repeatsLeft}</dd>
              </div>
              <div>
                <dt className="text-meta text-muted">Patient phone</dt>
                <dd className="money text-ink">{open.patient.phone ?? '—'}</dd>
              </div>
            </dl>

            <div>
              <p className="mb-2 text-sm font-medium text-ink">Medicines</p>
              <ul className="divide-y divide-hairline rounded-card border border-hairline">
                {open.items.map((item) => (
                  <li key={item.id} className="p-3.5">
                    <div className="flex items-start justify-between gap-3">
                      <p className="text-sm font-medium text-ink">{item.name}</p>
                      <span className="money shrink-0 text-sm text-muted">× {item.quantity}</span>
                    </div>
                    <p className="mt-0.5 text-meta text-muted">
                      {item.dosage}, {item.frequency}
                    </p>
                    {item.instructions && (
                      <p className="mt-1 text-meta text-ink/70">{item.instructions}</p>
                    )}
                    {!item.substitutable && (
                      <Badge tone="warn" className="mt-2">
                        No substitution
                      </Badge>
                    )}
                  </li>
                ))}
              </ul>
            </div>

            {open.notes && (
              <div>
                <p className="mb-1 text-sm font-medium text-ink">Note from the doctor</p>
                <p className="text-sm text-ink/70">{open.notes}</p>
              </div>
            )}

            {open.status === 'APPROVED' && (
              <div className="space-y-3 border-t border-hairline pt-4">
                <SelectField
                  label="How is the patient getting this?"
                  value={fulfilment}
                  onChange={(e) => setFulfilment(e.target.value as 'COLLECTION' | 'DELIVERY')}
                  options={[
                    { value: 'COLLECTION', label: 'Collecting from the counter' },
                    ...(offersDelivery ? [{ value: 'DELIVERY', label: 'Delivery' }] : []),
                  ]}
                />
                {fulfilment === 'DELIVERY' && (
                  <Field
                    label="Delivery address"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="Street, suburb"
                  />
                )}
              </div>
            )}

            {error && <ErrorState title="Cannot dispense" body={error} />}
          </div>
        )}
      </Sheet>
    </>
  );
}
