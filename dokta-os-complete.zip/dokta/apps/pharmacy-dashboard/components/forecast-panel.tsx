'use client';

import * as React from 'react';
import { Sparkles } from 'lucide-react';
import { Button, Card, CardBody, CardHeader, CardTitle, ErrorState } from '@dokta/ui';
import { money } from '@dokta/shared';
import { runForecast } from '@/app/inventory/expiries/actions';

interface Suggestion {
  medicineName: string;
  predictedUnits30Days: number;
  recommendedOrderQty: number;
  confidence: string;
  reasoning: string;
}

export function ForecastPanel({ atRiskValue, batchCount }: { atRiskValue: number; batchCount: number }) {
  const [suggestions, setSuggestions] = React.useState<Suggestion[] | null>(null);
  const [error, setError] = React.useState<string | null>(null);
  const [pending, startTransition] = React.useTransition();

  function forecast() {
    setError(null);
    startTransition(async () => {
      const result = await runForecast();
      if (result.ok) setSuggestions(result.forecasts);
      else setError(result.error);
    });
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Ordering</CardTitle>
        <span className="money text-meta text-muted">
          {money(atRiskValue)} across {batchCount} batches expiring within 90 days
        </span>
      </CardHeader>
      <CardBody>
        {!suggestions && !error && (
          <div className="flex flex-wrap items-center justify-between gap-3">
            <p className="max-w-prose text-sm text-muted">
              Forecast next month&rsquo;s demand from your own sales history, so you order enough to
              cover the winter peak without adding to what is already expiring.
            </p>
            <Button variant="outline" loading={pending} onClick={forecast}>
              <Sparkles className="h-4 w-4" aria-hidden />
              Forecast demand
            </Button>
          </div>
        )}

        {error && <ErrorState title="Forecast unavailable" body={error} onRetry={forecast} />}

        {suggestions && (
          <ul className="divide-y divide-hairline">
            {suggestions.map((s) => (
              <li key={s.medicineName} className="py-3 first:pt-0 last:pb-0">
                <div className="flex items-start justify-between gap-3">
                  <p className="text-sm font-medium text-ink">{s.medicineName}</p>
                  <p className="money shrink-0 text-sm font-semibold text-ink">
                    Order {s.recommendedOrderQty}
                  </p>
                </div>
                <p className="mt-0.5 text-meta text-muted">
                  {s.predictedUnits30Days} units expected over 30 days · {s.confidence} confidence
                </p>
                <p className="mt-1 text-meta text-ink/70">{s.reasoning}</p>
              </li>
            ))}
          </ul>
        )}
      </CardBody>
    </Card>
  );
}
