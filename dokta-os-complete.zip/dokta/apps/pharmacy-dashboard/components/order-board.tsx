'use client';

import * as React from 'react';
import { Truck } from 'lucide-react';
import { Badge, Button, EmptyState, ErrorState } from '@dokta/ui';
import { moveOrder } from '@/app/prescriptions/actions';

interface Order {
  id: string;
  reference: string;
  status: string;
  fulfilment: string;
  address: string | null;
  total: string;
  placed: string;
  patient: string;
  phone: string | null;
  items: string[];
}

/** The next thing to do to an order, phrased as the action it triggers. */
function nextStep(order: Order): { label: string; status: 'PICKING' | 'READY_FOR_COLLECTION' | 'OUT_FOR_DELIVERY' | 'DELIVERED' } | null {
  if (order.status === 'AWAITING_PAYMENT') return null;
  if (order.status === 'PAID') return { label: 'Start picking', status: 'PICKING' };
  if (order.status === 'PICKING') {
    return order.fulfilment === 'DELIVERY'
      ? { label: 'Send with driver', status: 'OUT_FOR_DELIVERY' }
      : { label: 'Ready at counter', status: 'READY_FOR_COLLECTION' };
  }
  if (order.status === 'OUT_FOR_DELIVERY') return { label: 'Mark delivered', status: 'DELIVERED' };
  if (order.status === 'READY_FOR_COLLECTION') return { label: 'Mark collected', status: 'DELIVERED' };
  return null;
}

export function OrderBoard({ orders }: { orders: Order[] }) {
  const [error, setError] = React.useState<string | null>(null);
  const [pending, startTransition] = React.useTransition();

  if (orders.length === 0) {
    return (
      <EmptyState
        icon={Truck}
        title="No orders in progress"
        body="Dispensed scripts and app orders appear here until they are collected or delivered."
      />
    );
  }

  function advance(id: string, status: Parameters<typeof moveOrder>[1]) {
    setError(null);
    startTransition(async () => {
      const result = await moveOrder(id, status);
      if (!result.ok) setError(result.error);
    });
  }

  return (
    <>
      {error && <ErrorState title="Could not update the order" body={error} />}

      <ul className="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-3">
        {orders.map((order) => {
          const step = nextStep(order);
          return (
            <li key={order.id} className="rounded-card border border-hairline bg-white p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-sm font-semibold text-ink">{order.patient}</p>
                  <p className="money text-meta text-muted">
                    {order.reference} · {order.placed}
                  </p>
                </div>
                <Badge status={order.status} />
              </div>

              <ul className="mt-3 space-y-0.5 text-sm text-ink/70">
                {order.items.map((item) => (
                  <li key={item} className="truncate">
                    {item}
                  </li>
                ))}
              </ul>

              {order.fulfilment === 'DELIVERY' && order.address && (
                <p className="mt-2 flex items-start gap-1.5 text-meta text-muted">
                  <Truck className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden />
                  {order.address}
                </p>
              )}

              <div className="mt-4 flex items-center justify-between gap-3">
                <span className="money text-sm font-semibold text-ink">{order.total}</span>
                {step ? (
                  <Button size="sm" loading={pending} onClick={() => advance(order.id, step.status)}>
                    {step.label}
                  </Button>
                ) : (
                  <span className="text-meta text-warn">Waiting on payment</span>
                )}
              </div>
            </li>
          );
        })}
      </ul>
    </>
  );
}
