'use server';

import { revalidatePath } from 'next/cache';
import { requireCapability } from '@dokta/auth';
import { db } from '@dokta/database';
import { DomainError, advanceOrder, dispensePrescription } from '@dokta/core';
import { currentPharmacy } from '@/app/layout';

async function pharmacyContext(capability: string) {
  const session = await requireCapability(capability, '/prescriptions');
  const pharmacy = await currentPharmacy(session.id);
  if (!pharmacy) throw new Error('This account is not linked to a pharmacy');
  return { session, pharmacyId: pharmacy.id };
}

/**
 * A pharmacist checks the script before any stock moves. Approval is recorded
 * separately from dispensing so the two steps can be done by different people.
 */
export async function approveScript(prescriptionId: string) {
  const { session, pharmacyId } = await pharmacyContext('prescription:dispense');

  const staff = await db.pharmacyStaff.findFirst({
    where: { pharmacyId, userId: session.id },
    select: { canDispense: true },
  });
  const owner = await db.pharmacy.findFirst({
    where: { id: pharmacyId, ownerId: session.id },
    select: { id: true },
  });

  if (!owner && !staff?.canDispense) {
    return { ok: false as const, error: 'Only a pharmacist on this account can approve scripts.' };
  }

  await db.prescription.updateMany({
    where: { id: prescriptionId, pharmacyId, status: 'SENT_TO_PHARMACY' },
    data: { status: 'APPROVED' },
  });

  revalidatePath('/prescriptions');
  return { ok: true as const };
}

export async function dispense(input: {
  prescriptionId: string;
  fulfilment: 'COLLECTION' | 'DELIVERY';
  deliveryAddress?: string;
  substitutions?: Record<string, string>;
}) {
  const { pharmacyId } = await pharmacyContext('prescription:dispense');

  try {
    const order = await dispensePrescription({ ...input, pharmacyId });
    revalidatePath('/prescriptions');
    revalidatePath('/orders');
    revalidatePath('/inventory');
    return { ok: true as const, reference: order.reference, total: Number(order.total) };
  } catch (error) {
    if (error instanceof DomainError) return { ok: false as const, error: error.message };
    throw error;
  }
}

export async function moveOrder(
  orderId: string,
  status: 'PICKING' | 'READY_FOR_COLLECTION' | 'OUT_FOR_DELIVERY' | 'DELIVERED',
) {
  const { pharmacyId } = await pharmacyContext('order:fulfil');

  const owns = await db.order.findFirst({ where: { id: orderId, pharmacyId }, select: { id: true } });
  if (!owns) return { ok: false as const, error: 'That order belongs to another pharmacy.' };

  await advanceOrder(orderId, status);
  revalidatePath('/orders');
  return { ok: true as const };
}
