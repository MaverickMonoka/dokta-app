import { ClipboardList } from 'lucide-react';
import { requireCapability, audit } from '@dokta/auth';
import { pharmacyQueue } from '@dokta/core';
import { shortDate } from '@dokta/shared';
import { EmptyState, PageHeader } from '@dokta/ui';
import { currentPharmacy } from '@/app/layout';
import { ScriptQueue } from '@/components/script-queue';

export const metadata = { title: 'Scripts' };
export const dynamic = 'force-dynamic';

export default async function PrescriptionsPage() {
  const session = await requireCapability('prescription:read:assigned', '/prescriptions');
  const pharmacy = await currentPharmacy(session.id);

  if (!pharmacy) {
    return <EmptyState icon={ClipboardList} title="No pharmacy linked" body="Ask the owner to add you as staff." />;
  }

  const queue = await pharmacyQueue(pharmacy.id);

  // Reading a script is reading health information about someone else.
  await Promise.all(
    queue.map((rx) =>
      audit({
        actorId: session.id,
        action: 'read',
        entity: 'Prescription',
        entityId: rx.id,
        subjectId: rx.patient.id,
        lawfulBasis: 'provision_of_healthcare',
      }),
    ),
  );

  return (
    <>
      <PageHeader
        title="Scripts to fill"
        description="A pharmacist approves each script before stock moves. Dispensing creates a priced order for the patient to pay."
      />
      <div className="p-5 lg:p-8">
        <ScriptQueue
          offersDelivery
          scripts={queue.map((rx) => ({
            id: rx.id,
            reference: rx.reference,
            status: rx.status,
            received: shortDate(rx.createdAt),
            validUntil: shortDate(rx.validUntil),
            repeatsLeft: rx.repeats - rx.repeatsUsed,
            notes: rx.notes,
            doctor: `${rx.doctor.user.name} · ${rx.doctor.speciality}`,
            patient: {
              name: rx.patient.user.name,
              phone: rx.patient.user.phone,
              allergies: (rx.patient.allergies as string[]) ?? [],
            },
            items: rx.items.map((i) => ({
              id: i.id,
              name: `${i.medicineName}${i.strength ? ` ${i.strength}` : ''}`,
              dosage: i.dosage,
              frequency: i.frequency,
              quantity: i.quantity,
              instructions: i.instructions,
              substitutable: i.substitutable,
            })),
          }))}
        />
      </div>
    </>
  );
}
