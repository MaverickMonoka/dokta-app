import Link from 'next/link';
import { AlertTriangle, Boxes, CalendarX2, ScanLine } from 'lucide-react';
import { requireCapability } from '@dokta/auth';
import { expiringBatches, lowStock, todaysTakings } from '@dokta/core';
import { db } from '@dokta/database';
import { money, shortDate } from '@dokta/shared';
import { Card, CardBody, CardHeader, CardTitle, EmptyState, PageHeader, Stat, buttonVariants } from '@dokta/ui';
import { currentPharmacy } from '@/app/layout';

export const dynamic = 'force-dynamic';

export default async function PharmacyToday() {
  const session = await requireCapability('pos:operate', '/');
  const pharmacy = await currentPharmacy(session.id);

  if (!pharmacy) {
    return (
      <EmptyState
        icon={Boxes}
        title="No pharmacy linked to this account"
        body="Ask the owner to add you as staff, then sign in again."
      />
    );
  }

  const [takings, low, expiring, scripts] = await Promise.all([
    todaysTakings(pharmacy.id),
    lowStock(pharmacy.id),
    expiringBatches(pharmacy.id, 60),
    db.prescription.count({
      where: { pharmacyId: pharmacy.id, status: { in: ['SENT_TO_PHARMACY', 'APPROVED'] } },
    }),
  ]);

  return (
    <>
      <PageHeader
        title="Today"
        description={new Intl.DateTimeFormat('en-ZA', { dateStyle: 'full' }).format(new Date())}
        actions={
          <Link href="/pos" className={buttonVariants()}>
            <ScanLine className="h-4 w-4" aria-hidden />
            Open till
          </Link>
        }
      />

      <div className="space-y-5 p-5 lg:p-8">
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <Stat label="Takings today" value={money(takings.total)} hint={`${takings.counterCount + takings.onlineCount} sales`} />
          <Stat label="Over the counter" value={money(takings.counterTotal)} hint={`${takings.counterCount} at the till`} />
          <Stat label="Scripts waiting" value={scripts} />
          <Stat label="Lines below reorder" value={low.length} />
        </div>

        <div className="grid gap-5 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>Reorder now</CardTitle>
              <Link href="/inventory" className="text-meta text-care hover:text-care-dark">
                All stock
              </Link>
            </CardHeader>
            <CardBody className="px-0 pb-0">
              {low.length === 0 ? (
                <p className="px-5 pb-5 text-sm text-muted">Every line is above its reorder level.</p>
              ) : (
                <ul className="divide-y divide-hairline border-t border-hairline">
                  {low.slice(0, 6).map((item) => (
                    <li key={item.id} className="flex items-center justify-between gap-3 px-5 py-3">
                      <span className="min-w-0">
                        <span className="block truncate text-sm font-medium text-ink">
                          {item.medicine.name} {item.medicine.strength}
                        </span>
                        <span className="text-meta text-muted">
                          Reorder level {item.reorderLevel} · order {item.reorderQty}
                        </span>
                      </span>
                      <span
                        className={`money shrink-0 text-sm font-semibold ${item.stockOnHand === 0 ? 'text-alert' : 'text-warn'}`}
                      >
                        {item.stockOnHand} left
                      </span>
                    </li>
                  ))}
                </ul>
              )}
            </CardBody>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Expiring within 60 days</CardTitle>
              <Link href="/inventory/expiries" className="text-meta text-care hover:text-care-dark">
                Plan them
              </Link>
            </CardHeader>
            <CardBody className="px-0 pb-0">
              {expiring.length === 0 ? (
                <p className="px-5 pb-5 text-sm text-muted">Nothing expiring in the next two months.</p>
              ) : (
                <ul className="divide-y divide-hairline border-t border-hairline">
                  {expiring.slice(0, 6).map((batch) => {
                    const days = Math.ceil((batch.expiryDate.getTime() - Date.now()) / 86_400_000);
                    return (
                      <li key={batch.id} className="flex items-center justify-between gap-3 px-5 py-3">
                        <span className="min-w-0">
                          <span className="block truncate text-sm font-medium text-ink">
                            {batch.inventory.medicine.name} {batch.inventory.medicine.strength}
                          </span>
                          <span className="money text-meta text-muted">
                            Batch {batch.batchNumber} · {batch.quantity} units
                          </span>
                        </span>
                        <span
                          className={`shrink-0 text-meta font-medium ${days <= 30 ? 'text-alert' : 'text-warn'}`}
                        >
                          {days <= 0 ? 'Expired' : `${days} days`}
                        </span>
                      </li>
                    );
                  })}
                </ul>
              )}
            </CardBody>
          </Card>
        </div>

        {expiring.some((b) => b.expiryDate < new Date()) && (
          <p className="flex items-start gap-2 rounded-card border border-alert/30 bg-alert-soft p-4 text-sm text-ink">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-alert" aria-hidden />
            Expired stock is still on your shelf list. It cannot be dispensed or sold — pull it and
            write it off on the expiries page.
          </p>
        )}
      </div>
    </>
  );
}
