import type { Metadata, Viewport } from 'next';
import { Inter, Plus_Jakarta_Sans } from 'next/font/google';
import { headers } from 'next/headers';
import { BarChart3, Boxes, ClipboardList, LayoutDashboard, ScanLine, Truck } from 'lucide-react';
import { requireCapability } from '@dokta/auth';
import { db } from '@dokta/database';
import { AppShell } from '@dokta/ui';
import './globals.css';

const body = Inter({ subsets: ['latin'], variable: '--font-body', display: 'swap' });
const display = Plus_Jakarta_Sans({
  subsets: ['latin'],
  weight: ['600', '700'],
  variable: '--font-display',
  display: 'swap',
});

export const metadata: Metadata = { title: { default: 'Pharmacy', template: '%s · DOKTA' } };
export const viewport: Viewport = { themeColor: '#0B2137', width: 'device-width', initialScale: 1 };

/** The pharmacy the signed-in person works at, whether they own it or staff it. */
export async function currentPharmacy(userId: string) {
  const owned = await db.pharmacy.findFirst({ where: { ownerId: userId }, select: { id: true, name: true } });
  if (owned) return owned;

  const staff = await db.pharmacyStaff.findFirst({
    where: { userId },
    select: { pharmacy: { select: { id: true, name: true } } },
  });
  return staff?.pharmacy ?? null;
}

export default async function PharmacyLayout({ children }: { children: React.ReactNode }) {
  const session = await requireCapability('pos:operate', '/');
  const pharmacy = await currentPharmacy(session.id);

  const waiting = pharmacy
    ? await db.prescription.count({
        where: { pharmacyId: pharmacy.id, status: { in: ['SENT_TO_PHARMACY', 'APPROVED'] } },
      })
    : 0;

  const path = headers().get('x-invoke-path') ?? headers().get('x-pathname') ?? '/';

  return (
    <html lang="en-ZA" className={`${body.variable} ${display.variable}`}>
      <body>
        <AppShell
          product={pharmacy?.name ?? 'Pharmacy'}
          currentPath={path}
          user={{ name: session.name, subtitle: pharmacy?.name }}
          nav={[
            { href: '/', label: 'Today', icon: LayoutDashboard },
            { href: '/pos', label: 'Till', icon: ScanLine },
            { href: '/prescriptions', label: 'Scripts', icon: ClipboardList, badge: waiting },
            { href: '/orders', label: 'Deliveries', icon: Truck },
            { href: '/inventory', label: 'Stock', icon: Boxes },
            { href: '/reports', label: 'Reports', icon: BarChart3 },
          ]}
        >
          {children}
        </AppShell>
      </body>
    </html>
  );
}
