import { BarChart3 } from 'lucide-react';
import { requireCapability } from '@dokta/auth';
import { db } from '@dokta/database';
import { money } from '@dokta/shared';
import { BarList, Card, CardBody, CardHeader, CardTitle, EmptyState, LineChart, PageHeader, Stat } from '@dokta/ui';
import { currentPharmacy } from '@/app/layout';

export const metadata = { title: 'Reports' };
export const dynamic = 'force-dynamic';

export default async function ReportsPage() {
  const session = await requireCapability('report:sales', '/reports');
  const pharmacy = await currentPharmacy(session.id);
  if (!pharmacy) return <EmptyState icon={BarChart3} title="No pharmacy linked" body="Ask the owner to add you as staff." />;

  const since = new Date(Date.now() - 29 * 86_400_000);
  since.setHours(0, 0, 0, 0);

  const [sales, orderItems] = await Promise.all([
    db.sale.findMany({
      where: { pharmacyId: pharmacy.id, createdAt: { gte: since }, voidedAt: null },
      select: { total: true, createdAt: true, gateway: true },
    }),
    db.orderItem.findMany({
      where: { order: { pharmacyId: pharmacy.id, placedAt: { gte: since } } },
      select: { description: true, quantity: true, lineTotal: true },
    }),
  ]);

  const labels: string[] = [];
  const daily: number[] = [];
  for (let i = 29; i >= 0; i -= 1) {
    const key = new Date(Date.now() - i * 86_400_000).toISOString().slice(0, 10);
    labels.push(key);
    daily.push(
      Math.round(
        sales
          .filter((s) => s.createdAt.toISOString().slice(0, 10) === key)
          .reduce((sum, s) => sum + Number(s.total), 0) * 100,
      ) / 100,
    );
  }

  const counterTotal = sales.reduce((sum, s) => sum + Number(s.total), 0);
  const scriptTotal = orderItems.reduce((sum, i) => sum + Number(i.lineTotal), 0);

  const byMedicine = new Map<string, number>();
  for (const item of orderItems) {
    byMedicine.set(item.description, (byMedicine.get(item.description) ?? 0) + item.quantity);
  }

  const byMethod = new Map<string, number>();
  for (const sale of sales) {
    byMethod.set(sale.gateway, (byMethod.get(sale.gateway) ?? 0) + Number(sale.total));
  }

  return (
    <>
      <PageHeader title="Last 30 days" description={`${pharmacy.name} · counter and script sales`} />

      <div className="space-y-5 p-5 lg:p-8">
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <Stat label="Total turnover" value={money(counterTotal + scriptTotal)} />
          <Stat label="Over the counter" value={money(counterTotal)} hint={`${sales.length} sales`} />
          <Stat label="Against scripts" value={money(scriptTotal)} />
          <Stat
            label="Average basket"
            value={money(sales.length ? counterTotal / sales.length : 0)}
          />
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Daily counter takings</CardTitle>
          </CardHeader>
          <CardBody>
            <LineChart values={daily} labels={labels} format={money} />
          </CardBody>
        </Card>

        <div className="grid gap-5 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>Most dispensed</CardTitle>
            </CardHeader>
            <CardBody>
              {byMedicine.size === 0 ? (
                <p className="text-sm text-muted">No scripts dispensed in this period.</p>
              ) : (
                <BarList
                  items={Array.from(byMedicine, ([name, value]) => ({ name, value }))
                    .sort((a, b) => b.value - a.value)
                    .slice(0, 8)}
                  format={(n) => `${n} units`}
                />
              )}
            </CardBody>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>How customers paid</CardTitle>
            </CardHeader>
            <CardBody>
              {byMethod.size === 0 ? (
                <p className="text-sm text-muted">No counter sales in this period.</p>
              ) : (
                <BarList
                  items={Array.from(byMethod, ([name, value]) => ({
                    name: name.charAt(0) + name.slice(1).toLowerCase(),
                    value,
                  })).sort((a, b) => b.value - a.value)}
                  format={money}
                />
              )}
            </CardBody>
          </Card>
        </div>
      </div>
    </>
  );
}
