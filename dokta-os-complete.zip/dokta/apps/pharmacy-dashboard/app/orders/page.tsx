import { Truck } from 'lucide-react';
import { requireCapability } from '@dokta/auth';
import { db } from '@dokta/database';
import { money, shortDate } from '@dokta/shared';
import { EmptyState, PageHeader } from '@dokta/ui';
import { currentPharmacy } from '@/app/layout';
import { OrderBoard } from '@/components/order-board';

export const metadata = { title: 'Deliveries' };
export const dynamic = 'force-dynamic';

export default async function OrdersPage() {
  const session = await requireCapability('order:fulfil', '/orders');
  const pharmacy = await currentPharmacy(session.id);
  if (!pharmacy) return <EmptyState icon={Truck} title="No pharmacy linked" body="Ask the owner to add you as staff." />;

  const orders = await db.order.findMany({
    where: {
      pharmacyId: pharmacy.id,
      status: { in: ['AWAITING_PAYMENT', 'PAID', 'PICKING', 'READY_FOR_COLLECTION', 'OUT_FOR_DELIVERY'] },
    },
    orderBy: { placedAt: 'asc' },
    select: {
      id: true,
      reference: true,
      status: true,
      fulfilment: true,
      deliveryAddress: true,
      total: true,
      placedAt: true,
      items: { select: { description: true, quantity: true } },
      patient: { select: { user: { select: { name: true, phone: true } } } },
    },
  });

  return (
    <>
      <PageHeader
        title="Orders in progress"
        description="An order moves to picking once the patient has paid. Nothing leaves the counter before that."
      />
      <div className="p-5 lg:p-8">
        <OrderBoard
          orders={orders.map((o) => ({
            id: o.id,
            reference: o.reference,
            status: o.status,
            fulfilment: o.fulfilment,
            address: o.deliveryAddress,
            total: money(Number(o.total)),
            placed: o.placedAt ? shortDate(o.placedAt) : '—',
            patient: o.patient.user.name,
            phone: o.patient.user.phone,
            items: o.items.map((i) => `${i.quantity} × ${i.description}`),
          }))}
        />
      </div>
    </>
  );
}
