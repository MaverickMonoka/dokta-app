import Link from 'next/link';
import { Boxes } from 'lucide-react';
import { requireCapability } from '@dokta/auth';
import { db } from '@dokta/database';
import { money } from '@dokta/shared';
import { Badge, DataTable, EmptyState, PageHeader, Stat, buttonVariants } from '@dokta/ui';
import { currentPharmacy } from '@/app/layout';

export const metadata = { title: 'Stock' };
export const dynamic = 'force-dynamic';

export default async function InventoryPage() {
  const session = await requireCapability('inventory:manage', '/inventory');
  const pharmacy = await currentPharmacy(session.id);
  if (!pharmacy) return <EmptyState icon={Boxes} title="No pharmacy linked" body="Ask the owner to add you as staff." />;

  const items = await db.inventoryItem.findMany({
    where: { pharmacyId: pharmacy.id },
    orderBy: { medicine: { name: 'asc' } },
    select: {
      id: true,
      sellingPrice: true,
      costPrice: true,
      stockOnHand: true,
      reorderLevel: true,
      isActive: true,
      medicine: { select: { name: true, strength: true, schedule: true } },
      batches: { orderBy: { expiryDate: 'asc' }, take: 1, select: { expiryDate: true } },
    },
  });

  const stockValue = items.reduce((sum, i) => sum + Number(i.costPrice ?? 0) * i.stockOnHand, 0);
  const retailValue = items.reduce((sum, i) => sum + Number(i.sellingPrice) * i.stockOnHand, 0);

  return (
    <>
      <PageHeader
        title="Stock"
        description="Stock comes off first-expiry-first when you dispense or ring up a sale."
        actions={
          <Link href="/inventory/expiries" className={buttonVariants({ variant: 'outline', size: 'sm' })}>
            Expiries
          </Link>
        }
      />

      <div className="space-y-5 p-5 lg:p-8">
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <Stat label="Lines stocked" value={items.length} />
          <Stat label="Stock at cost" value={money(stockValue)} />
          <Stat label="Stock at retail" value={money(retailValue)} />
          <Stat
            label="Margin if it all sells"
            value={money(retailValue - stockValue)}
            hint={stockValue > 0 ? `${Math.round(((retailValue - stockValue) / stockValue) * 100)}% on cost` : undefined}
          />
        </div>

        <DataTable
          rows={items}
          rowKey={(i) => i.id}
          empty={
            <EmptyState
              icon={Boxes}
              title="No stock loaded yet"
              body="Add the lines you sell so they can be scanned at the till and dispensed against scripts."
            />
          }
          columns={[
            {
              key: 'name',
              header: 'Medicine',
              render: (i) => (
                <span>
                  <span className="block font-medium text-ink">{i.medicine.name}</span>
                  <span className="block text-meta text-muted">{i.medicine.strength ?? '—'}</span>
                </span>
              ),
            },
            {
              key: 'schedule',
              header: 'Schedule',
              render: (i) => <Badge tone={i.medicine.schedule === 'S0' ? 'neutral' : 'warn'}>{i.medicine.schedule}</Badge>,
            },
            {
              key: 'stock',
              header: 'On hand',
              numeric: true,
              render: (i) => (
                <span className={i.stockOnHand <= i.reorderLevel ? 'font-semibold text-alert' : 'text-ink'}>
                  {i.stockOnHand}
                </span>
              ),
            },
            { key: 'reorder', header: 'Reorder at', numeric: true, render: (i) => i.reorderLevel },
            { key: 'cost', header: 'Cost', numeric: true, render: (i) => money(Number(i.costPrice ?? 0)) },
            { key: 'price', header: 'Price', numeric: true, render: (i) => money(Number(i.sellingPrice)) },
            {
              key: 'expiry',
              header: 'First expiry',
              render: (i) =>
                i.batches[0]
                  ? new Intl.DateTimeFormat('en-ZA', { month: 'short', year: 'numeric' }).format(i.batches[0].expiryDate)
                  : '—',
            },
          ]}
        />
      </div>
    </>
  );
}
