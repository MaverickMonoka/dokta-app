import { CalendarX2 } from 'lucide-react';
import { requireCapability } from '@dokta/auth';
import { expiringBatches } from '@dokta/core';
import { money } from '@dokta/shared';
import { Badge, DataTable, EmptyState, PageHeader } from '@dokta/ui';
import { currentPharmacy } from '@/app/layout';
import { ForecastPanel } from '@/components/forecast-panel';

export const metadata = { title: 'Expiries' };
export const dynamic = 'force-dynamic';

export default async function ExpiriesPage() {
  const session = await requireCapability('inventory:manage', '/inventory/expiries');
  const pharmacy = await currentPharmacy(session.id);
  if (!pharmacy) return <EmptyState icon={CalendarX2} title="No pharmacy linked" body="Ask the owner to add you as staff." />;

  const batches = await expiringBatches(pharmacy.id, 180);

  const rows = batches.map((b) => {
    const days = Math.ceil((b.expiryDate.getTime() - Date.now()) / 86_400_000);
    return {
      id: b.id,
      batchNumber: b.batchNumber,
      name: `${b.inventory.medicine.name} ${b.inventory.medicine.strength ?? ''}`.trim(),
      quantity: b.quantity,
      value: Number(b.inventory.sellingPrice) * b.quantity,
      expiryDate: b.expiryDate,
      supplier: b.supplier?.name ?? '—',
      days,
    };
  });

  const atRisk = rows.filter((r) => r.days <= 90).reduce((sum, r) => sum + r.value, 0);

  return (
    <>
      <PageHeader
        title="Expiring stock"
        description="Suppliers usually accept returns up to six months before expiry, not after. Anything inside 30 days is worth discounting now."
      />

      <div className="space-y-5 p-5 lg:p-8">
        <ForecastPanel atRiskValue={atRisk} batchCount={rows.filter((r) => r.days <= 90).length} />

        <DataTable
          rows={rows}
          rowKey={(r) => r.id}
          empty={
            <EmptyState
              icon={CalendarX2}
              title="Nothing expiring in six months"
              body="Batches move here automatically as they approach their expiry date."
            />
          }
          columns={[
            {
              key: 'name',
              header: 'Medicine',
              render: (r) => (
                <span>
                  <span className="block font-medium text-ink">{r.name}</span>
                  <span className="money block text-meta text-muted">Batch {r.batchNumber}</span>
                </span>
              ),
            },
            { key: 'qty', header: 'Units', numeric: true, render: (r) => r.quantity },
            { key: 'value', header: 'Retail value', numeric: true, render: (r) => money(r.value) },
            { key: 'supplier', header: 'Supplier', render: (r) => r.supplier },
            {
              key: 'expiry',
              header: 'Expires',
              render: (r) =>
                new Intl.DateTimeFormat('en-ZA', { dateStyle: 'medium' }).format(r.expiryDate),
            },
            {
              key: 'window',
              header: 'Action',
              render: (r) =>
                r.days <= 0 ? (
                  <Badge tone="alert">Write off</Badge>
                ) : r.days <= 30 ? (
                  <Badge tone="alert">Discount now</Badge>
                ) : r.days <= 90 ? (
                  <Badge tone="warn">Sell through</Badge>
                ) : (
                  <Badge tone="neutral">Return window open</Badge>
                ),
            },
          ]}
        />
      </div>
    </>
  );
}
