'use server';

import { requireCapability } from '@dokta/auth';
import { db } from '@dokta/database';
import { forecastDemand } from '@dokta/ai';
import { currentPharmacy } from '@/app/layout';

/**
 * Builds twelve months of sales history per line from counter sales and
 * dispensed orders, then asks the model to project the next thirty days.
 */
export async function runForecast() {
  const session = await requireCapability('inventory:manage', '/inventory/expiries');
  const pharmacy = await currentPharmacy(session.id);
  if (!pharmacy) return { ok: false as const, error: 'No pharmacy linked to this account.' };

  const since = new Date();
  since.setMonth(since.getMonth() - 12);

  const [items, orderLines] = await Promise.all([
    db.inventoryItem.findMany({
      where: { pharmacyId: pharmacy.id, isActive: true },
      select: { medicineId: true, medicine: { select: { name: true } } },
      take: 25,
    }),
    db.orderItem.findMany({
      where: { order: { pharmacyId: pharmacy.id, placedAt: { gte: since } } },
      select: { medicineId: true, quantity: true, order: { select: { placedAt: true } } },
    }),
  ]);

  const history = items.map((item) => {
    const months = Array.from({ length: 12 }, () => 0);
    for (const line of orderLines) {
      if (line.medicineId !== item.medicineId || !line.order.placedAt) continue;
      const monthsAgo = Math.floor(
        (Date.now() - line.order.placedAt.getTime()) / (30 * 86_400_000),
      );
      if (monthsAgo >= 0 && monthsAgo < 12) months[11 - monthsAgo] += line.quantity;
    }
    return { medicineId: item.medicineId, name: item.medicine.name, unitsByMonth: months };
  });

  if (history.every((h) => h.unitsByMonth.every((m) => m === 0))) {
    return {
      ok: false as const,
      error: 'There is no sales history to forecast from yet. Come back after a few weeks of trading.',
    };
  }

  try {
    const forecasts = await forecastDemand({ history, month: new Date().getMonth() + 1 });
    return { ok: true as const, forecasts };
  } catch {
    return { ok: false as const, error: 'The forecasting service did not respond. Try again shortly.' };
  }
}
