'use server';

import { revalidatePath } from 'next/cache';
import { requireCapability } from '@dokta/auth';
import { DomainError, ringUpSale, scanBarcode, type CartLine } from '@dokta/core';
import { currentPharmacy } from '@/app/layout';

async function till() {
  const session = await requireCapability('pos:operate', '/pos');
  const pharmacy = await currentPharmacy(session.id);
  if (!pharmacy) throw new Error('This account is not linked to a pharmacy');
  return { session, pharmacyId: pharmacy.id };
}

export async function lookupBarcode(barcode: string) {
  const { pharmacyId } = await till();

  try {
    return { ok: true as const, product: await scanBarcode(pharmacyId, barcode.trim()) };
  } catch (error) {
    if (error instanceof DomainError) {
      return { ok: false as const, error: `${error.message}. Add it to your stock list first.` };
    }
    throw error;
  }
}

export async function completeSale(input: {
  lines: CartLine[];
  discount: number;
  gateway: 'CASH' | 'YOCO' | 'SNAPSCAN';
  tendered?: number;
}) {
  const { session, pharmacyId } = await till();

  try {
    const { sale, totals } = await ringUpSale({
      pharmacyId,
      cashierId: session.id,
      lines: input.lines,
      discount: input.discount,
      gateway: input.gateway,
      tendered: input.tendered,
    });

    revalidatePath('/');
    revalidatePath('/inventory');

    return {
      ok: true as const,
      receipt: {
        reference: sale.reference,
        lines: input.lines,
        ...totals,
        tendered: input.tendered ?? null,
        change: input.tendered != null ? Math.round((input.tendered - totals.total) * 100) / 100 : null,
        gateway: input.gateway,
        at: sale.createdAt.toISOString(),
      },
    };
  } catch (error) {
    if (error instanceof DomainError) return { ok: false as const, error: error.message };
    throw error;
  }
}
