import { requireCapability } from '@dokta/auth';
import { db } from '@dokta/database';
import { EmptyState } from '@dokta/ui';
import { ScanLine } from 'lucide-react';
import { currentPharmacy } from '@/app/layout';
import { PosTerminal } from '@/components/pos-terminal';

export const metadata = { title: 'Till' };
export const dynamic = 'force-dynamic';

export default async function PosPage() {
  const session = await requireCapability('pos:operate', '/pos');
  const pharmacy = await currentPharmacy(session.id);

  if (!pharmacy) {
    return (
      <EmptyState
        icon={ScanLine}
        title="This account is not linked to a pharmacy"
        body="Ask the pharmacy owner to add you as staff, then sign in again."
      />
    );
  }

  // Quick keys for the counter: what actually sells, most-sold first.
  const popular = await db.inventoryItem.findMany({
    where: { pharmacyId: pharmacy.id, isActive: true, stockOnHand: { gt: 0 } },
    orderBy: { medicine: { name: 'asc' } },
    take: 12,
    select: {
      id: true,
      sellingPrice: true,
      stockOnHand: true,
      medicine: { select: { id: true, name: true, strength: true, schedule: true } },
    },
  });

  return (
    <PosTerminal
      cashierName={session.name}
      quickKeys={popular.map((item) => ({
        inventoryId: item.id,
        medicineId: item.medicine.id,
        name: item.medicine.name,
        strength: item.medicine.strength,
        unitPrice: Number(item.sellingPrice),
        stockOnHand: item.stockOnHand,
        requiresPharmacist: item.medicine.schedule !== 'S0' && item.medicine.schedule !== 'S1',
      }))}
    />
  );
}
